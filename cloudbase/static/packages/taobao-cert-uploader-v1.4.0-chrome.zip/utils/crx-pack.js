(function (global) {
  const SIGNATURE_CONTEXT = new TextEncoder().encode('CRX3 SignedData\x00');

  function encodeVarint(value) {
    const out = [];
    let n = value >>> 0;
    while (n >= 0x80) {
      out.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    out.push(n);
    return new Uint8Array(out);
  }

  function concatChunks(chunks) {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    chunks.forEach((chunk) => {
      out.set(chunk, offset);
      offset += chunk.length;
    });
    return out;
  }

  function encodeLengthDelimited(fieldNumber, bytes) {
    const tag = encodeVarint((fieldNumber << 3) | 2);
    const len = encodeVarint(bytes.length);
    return concatChunks([tag, len, bytes]);
  }

  function toArrayBuffer(bytes) {
    const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    return view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength);
  }

  function pemToArrayBuffer(pem) {
    const b64 = pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  async function importPrivateKey(pemText) {
    return crypto.subtle.importKey(
      'pkcs8',
      pemToArrayBuffer(pemText),
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      true,
      ['sign']
    );
  }

  async function getPublicSpkiFromPrivateKey(privateKey) {
    const jwk = await crypto.subtle.exportKey('jwk', privateKey);
    const publicJwk = {
      kty: jwk.kty,
      n: jwk.n,
      e: jwk.e,
      alg: 'RS256',
      ext: true,
    };
    const publicKey = await crypto.subtle.importKey(
      'jwk',
      publicJwk,
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      true,
      ['verify']
    );
    return new Uint8Array(await crypto.subtle.exportKey('spki', publicKey));
  }

  async function calculateCrxId(publicSpki) {
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', publicSpki));
    return hash.slice(0, 16);
  }

  /**
   * 按 Chromium 的规则计算并校验 CRX3 签名载荷。
   *
   * 依据：components/crx_file/crx_verifier.cc → VerifyCrx3()
   *   v->Update(kSignatureContext);              // "CRX3 SignedData\0"
   *   v->Update(header_size_octets);             // LE32(signed_header_data.size())
   *   v->Update(signed_header_data_str);         // field 10000 的值
   *   再 Update(archive)
   *
   * 其中 header_size_octets 是 **signed_header_data（序列化后的 SignedData）的字节数**，
   * 不是整个 CrxFileHeader 的长度。历史上这里取错长度，导致签名永远验不过、
   * Chrome / 360 直接拒绝安装（"CRX_REQUIRED_PROOF_MISSING" / 无法安装）。
   * 另外 version != 3 会被直接判定为 ERROR_HEADER_INVALID，
   * 所以绝不能回退成手工拼的 "Cr24 + version 2" 伪 CRX。
   */
  function buildSignPayload(signedData, zipBytes) {
    const headerSizeOctets = new Uint8Array(4);
    new DataView(headerSizeOctets.buffer).setUint32(0, signedData.length, true);
    return concatChunks([SIGNATURE_CONTEXT, headerSizeOctets, signedData, zipBytes]);
  }

  async function verifyCrx3SignedData({ signedData, zipBytes, publicSpki, signature }) {
    const publicKey = await crypto.subtle.importKey(
      'spki',
      toArrayBuffer(publicSpki),
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      false,
      ['verify']
    );
    return crypto.subtle.verify(
      'RSASSA-PKCS1-v1_5',
      publicKey,
      toArrayBuffer(signature),
      buildSignPayload(signedData, zipBytes)
    );
  }

  async function packCrx3(zipBytes, pemText) {
    const privateKey = await importPrivateKey(pemText);
    const publicSpki = await getPublicSpkiFromPrivateKey(privateKey);
    const crxId = await calculateCrxId(publicSpki);

    // field 10000 的值：序列化后的 SignedData{ crx_id }，共 18 字节
    const signedData = encodeLengthDelimited(1, crxId);

    const signature = new Uint8Array(
      await crypto.subtle.sign(
        'RSASSA-PKCS1-v1_5',
        privateKey,
        buildSignPayload(signedData, zipBytes)
      )
    );

    // CrxFileHeader{ sha256_with_rsa: AsymmetricKeyProof{ public_key, signature }, signed_header_data }
    const proof = concatChunks([
      encodeLengthDelimited(1, publicSpki),
      encodeLengthDelimited(2, signature),
    ]);
    const header = concatChunks([
      encodeLengthDelimited(2, proof),
      encodeLengthDelimited(10000, signedData),
    ]);

    const magic = new TextEncoder().encode('Cr24');
    const version = new Uint8Array(4);
    new DataView(version.buffer).setUint32(0, 3, true);
    const headerSize = new Uint8Array(4);
    new DataView(headerSize.buffer).setUint32(0, header.length, true);

    const crx = concatChunks([magic, version, headerSize, header, zipBytes]);

    // 打包自检：签名必须能用 Chromium 的算法验过，否则宁可抛错也不要产出废包
    const ok = await verifyCrx3SignedData({ signedData, zipBytes, publicSpki, signature });
    if (!ok) {
      throw new Error('CRX3 自检失败：签名校验未通过，已中止打包');
    }

    return crx;
  }

  global.TCBCrxPack = {
    packCrx3,
    buildSignPayload,
    verifyCrx3SignedData,
    calculateCrxId,
    getPublicSpkiFromPrivateKey,
    importPrivateKey,
  };
})(typeof self !== 'undefined' ? self : this);
