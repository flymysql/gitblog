# 淘宝发货证书自动上传

Chrome 浏览器插件，用于在淘宝卖家中心「已卖出」页面自动识别待发货订单，批量上传证书。

## 功能流程

1. 打开 `https://myseller.taobao.com/home.htm/trade-platform/tp/sold`
2. 插件自动点击当前 Tab，等待 1 秒后扫描所有「发货」链接
3. 弹窗提示「识别到 xxx 个待发货，是否开始全部上传证书」
4. 点击「开始」后，逐个打开发货页面
5. 每个发货页内识别所有「上传证书」链接，逐个处理：
   - 点击「上传证书」
   - 等待 1 秒 → 点击新增 Tab 按钮
   - 等待 1 秒 → 自动生成证书图片并上传
   - 点击「确定」
6. 当前发货页全部完成后自动关闭，继续下一个

## 安装方法

**方式 A：CRX 一键安装（Chrome / 360 极速浏览器，推荐）**

1. 下载 `taobao-cert-uploader-vX.Y.Z-360-signed.crx`
2. 拖到浏览器 `chrome://extensions/` 页面（或 360 的 `se://extensions/`）
3. 提示「是否添加扩展程序」时点「添加」

**方式 B：zip 解压安装（任何 Chromium 内核浏览器都能用）**

1. 下载 `taobao-cert-uploader-vX.Y.Z-chrome.zip` 并解压到一个**长期不动的目录**
2. 打开 `chrome://extensions/`，开启右上角「开发者模式」
3. 点击「加载已解压的扩展程序」，选择刚才解压出来的目录

> ⚠️ **升级前先卸载旧版**。新版如果换了签名私钥，扩展 ID 就会变，
> 浏览器会把它当成「另一个扩展」而不是「同一个扩展的新版本」，
> 于是新旧两个同时存在、同时往页面里注入按钮和面板，行为会互相干扰。
> 卸载旧版会清掉它的本地记录（已完成订单、证书自增序号、白名单注入），
> 这是正常的——先卸载再装，比装完再debug省事得多。

## 打包 / 发版

```bash
# 打包（zip + 签名 crx + 发布前验签门禁）
node tools/pack.mjs                       # 版本号读 manifest.json
node tools/pack.mjs --version 1.4.0
node tools/pack.mjs --key ../tcb-keys/taobao-cert-sign-key.pem

# 单独校验一个 crx 是否符合 CRX3 规范（能不能装上看这个）
node tools/verify-crx.mjs dist/taobao-cert-uploader-v1.4.0-360-signed.crx
```

- 签名私钥**不进 git、也不随包分发**，放在 `../tcb-keys/` 或用 `TCB_SIGN_KEY` 指定。
- 签不出来 / 验不过就**直接报错退出**，不会再产出「装不上」的 crx。

## 变更记录

### v1.4.0

- **修复：发布的 360 CRX 装不上（"新版用不了"的真凶）**
  - 旧发布脚本在签名失败时会回退成手工拼的头 `Cr24 + [2,0,0,0,0,0,0,0] + zip`，
    该文件 CRX version = 2，Chromium 第一步校验就 `ERROR_HEADER_INVALID`，只能提示「无法安装」。
    现在**取消这个回退**：签不出来就直接失败退出。
  - 修复 `utils/crx-pack.js` 的签名载荷长度：应为 `LE32(len(signed_header_data))`，
    1.3.1 里误写成整个 `CrxFileHeader` 的长度，导致「以为签好了，其实验签不过」。
    现在打包时会**自检**签名，验不过就中止。
  - 新增 `tools/verify-crx.mjs` 发布前门禁，并在 `publish-extension.mjs` 里再过一道。
- **修复：跳过/失败过的订单第二遍扫描不再出现**
  - `noCertButtons`（本页 15 秒内没扫到证书按钮）不再计为完成，且完成判定统一收敛到
    `tcbIsCompletedShipRecord()`；历史遗留的「假完成」记录会在升级后一次性清理，
    订单重新回到扫描队列。
- **修复：证书上传不成功且看不出原因**
  - 上传控件选择器增加 4 级兜底（原来是一条十几层 `nth-child` 的绝对路径，改版即失效）。
  - 证书编号填入后**回读校验**，`input.files` 注入后**回读校验**。
  - 点「确定」前**等待按钮变为可点击**；按钮被禁用时抛错并说明缺了哪一项
    （证书编号为空 / 检测机构未选择 / 证书图片未挂载），不再「点了没反应却报成功」。
- **安全：不再随包分发签名私钥**（`utils/export-key.dat` 从安装包移除）。

## 证书图片格式

- 样式：白底 + 上下浅灰线 + Times New Roman 黑色衬线字体
- 内容：`prefixHead` + 2 位随机数字 + `prefixTail` + 5 位自增数字（如 `KLM07M1_00123`）
- 自增序号保存在插件本地存储（`certSerial`），跨订单连续递增

## 配置修改

编辑 `utils/cert-generator.js` 中的 `TCB.CERT_CONFIG`：

```javascript
TCB.CERT_CONFIG = {
  prefixHead: 'KLM',
  prefixTail: 'M1_',
  randomDigits: 2,
  startNumber: 1,
  numberLength: 5,
  institutionName: '深圳市中首珠宝检测有限公司',
  // ...
};
```

## 注意事项

- 需要保持登录淘宝卖家账号
- 页面 DOM 结构变化时可能需要更新 selector
- 建议先在少量订单上测试
- 上传过程中请勿手动操作相关标签页

## 日志与故障排查（v2.0 新增）

插件内置统一日志系统，所有操作、错误、心跳都会自动记录（内存 + storage 持久化）。

- **日志滚动清理**：日志自动按时间滚动，**默认只保留最近 7 天**（可通过 `TCBLogger.setRetentionDays(N)` 调整），同时受条数上限约束，避免长期运行导致存储膨胀。
- **导出日志包**：监控面板（已卖出页）或弹窗中点击「📦 导出日志包」，会打包下载一个 zip，包含：
  - `log-manifest.json`：导出时间、扩展版本、环境信息
  - `log-entries.json`：全部日志条目（时间/级别/上下文/详情）
  - `log-context.json`：运行现场快照（页面 URL、iframe 列表、证书按钮/编号元素统计）
  - `storage-snapshot.json`：storage 关键键值（完成记录、白名单、批次状态等，密码哈希已脱敏）
  - `batch-state.json`：当前批次状态（如批次进行中）
- **清理异常记录**：点击「🧹 清理异常记录」可删除完成记录中疑似误写的订单（有失败标记 / 未找到证书按钮但无上传 / 批量发货 / 心跳超时），删除后这些订单会重新出现在待扫描列表。

遇到问题时的操作建议：
1. 复现问题（尽量让异常发生一次）
2. 点击「📦 导出日志包」
3. 把 zip 发给开发者分析

## 文件结构

```
taobao-cert-uploader/
├── manifest.json
├── background.js          # 后台任务调度（多标签页管理）
├── content/
│   ├── cert-dialog.js     # 证书弹窗 iframe 内操作（新增 Tab/上传/填编号/确定）
│   ├── sold-page.js       # 已卖出页面逻辑
│   └── ship-page.js       # 发货详情页逻辑
├── utils/
│   ├── cert-generator.js  # 证书图片生成与上传
│   ├── helpers.js         # 通用工具函数
│   ├── logger.js          # 统一日志收集（v2.0 新增）
│   ├── log-export.js      # 日志包导出 + 异常记录清理（v2.0 新增）
│   └── shop-whitelist.js  # 店铺白名单与管理密码
└── styles/
    ├── modal.css          # 确认弹窗/监控面板样式
    └── popup.css          # 弹窗样式
```
