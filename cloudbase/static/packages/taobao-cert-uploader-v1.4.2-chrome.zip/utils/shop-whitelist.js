// 店铺白名单（可被 background importScripts 与 content script 共用）
var TCB_SHOP_WHITELIST = [
  '金街黄金珠宝店',
  '周韵福黄金珠宝',
  '周满福黄金珠宝',
  '周满福黄金 3D硬金足金水贝黄金珠宝批发',
  '周满福珠宝',
  '周满福珠宝黄金',
  '周满福黄金珠宝假一赔十',
];

// 注入 / 移除内置白名单存储键；管理密码默认 tcb@2026，可在弹窗中修改
var TCB_INJECTED_WHITELIST_KEY = 'tcbInjectedWhitelist';
var TCB_REMOVED_BUILTIN_KEY = 'tcbRemovedBuiltinWhitelist';
var TCB_ADMIN_PASSWORD_HASH_KEY = 'tcbAdminPasswordHash';
var TCB_DEFAULT_ADMIN_PASSWORD_HASH = '3b459c76';
var tcbRuntimeAdminPasswordHash = TCB_DEFAULT_ADMIN_PASSWORD_HASH;

function tcbNormalizeShopName(name) {
  return (name || '').replace(/\s+/g, '').trim();
}

/**
 * 一条「发货订单完成记录」是否算真的完成。
 *
 * 共用于 background(service worker) 与 content script：SW 通过 importScripts 引入本文件，
 * 页面侧由 helpers.js 转发成 TCB.isCompletedShipRecord。
 *
 * 旧版本在「本页 15 秒内没扫到证书按钮」时也会写一条完成记录
 * （noCertButtons=true、certUploaded=0），此后该订单被永久过滤掉，
 * 第二遍、第三遍扫描都不会再出现 —— 也就是「跳过之后第二遍再上传识别不到」。
 * 因此只有「没被跳过 + 没有失败 + 至少上传或确认过一个证书」才算完成。
 */
function tcbIsCompletedShipRecord(record) {
  if (!record) return false;
  if (Number(record.certFailed) > 0) return false;
  if (record.skipReason === 'heartbeat-timeout') return false;
  // 批量发货页确实无法上传证书，属确定结论，保留
  if (record.skipReason === 'batch-consign') return true;
  if (record.noCertButtons) return false;

  // 本单确实上传过证书 → 完成
  if (Number(record.certUploaded) > 0) return true;

  // v1.4.1 修复点：一张都没传时，只有「两次独立读弹窗都读到同一个编号，
  // 且编号就是本插件生成的格式」才算真的本来就传好了（certSkippedVerified）。
  // 1.2.x/1.3.x 写下的 {certUploaded:0, certSkipped:N} 记录既没有这个字段、
  // 也没有 reviewNeeded，会落到最后的 return false —— 于是订单重新回到扫描队列。
  if (Number(record.certSkippedVerified) > 0) return true;

  // 两次都能读到编号、但不是本插件格式：无法自动判定，计入「待人工确认」清单
  // （面板会提示，可用「🧹 清理异常记录」一键重新排队），本次按已处理避免每分钟重扫。
  if (record.reviewNeeded) return true;

  return false;
}

function tcbHashPassword(pwd) {
  var hash = 5381;
  var text = String(pwd || '');
  for (var i = 0; i < text.length; i++) {
    hash = ((hash << 5) + hash) ^ text.charCodeAt(i);
  }
  return (hash >>> 0).toString(16);
}

function tcbLoadAdminPasswordHash(callback) {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    tcbRuntimeAdminPasswordHash = TCB_DEFAULT_ADMIN_PASSWORD_HASH;
    if (callback) callback(tcbRuntimeAdminPasswordHash);
    return;
  }
  chrome.storage.local.get(TCB_ADMIN_PASSWORD_HASH_KEY, function (data) {
    tcbRuntimeAdminPasswordHash =
      data[TCB_ADMIN_PASSWORD_HASH_KEY] || TCB_DEFAULT_ADMIN_PASSWORD_HASH;
    if (callback) callback(tcbRuntimeAdminPasswordHash);
  });
}

function tcbVerifyAdminPassword(pwd) {
  return tcbHashPassword(pwd) === tcbRuntimeAdminPasswordHash;
}

function tcbChangeAdminPassword(oldPwd, newPwd, callback) {
  var nextPwd = String(newPwd || '');
  if (nextPwd.length < 4) {
    if (callback) callback({ ok: false, error: '新密码至少 4 位' });
    return;
  }
  if (!tcbVerifyAdminPassword(oldPwd)) {
    if (callback) callback({ ok: false, error: '原密码错误' });
    return;
  }
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    if (callback) callback({ ok: false, error: '无法保存新密码' });
    return;
  }
  var newHash = tcbHashPassword(nextPwd);
  var payload = {};
  payload[TCB_ADMIN_PASSWORD_HASH_KEY] = newHash;
  chrome.storage.local.set(payload, function () {
    tcbRuntimeAdminPasswordHash = newHash;
    if (callback) callback({ ok: true });
  });
}

function tcbGetBuiltInWhitelist() {
  return TCB_SHOP_WHITELIST.slice();
}

function tcbIsShopNameInList(name, list) {
  var normalized = tcbNormalizeShopName(name);
  if (!normalized || !list || !list.length) return false;
  return list.some(function (item) {
    return tcbNormalizeShopName(item) === normalized;
  });
}

function tcbIsBuiltinRemoved(name, removedBuiltinList) {
  return tcbIsShopNameInList(name, removedBuiltinList);
}

function tcbGetActiveBuiltinWhitelist(removedBuiltinList) {
  var removed = removedBuiltinList || [];
  return TCB_SHOP_WHITELIST.filter(function (item) {
    return !tcbIsBuiltinRemoved(item, removed);
  });
}

function tcbGetEffectiveWhitelist(injectedList, removedBuiltinList) {
  var seen = {};
  var result = [];
  function addItem(item) {
    var text = String(item || '').trim();
    if (!text) return;
    var key = tcbNormalizeShopName(text);
    if (!key || seen[key]) return;
    seen[key] = true;
    result.push(text);
  }
  tcbGetActiveBuiltinWhitelist(removedBuiltinList).forEach(addItem);
  (injectedList || []).forEach(addItem);
  return result;
}

function tcbIsShopNameAllowed(name, injectedList, removedBuiltinList) {
  if (tcbIsBuiltinRemoved(name, removedBuiltinList)) return false;
  if (tcbIsShopNameInList(name, TCB_SHOP_WHITELIST)) return true;
  if (injectedList && injectedList.length) {
    return tcbIsShopNameInList(name, injectedList);
  }
  return false;
}

function tcbReadStorageList(key, callback) {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    callback([]);
    return;
  }
  chrome.storage.local.get(key, function (data) {
    var list = data[key];
    callback(Array.isArray(list) ? list : []);
  });
}

function tcbWriteStorageList(key, list, callback) {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
    if (callback) callback(false);
    return;
  }
  var normalized = [];
  var seen = {};
  (list || []).forEach(function (item) {
    var text = String(item || '').trim();
    if (!text) return;
    var normalizedKey = tcbNormalizeShopName(text);
    if (!normalizedKey || seen[normalizedKey]) return;
    seen[normalizedKey] = true;
    normalized.push(text);
  });
  var payload = {};
  payload[key] = normalized;
  chrome.storage.local.set(payload, function () {
    if (callback) callback(true, normalized);
  });
}

function tcbGetInjectedWhitelist(callback) {
  tcbReadStorageList(TCB_INJECTED_WHITELIST_KEY, callback);
}

function tcbGetRemovedBuiltinWhitelist(callback) {
  tcbReadStorageList(TCB_REMOVED_BUILTIN_KEY, callback);
}

function tcbSetInjectedWhitelist(list, callback) {
  tcbWriteStorageList(TCB_INJECTED_WHITELIST_KEY, list, callback);
}

function tcbSetRemovedBuiltinWhitelist(list, callback) {
  tcbWriteStorageList(TCB_REMOVED_BUILTIN_KEY, list, callback);
}

function tcbGetWhitelistSnapshot(callback) {
  tcbGetInjectedWhitelist(function (injected) {
    tcbGetRemovedBuiltinWhitelist(function (removedBuiltin) {
      callback({
        injected: injected,
        removedBuiltin: removedBuiltin,
        activeBuiltin: tcbGetActiveBuiltinWhitelist(removedBuiltin),
        effective: tcbGetEffectiveWhitelist(injected, removedBuiltin),
      });
    });
  });
}

function tcbAddInjectedShop(name, callback) {
  var text = String(name || '').trim();
  if (!text) {
    if (callback) callback({ ok: false, error: '店铺名不能为空' });
    return;
  }
  tcbGetWhitelistSnapshot(function (snapshot) {
    if (tcbIsShopNameAllowed(text, snapshot.injected, snapshot.removedBuiltin)) {
      if (callback) callback({ ok: false, error: '该店铺已在白名单中' });
      return;
    }
    var list = snapshot.injected.slice();
    list.push(text);
    tcbSetInjectedWhitelist(list, function (ok, normalized) {
      if (!ok) {
        if (callback) callback({ ok: false, error: '保存失败' });
        return;
      }
      if (callback) callback({ ok: true, list: normalized, added: text });
    });
  });
}

function tcbRemoveInjectedShop(name, callback) {
  var target = tcbNormalizeShopName(name);
  if (!target) {
    if (callback) callback({ ok: false, error: '店铺名不能为空' });
    return;
  }
  tcbGetInjectedWhitelist(function (list) {
    var next = list.filter(function (item) {
      return tcbNormalizeShopName(item) !== target;
    });
    if (next.length === list.length) {
      if (callback) callback({ ok: false, error: '未找到该注入店铺' });
      return;
    }
    tcbSetInjectedWhitelist(next, function (ok, normalized) {
      if (!ok) {
        if (callback) callback({ ok: false, error: '保存失败' });
        return;
      }
      if (callback) callback({ ok: true, list: normalized, removed: name });
    });
  });
}

function tcbRemoveBuiltinShop(name, callback) {
  var text = String(name || '').trim();
  if (!text) {
    if (callback) callback({ ok: false, error: '店铺名不能为空' });
    return;
  }
  if (!tcbIsShopNameInList(text, TCB_SHOP_WHITELIST)) {
    if (callback) callback({ ok: false, error: '该店铺不在内置白名单中' });
    return;
  }
  tcbGetRemovedBuiltinWhitelist(function (list) {
    if (tcbIsBuiltinRemoved(text, list)) {
      if (callback) callback({ ok: false, error: '该内置店铺已移除' });
      return;
    }
    var next = list.slice();
    next.push(text);
    tcbSetRemovedBuiltinWhitelist(next, function (ok, normalized) {
      if (!ok) {
        if (callback) callback({ ok: false, error: '保存失败' });
        return;
      }
      if (callback) callback({ ok: true, list: normalized, removed: text });
    });
  });
}

function tcbRestoreBuiltinShop(name, callback) {
  var target = tcbNormalizeShopName(name);
  if (!target) {
    if (callback) callback({ ok: false, error: '店铺名不能为空' });
    return;
  }
  tcbGetRemovedBuiltinWhitelist(function (list) {
    var next = list.filter(function (item) {
      return tcbNormalizeShopName(item) !== target;
    });
    if (next.length === list.length) {
      if (callback) callback({ ok: false, error: '未找到该已移除内置店铺' });
      return;
    }
    tcbSetRemovedBuiltinWhitelist(next, function (ok, normalized) {
      if (!ok) {
        if (callback) callback({ ok: false, error: '保存失败' });
        return;
      }
      if (callback) callback({ ok: true, list: normalized, restored: name });
    });
  });
}

function tcbBuildShopWhitelistSource(effectiveList, passwordHash) {
  var hash = passwordHash || tcbRuntimeAdminPasswordHash || TCB_DEFAULT_ADMIN_PASSWORD_HASH;
  var lines = effectiveList.map(function (item) {
    return "  '" + String(item).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "',";
  });
  return [
    '// 店铺白名单（可被 background importScripts 与 content script 共用）',
    'var TCB_SHOP_WHITELIST = [',
    lines.join('\n'),
    '];',
    '',
    '// 注入 / 移除内置白名单存储键；管理密码默认 tcb@2026，可在弹窗中修改',
    "var TCB_INJECTED_WHITELIST_KEY = 'tcbInjectedWhitelist';",
    "var TCB_REMOVED_BUILTIN_KEY = 'tcbRemovedBuiltinWhitelist';",
    "var TCB_ADMIN_PASSWORD_HASH_KEY = 'tcbAdminPasswordHash';",
    "var TCB_DEFAULT_ADMIN_PASSWORD_HASH = '" + hash + "';",
    'var tcbRuntimeAdminPasswordHash = TCB_DEFAULT_ADMIN_PASSWORD_HASH;',
    '',
    'function tcbNormalizeShopName(name) {',
    "  return (name || '').replace(/\\s+/g, '').trim();",
    '}',
    '',
    'function tcbHashPassword(pwd) {',
    '  var hash = 5381;',
    "  var text = String(pwd || '');",
    '  for (var i = 0; i < text.length; i++) {',
    '    hash = ((hash << 5) + hash) ^ text.charCodeAt(i);',
    '  }',
    '  return (hash >>> 0).toString(16);',
    '}',
    '',
    'function tcbLoadAdminPasswordHash(callback) {',
    "  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {",
    '    tcbRuntimeAdminPasswordHash = TCB_DEFAULT_ADMIN_PASSWORD_HASH;',
    '    if (callback) callback(tcbRuntimeAdminPasswordHash);',
    '    return;',
    '  }',
    '  chrome.storage.local.get(TCB_ADMIN_PASSWORD_HASH_KEY, function (data) {',
    '    tcbRuntimeAdminPasswordHash =',
    '      data[TCB_ADMIN_PASSWORD_HASH_KEY] || TCB_DEFAULT_ADMIN_PASSWORD_HASH;',
    '    if (callback) callback(tcbRuntimeAdminPasswordHash);',
    '  });',
    '}',
    '',
    'function tcbVerifyAdminPassword(pwd) {',
    '  return tcbHashPassword(pwd) === tcbRuntimeAdminPasswordHash;',
    '}',
    '',
    'function tcbGetBuiltInWhitelist() {',
    '  return TCB_SHOP_WHITELIST.slice();',
    '}',
    '',
    'function tcbIsShopNameInList(name, list) {',
    '  var normalized = tcbNormalizeShopName(name);',
    '  if (!normalized || !list || !list.length) return false;',
    '  return list.some(function (item) {',
    '    return tcbNormalizeShopName(item) === normalized;',
    '  });',
    '}',
    '',
    'function tcbIsBuiltinRemoved(name, removedBuiltinList) {',
    '  return tcbIsShopNameInList(name, removedBuiltinList);',
    '}',
    '',
    'function tcbGetActiveBuiltinWhitelist(removedBuiltinList) {',
    '  var removed = removedBuiltinList || [];',
    '  return TCB_SHOP_WHITELIST.filter(function (item) {',
    '    return !tcbIsBuiltinRemoved(item, removed);',
    '  });',
    '}',
    '',
    'function tcbGetEffectiveWhitelist(injectedList, removedBuiltinList) {',
    '  var seen = {};',
    '  var result = [];',
    '  function addItem(item) {',
    "    var text = String(item || '').trim();",
    '    if (!text) return;',
    '    var key = tcbNormalizeShopName(text);',
    '    if (!key || seen[key]) return;',
    '    seen[key] = true;',
    '    result.push(text);',
    '  }',
    '  tcbGetActiveBuiltinWhitelist(removedBuiltinList).forEach(addItem);',
    '  (injectedList || []).forEach(addItem);',
    '  return result;',
    '}',
    '',
    'function tcbIsShopNameAllowed(name, injectedList, removedBuiltinList) {',
    '  if (tcbIsBuiltinRemoved(name, removedBuiltinList)) return false;',
    '  if (tcbIsShopNameInList(name, TCB_SHOP_WHITELIST)) return true;',
    '  if (injectedList && injectedList.length) {',
    '    return tcbIsShopNameInList(name, injectedList);',
    '  }',
    '  return false;',
    '}',
    '',
    'function tcbReadStorageList(key, callback) {',
    "  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {",
    '    callback([]);',
    '    return;',
    '  }',
    '  chrome.storage.local.get(key, function (data) {',
    '    var list = data[key];',
    '    callback(Array.isArray(list) ? list : []);',
    '  });',
    '}',
    '',
    'function tcbWriteStorageList(key, list, callback) {',
    "  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {",
    '    if (callback) callback(false);',
    '    return;',
    '  }',
    '  var normalized = [];',
    '  var seen = {};',
    '  (list || []).forEach(function (item) {',
    "    var text = String(item || '').trim();",
    '    if (!text) return;',
    '    var normalizedKey = tcbNormalizeShopName(text);',
    '    if (!normalizedKey || seen[normalizedKey]) return;',
    '    seen[normalizedKey] = true;',
    '    normalized.push(text);',
    '  });',
    '  var payload = {};',
    '  payload[key] = normalized;',
    '  chrome.storage.local.set(payload, function () {',
    '    if (callback) callback(true, normalized);',
    '  });',
    '}',
    '',
    'function tcbGetInjectedWhitelist(callback) {',
    '  tcbReadStorageList(TCB_INJECTED_WHITELIST_KEY, callback);',
    '}',
    '',
    'function tcbGetRemovedBuiltinWhitelist(callback) {',
    '  tcbReadStorageList(TCB_REMOVED_BUILTIN_KEY, callback);',
    '}',
    '',
    'function tcbSetInjectedWhitelist(list, callback) {',
    '  tcbWriteStorageList(TCB_INJECTED_WHITELIST_KEY, list, callback);',
    '}',
    '',
    'function tcbSetRemovedBuiltinWhitelist(list, callback) {',
    '  tcbWriteStorageList(TCB_REMOVED_BUILTIN_KEY, list, callback);',
    '}',
    '',
    'function tcbGetWhitelistSnapshot(callback) {',
    '  tcbGetInjectedWhitelist(function (injected) {',
    '    tcbGetRemovedBuiltinWhitelist(function (removedBuiltin) {',
    '      callback({',
    '        injected: injected,',
    '        removedBuiltin: removedBuiltin,',
    '        activeBuiltin: tcbGetActiveBuiltinWhitelist(removedBuiltin),',
    '        effective: tcbGetEffectiveWhitelist(injected, removedBuiltin),',
    '      });',
    '    });',
    '  });',
    '}',
    '',
    'function tcbAddInjectedShop(name, callback) {',
    "  var text = String(name || '').trim();",
    '  if (!text) {',
    "    if (callback) callback({ ok: false, error: '店铺名不能为空' });",
    '    return;',
    '  }',
    '  tcbGetWhitelistSnapshot(function (snapshot) {',
    '    if (tcbIsShopNameAllowed(text, snapshot.injected, snapshot.removedBuiltin)) {',
    "      if (callback) callback({ ok: false, error: '该店铺已在白名单中' });",
    '      return;',
    '    }',
    '    var list = snapshot.injected.slice();',
    '    list.push(text);',
    '    tcbSetInjectedWhitelist(list, function (ok, normalized) {',
    '      if (!ok) {',
    "        if (callback) callback({ ok: false, error: '保存失败' });",
    '        return;',
    '      }',
    "      if (callback) callback({ ok: true, list: normalized, added: text });",
    '    });',
    '  });',
    '}',
    '',
    'function tcbRemoveInjectedShop(name, callback) {',
    '  var target = tcbNormalizeShopName(name);',
    '  if (!target) {',
    "    if (callback) callback({ ok: false, error: '店铺名不能为空' });",
    '    return;',
    '  }',
    '  tcbGetInjectedWhitelist(function (list) {',
    '    var next = list.filter(function (item) {',
    '      return tcbNormalizeShopName(item) !== target;',
    '    });',
    '    if (next.length === list.length) {',
    "      if (callback) callback({ ok: false, error: '未找到该注入店铺' });",
    '      return;',
    '    }',
    '    tcbSetInjectedWhitelist(next, function (ok, normalized) {',
    '      if (!ok) {',
    "        if (callback) callback({ ok: false, error: '保存失败' });",
    '        return;',
    '      }',
    "      if (callback) callback({ ok: true, list: normalized, removed: name });",
    '    });',
    '  });',
    '}',
    '',
    'function tcbRemoveBuiltinShop(name, callback) {',
    "  var text = String(name || '').trim();",
    '  if (!text) {',
    "    if (callback) callback({ ok: false, error: '店铺名不能为空' });",
    '    return;',
    '  }',
    '  if (!tcbIsShopNameInList(text, TCB_SHOP_WHITELIST)) {',
    "    if (callback) callback({ ok: false, error: '该店铺不在内置白名单中' });",
    '    return;',
    '  }',
    '  tcbGetRemovedBuiltinWhitelist(function (list) {',
    '    if (tcbIsBuiltinRemoved(text, list)) {',
    "      if (callback) callback({ ok: false, error: '该内置店铺已移除' });",
    '      return;',
    '    }',
    '    var next = list.slice();',
    '    next.push(text);',
    '    tcbSetRemovedBuiltinWhitelist(next, function (ok, normalized) {',
    '      if (!ok) {',
    "        if (callback) callback({ ok: false, error: '保存失败' });",
    '        return;',
    '      }',
    "      if (callback) callback({ ok: true, list: normalized, removed: text });",
    '    });',
    '  });',
    '}',
    '',
    'function tcbRestoreBuiltinShop(name, callback) {',
    '  var target = tcbNormalizeShopName(name);',
    '  if (!target) {',
    "    if (callback) callback({ ok: false, error: '店铺名不能为空' });",
    '    return;',
    '  }',
    '  tcbGetRemovedBuiltinWhitelist(function (list) {',
    '    var next = list.filter(function (item) {',
    '      return tcbNormalizeShopName(item) !== target;',
    '    });',
    '    if (next.length === list.length) {',
    "      if (callback) callback({ ok: false, error: '未找到该已移除内置店铺' });",
    '      return;',
    '    }',
    '    tcbSetRemovedBuiltinWhitelist(next, function (ok, normalized) {',
    '      if (!ok) {',
    "        if (callback) callback({ ok: false, error: '保存失败' });",
    '        return;',
    '      }',
    "      if (callback) callback({ ok: true, list: normalized, restored: name });",
    '    });',
    '  });',
    '}',
    '',
  ].join('\n');
}
