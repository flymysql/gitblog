# 淘宝发货证书自动上传

Chrome 浏览器插件，用于在淘宝卖家中心「已卖出」页面自动识别待发货订单，批量上传证书。

## 功能流程

1. 打开 `https://myseller.taobao.com/home.htm/trade-platform/tp/sold`
2. 插件自动点击当前 Tab，等待 1 秒后扫描所有「发货」链接
3. 弹窗提示「识别到 xxx 个待发货，是否开始全部上传证书」
4. 点击「开始」后，逐个打开发货页面
5. 每个发货页内识别所有「上传证书」链接，逐个处理：
   - 点击「上传证书」
   - 等待 1 秒 → 点击新增 Tab 按钮
   - 等待 1 秒 → 自动生成证书图片并上传
   - 点击「确定」
6. 当前发货页全部完成后自动关闭，继续下一个

## 安装方法

1. 打开 Chrome，访问 `chrome://extensions/`
2. 开启右上角「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择本目录：`/Users/jimmy/projects/taobao-cert-uploader`

## 证书图片格式

- 样式：白底 + 上下浅灰线 + Times New Roman 黑色衬线字体
- 内容：`8位随机字符` + `3位自增数字`（如 `KL04Q651554`）
- 自增序号保存在插件本地存储，跨订单连续递增

## 配置修改

编辑 `utils/cert-generator.js` 中的 `TCB.CERT_CONFIG`：

```javascript
TCB.CERT_CONFIG = {
  prefixLength: 8,    // 前缀随机长度
  startNumber: 554,   // 起始序号
  numberLength: 3,    // 后缀数字位数
  // ...
};
```

## 注意事项

- 需要保持登录淘宝卖家账号
- 页面 DOM 结构变化时可能需要更新 selector
- 建议先在少量订单上测试
- 上传过程中请勿手动操作相关标签页

## 日志与故障排查（v2.0 新增）

插件内置统一日志系统，所有操作、错误、心跳都会自动记录（内存 + storage 持久化）。

- **日志滚动清理**：日志自动按时间滚动，**默认只保留最近 7 天**（可通过 `TCBLogger.setRetentionDays(N)` 调整），同时受条数上限约束，避免长期运行导致存储膨胀。
- **导出日志包**：监控面板（已卖出页）或弹窗中点击「📦 导出日志包」，会打包下载一个 zip，包含：
  - `log-manifest.json`：导出时间、扩展版本、环境信息
  - `log-entries.json`：全部日志条目（时间/级别/上下文/详情）
  - `log-context.json`：运行现场快照（页面 URL、iframe 列表、证书按钮/编号元素统计）
  - `storage-snapshot.json`：storage 关键键值（完成记录、白名单、批次状态等，密码哈希已脱敏）
  - `batch-state.json`：当前批次状态（如批次进行中）
- **清理异常记录**：点击「🧹 清理异常记录」可删除完成记录中疑似误写的订单（有失败标记 / 未找到证书按钮但无上传 / 批量发货 / 心跳超时），删除后这些订单会重新出现在待扫描列表。

遇到问题时的操作建议：
1. 复现问题（尽量让异常发生一次）
2. 点击「📦 导出日志包」
3. 把 zip 发给开发者分析

## 文件结构

```
taobao-cert-uploader/
├── manifest.json
├── background.js          # 后台任务调度（多标签页管理）
├── content/
│   ├── cert-dialog.js     # 证书弹窗 iframe 内操作（新增 Tab/上传/填编号/确定）
│   ├── sold-page.js       # 已卖出页面逻辑
│   └── ship-page.js       # 发货详情页逻辑
├── utils/
│   ├── cert-generator.js  # 证书图片生成与上传
│   ├── helpers.js         # 通用工具函数
│   ├── logger.js          # 统一日志收集（v2.0 新增）
│   ├── log-export.js      # 日志包导出 + 异常记录清理（v2.0 新增）
│   └── shop-whitelist.js  # 店铺白名单与管理密码
└── styles/
    ├── modal.css          # 确认弹窗/监控面板样式
    └── popup.css          # 弹窗样式
```
