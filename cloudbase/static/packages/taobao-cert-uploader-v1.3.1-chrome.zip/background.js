importScripts(
  'utils/shop-whitelist.js',
  'utils/zip-store.js',
  'utils/crx-pack.js',
  'utils/export-package.js',
  'utils/logger.js',
  'utils/log-export.js',
  'utils/updater.js'
);

const SOLD_PAGE_URL = 'https://myseller.taobao.com/home.htm/trade-platform/tp/sold';
const SHIP_RECORD_KEY = 'tcbCompletedShipOrders';
const BATCH_STATE_KEY = 'tcbBatchState';
const SHIP_PAGE_TIMEOUT_MS = 3 * 60 * 1000;
const HEARTBEAT_IDLE_TIMEOUT_MS = 3 * 60 * 1000;
const PROGRESS_WATCH_INTERVAL_MS = 30000;
const ADMIN_SESSION_MS = 30 * 60 * 1000;
const ADMIN_SESSION_KEY = 'tcbAdminSessionExpiry';

let injectedWhitelistCache = [];
let removedBuiltinCache = [];
let adminSessionExpiry = 0;

function readAdminSessionExpiry() {
  return new Promise((resolve) => {
    const finish = (expiry) => {
      adminSessionExpiry = Number(expiry) || 0;
      resolve(isAdminAuthenticated());
    };
    if (chrome.storage.session) {
      chrome.storage.session.get(ADMIN_SESSION_KEY, (data) => finish(data[ADMIN_SESSION_KEY]));
      return;
    }
    chrome.storage.local.get(ADMIN_SESSION_KEY, (data) => finish(data[ADMIN_SESSION_KEY]));
  });
}

function persistAdminSession(expiry) {
  adminSessionExpiry = Number(expiry) || 0;
  const payload = { [ADMIN_SESSION_KEY]: adminSessionExpiry };
  if (adminSessionExpiry > Date.now()) {
    if (chrome.storage.session) {
      chrome.storage.session.set(payload);
      return;
    }
    chrome.storage.local.set(payload);
    return;
  }
  if (chrome.storage.session) {
    chrome.storage.session.remove(ADMIN_SESSION_KEY);
    return;
  }
  chrome.storage.local.remove(ADMIN_SESSION_KEY);
}

function isShopAllowedBg(name) {
  return tcbIsShopNameAllowed(name, injectedWhitelistCache, removedBuiltinCache);
}

// 从后台 API 拉取白名单（在线管理实时生效），失败回退本地
const CLOUD_WHITELIST_API = 'https://gitbolg-d7gmnsrw46e011706-1256429518.ap-shanghai.app.tcloudbase.com/tcb-admin/public-whitelist';
function loadWhitelistCachesBg() {
  return new Promise((resolve) => {
    const finishLocal = () => {
      tcbGetWhitelistSnapshot((snapshot) => {
        injectedWhitelistCache = snapshot.injected || [];
        removedBuiltinCache = snapshot.removedBuiltin || [];
        resolve({ ...snapshot, source: 'local' });
      });
    };
    fetch(CLOUD_WHITELIST_API, { method: 'GET' })
      .then((resp) => resp.json().catch(() => ({})))
      .then((data) => {
        if (data && data.ok && Array.isArray(data.list) && data.list.length) {
          injectedWhitelistCache = data.list;
          removedBuiltinCache = [];
          bglog(`☁️ 白名单已从后台获取（${data.list.length} 个店铺）`);
          resolve({ injected: data.list, removedBuiltin: [], activeBuiltin: data.list, effective: data.list, source: 'cloud' });
        } else {
          bglog('⚠️ 后台白名单为空，回退本地');
          finishLocal();
        }
      })
      .catch((err) => {
        bglog('⚠️ 后台白名单获取失败，回退本地:', err.message);
        finishLocal();
      });
  });
}

function afterWhitelistChanged(sendResponse, result) {
  if (!result.ok) {
    sendResponse(result);
    return;
  }
  loadWhitelistCachesBg().then(() => {
    notifyWhitelistUpdated();
    sendResponse(result);
  });
}

function isAdminAuthenticated() {
  return Date.now() < adminSessionExpiry;
}

function setAdminSession() {
  persistAdminSession(Date.now() + ADMIN_SESSION_MS);
}

function clearAdminSession() {
  persistAdminSession(0);
}

function ensureAdminAuthenticated(sendResponse) {
  return readAdminSessionExpiry().then((authed) => {
    if (!authed) {
      sendResponse({
        ok: false,
        error: '会话已过期，请重新输入管理密码',
        needLogin: true,
      });
      return false;
    }
    return true;
  });
}

function loadInjectedWhitelistBg() {
  return loadWhitelistCachesBg().then((snapshot) => snapshot.injected || []);
}

function notifyWhitelistUpdated() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (!tab.id) return;
      chrome.tabs.sendMessage(tab.id, { action: 'WHITELIST_UPDATED' }).catch(() => {});
    });
  });
}

loadInjectedWhitelistBg();
readAdminSessionExpiry();
tcbLoadAdminPasswordHash();

// 启动自动更新检查（整点 + SW 启动后 10 秒首次检查）
if (self.TCBUpdater && typeof self.TCBUpdater.startAutoCheck === 'function') {
  self.TCBUpdater.startAutoCheck();
  bglog('🔄 自动更新检查已启动（整点检查后台最新版本）');
}

// 启动心跳上报（后台在线状态，每 5 分钟）
startHeartbeatReporting();
bglog('💓 心跳上报已启动（每 5 分钟上报店铺在线状态）');

// 安装/升级后补报历史统计（只执行一次，避免每次启动重复上报）
chrome.storage.local.get(HISTORY_SYNC_KEY, (data) => {
  if (!data[HISTORY_SYNC_KEY]) {
    bglog('🆕 检测到新安装/升级，准备补报历史统计数据');
    // 等 SW 就绪后执行（延迟 3 秒，避免启动竞争）
    setTimeout(syncHistoryToServer, 3000);
  } else {
    bglog('ℹ️ 历史数据已同步过，跳过补报');
  }
});

// background 环境标记（日志上下文）
if (typeof self !== 'undefined' && self.TCBLogger) {
  self.TCBLogger.setEnv('background');
}

function bglog(...args) {
  const d = new Date();
  const t = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
  console.log(`[证书上传·BG ${t}]`, ...args);
  if (self.TCBLogger) {
    self.TCBLogger.log('log', 'bg', args.length === 1 ? args[0] : args);
  }
}

let batchState = {
  active: false,
  paused: false,
  soldTabId: null,
  shipUrls: [],
  currentIndex: 0,
  processingTabId: null,
  skippedAtStart: 0,
  lastProgressAt: 0,
  lastHeartbeatStage: '',
  lastHeartbeatDetail: '',
  watchMode: false,
  sessionOrdersDone: 0,
  sessionCertsUploaded: 0,
  sessionCertsSkipped: 0,
  sessionCertsFailed: 0,
};

let progressWatchInterval = null;
let lastProgressAt = 0;
let hydrated = false;

// MV3 的 Service Worker 空闲会被回收，内存状态丢失。
// 将批次状态持久化到 storage，重启后可恢复，避免「暂停后点继续没反应」。
function persistBatchState() {
  try {
    chrome.storage.local.set({ [BATCH_STATE_KEY]: { ...batchState } });
  } catch (e) {
    /* ignore */
  }
}

function hydrateBatchState() {
  if (hydrated) return Promise.resolve();
  hydrated = true;
  return new Promise((resolve) => {
    chrome.storage.local.get(BATCH_STATE_KEY, (data) => {
      const saved = data[BATCH_STATE_KEY];
      if (saved && saved.active) {
        batchState = { ...batchState, ...saved };
        lastProgressAt = batchState.lastProgressAt || 0;
        bglog(
          `♻️ 从存储恢复批次状态：${batchState.currentIndex}/${batchState.shipUrls.length}，paused=${batchState.paused}`
        );
        if (batchState.processingTabId && batchState.shipUrls[batchState.currentIndex]) {
          startProgressWatch(
            batchState.processingTabId,
            batchState.shipUrls[batchState.currentIndex],
            batchState.currentIndex,
            batchState.shipUrls.length
          );
        }
      }
      resolve();
    });
  });
}

function shipUrlKey(url) {
  try {
    const u = new URL(url);
    const orderId =
      u.searchParams.get('orderId') ||
      u.searchParams.get('bizOrderId') ||
      u.searchParams.get('tradeId') ||
      u.searchParams.get('tid');
    if (orderId) return `order:${orderId}`;
    u.hash = '';
    ['spm', 'utparam', 'scm', 'from'].forEach((p) => u.searchParams.delete(p));
    return `url:${u.origin}${u.pathname}${u.search}`;
  } catch {
    return `url:${url}`;
  }
}

function getCompletedShipRecords() {
  return new Promise((resolve) => {
    chrome.storage.local.get(SHIP_RECORD_KEY, (data) => {
      resolve(data[SHIP_RECORD_KEY] || {});
    });
  });
}

function markShipCompleted(url, meta = {}) {
  const key = shipUrlKey(url);
  return new Promise((resolve) => {
    chrome.storage.local.get(SHIP_RECORD_KEY, (data) => {
      const records = data[SHIP_RECORD_KEY] || {};
      records[key] = {
        url,
        completedAt: Date.now(),
        ...meta,
      };
      chrome.storage.local.set({ [SHIP_RECORD_KEY]: records }, () => resolve(key));
    });
  });
}

function clearShipPageTimer() {
  stopProgressWatch();
}

function stopProgressWatch() {
  if (progressWatchInterval) {
    clearInterval(progressWatchInterval);
    progressWatchInterval = null;
  }
}

function touchTaskProgress(meta = {}) {
  lastProgressAt = Date.now();
  if (meta.stage) batchState.lastHeartbeatStage = meta.stage;
  if (meta.detail !== undefined) batchState.lastHeartbeatDetail = meta.detail;
  batchState.lastProgressAt = lastProgressAt;
  persistBatchState();
}

function forwardHeartbeatToSold(payload) {
  if (!batchState.soldTabId) return;
  chrome.tabs
    .sendMessage(batchState.soldTabId, {
      action: 'TASK_HEARTBEAT',
      current: batchState.currentIndex,
      total: batchState.shipUrls.length,
      ...payload,
    })
    .catch(() => {});
}

function startProgressWatch(tabId, url, index, total) {
  stopProgressWatch();
  touchTaskProgress({ stage: '打开发货页', detail: `第 ${index + 1}/${total} 个订单` });
  forwardHeartbeatToSold({
    shipIndex: index + 1,
    shipTotal: total,
    stage: '打开发货页',
    detail: `第 ${index + 1}/${total} 个订单`,
  });

  progressWatchInterval = setInterval(() => {
    if (!batchState.active || batchState.paused || batchState.processingTabId !== tabId) return;
    if (Date.now() - lastProgressAt < HEARTBEAT_IDLE_TIMEOUT_MS) return;

    stopProgressWatch();
    bglog(
      `⏱ 心跳超时（${HEARTBEAT_IDLE_TIMEOUT_MS / 1000}s 无进展），跳过: ${url}`,
      batchState.lastHeartbeatStage
    );
    finishSkippedShipOrder({
      url,
      index,
      total,
      tabId,
      skipReason: 'heartbeat-timeout',
      skipMessage: `超过 3 分钟无进展（停在：${batchState.lastHeartbeatStage || '未知'}）`,
      markCompleted: false,
      timedOut: true,
    });
  }, PROGRESS_WATCH_INTERVAL_MS);
}

function startShipPageTimer(tabId, url, index, total) {
  startProgressWatch(tabId, url, index, total);
}

function resetBatch() {
  clearShipPageTimer();
  batchState = {
    active: false,
    paused: false,
    soldTabId: null,
    shipUrls: [],
    currentIndex: 0,
    processingTabId: null,
    skippedAtStart: 0,
    lastProgressAt: 0,
    lastHeartbeatStage: '',
    lastHeartbeatDetail: '',
    watchMode: false,
    sessionOrdersDone: 0,
    sessionCertsUploaded: 0,
    sessionCertsSkipped: 0,
    sessionCertsFailed: 0,
  };
  lastProgressAt = 0;
  chrome.storage.local.remove(BATCH_STATE_KEY);
}

function notifySold(action, extra = {}) {
  if (!batchState.soldTabId) return;
  chrome.tabs.sendMessage(batchState.soldTabId, { action, ...extra }).catch(() => {});
}

function waitForTabComplete(tabId, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error(`标签页 ${tabId} 加载超时`));
    }, timeout);

    function listener(updatedTabId, info) {
      if (updatedTabId === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }

    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) {
        clearTimeout(timer);
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (tab.status === 'complete') {
        clearTimeout(timer);
        resolve();
        return;
      }
      chrome.tabs.onUpdated.addListener(listener);
    });
  });
}

function isBatchConsignPage(url) {
  if (!url) return false;
  try {
    const u = new URL(url);
    return u.hostname.includes('myseller.taobao.com') && u.pathname.includes('/batch-consign');
  } catch {
    return url.includes('batch-consign');
  }
}

function getTabUrl(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(tab.url || '');
    });
  });
}

function finishSkippedShipOrder({
  url,
  index,
  total,
  tabId,
  skipReason,
  skipMessage,
  markCompleted = true,
  timedOut = false,
}) {
  clearShipPageTimer();
  if (tabId) {
    chrome.tabs.remove(tabId).catch(() => {});
  }

  bglog(`⏭ 跳过订单 (${index + 1}/${total}): ${skipMessage || skipReason} — ${url}`);

  if (markCompleted) {
    markShipCompleted(url, {
      certTotal: 0,
      certUploaded: 0,
      certSkipped: 0,
      noCertButtons: true,
      skipReason,
    }).then((key) => bglog(`📝 已记录跳过订单: ${key}`));
  }

  batchState.currentIndex += 1;
  batchState.processingTabId = null;
  persistBatchState();

  if (batchState.soldTabId) {
    chrome.tabs
      .sendMessage(batchState.soldTabId, {
        action: 'SHIP_PROGRESS',
        current: batchState.currentIndex,
        total: batchState.shipUrls.length,
        shipIndex: index + 1,
        shipTotal: total,
        certTotal: 0,
        certUploaded: 0,
        certSkipped: 0,
        certFailed: 0,
        noCertButtons: true,
        skipReason,
        skipMessage,
        timedOut,
        paused: batchState.paused,
      })
      .catch(() => {});
  }

  if (batchState.paused) {
    notifySold('BATCH_PAUSED', {
      current: batchState.currentIndex,
      total: batchState.shipUrls.length,
    });
    return;
  }
  setTimeout(openNextShipTab, 500);
}

async function openNextShipTab() {
  if (!batchState.active) {
    bglog('批次未激活，停止');
    return;
  }

  if (batchState.paused) {
    bglog('⏸ 批次已暂停，等待恢复');
    notifySold('BATCH_PAUSED', {
      current: batchState.currentIndex,
      total: batchState.shipUrls.length,
    });
    return;
  }

  if (batchState.currentIndex >= batchState.shipUrls.length) {
    bglog(`✅ 全部 ${batchState.shipUrls.length} 个发货订单处理完成`);
    const soldTabId = batchState.soldTabId;
    const total = batchState.shipUrls.length;
    const watchMode = batchState.watchMode;
    const sessionStats = {
      orders: batchState.sessionOrdersDone,
      uploaded: batchState.sessionCertsUploaded,
      skipped: batchState.sessionCertsSkipped,
      failed: batchState.sessionCertsFailed,
    };
    resetBatch();
    if (soldTabId) {
      chrome.tabs
        .sendMessage(soldTabId, {
          action: 'BATCH_COMPLETE',
          total,
          watchMode,
          sessionStats,
        })
        .catch(() => {});
    }
    return;
  }

  const url = batchState.shipUrls[batchState.currentIndex];
  const index = batchState.currentIndex;
  const total = batchState.shipUrls.length;

  if (isBatchConsignPage(url)) {
    finishSkippedShipOrder({
      url,
      index,
      total,
      skipReason: 'batch-consign',
      skipMessage: '批量发货页，已自动跳过',
    });
    return;
  }

  bglog(`📂 打开第 ${index + 1}/${total} 个发货页（后台）: ${url}`);

  // active: false 让新标签页在后台打开，不抢占焦点，用户停留在待发货页
  chrome.tabs.create({ url, active: false }, async (tab) => {
    if (chrome.runtime.lastError || !tab?.id) {
      bglog('❌ 打开发货页失败', chrome.runtime.lastError);
      batchState.currentIndex += 1;
      openNextShipTab();
      return;
    }

    batchState.processingTabId = tab.id;
    persistBatchState();
    bglog(`新标签页已创建 tabId=${tab.id}，等待加载完成...`);

    try {
      await waitForTabComplete(tab.id);
      const actualUrl = await getTabUrl(tab.id);
      if (isBatchConsignPage(actualUrl)) {
        bglog(`⚠️ 打开后为批量发货页，自动跳过: ${actualUrl}`);
        finishSkippedShipOrder({
          url,
          index,
          total,
          tabId: tab.id,
          skipReason: 'batch-consign',
          skipMessage: '打开后为批量发货页，已自动跳过',
        });
        return;
      }

      bglog(`tabId=${tab.id} 加载完成 (${actualUrl})，再等 1.5s 后发送 PROCESS_SHIP_PAGE`);
      await new Promise((r) => setTimeout(r, 1500));

      chrome.tabs.sendMessage(
        tab.id,
        {
          action: 'PROCESS_SHIP_PAGE',
          shipIndex: index + 1,
          shipTotal: total,
          shipUrl: url,
        },
        (resp) => {
          if (chrome.runtime.lastError) {
            bglog(`⚠️ 向 tabId=${tab.id} 发送消息失败:`, chrome.runtime.lastError.message);
            getTabUrl(tab.id)
              .then((loadedUrl) => {
                if (isBatchConsignPage(loadedUrl)) {
                  finishSkippedShipOrder({
                    url,
                    index,
                    total,
                    tabId: tab.id,
                    skipReason: 'batch-consign',
                    skipMessage: '批量发货页无法处理证书，已自动跳过',
                  });
                } else {
                  bglog(`⚠️ 消息发送失败但非批量发货页: ${loadedUrl}，本单跳过（将在下次扫描重试）`);
                  finishSkippedShipOrder({
                    url,
                    index,
                    total,
                    tabId: tab.id,
                    skipReason: 'send-message-failed',
                    skipMessage: '内容脚本未响应，本单跳过',
                    markCompleted: false,
                  });
                }
              })
              .catch(() => {});
          } else {
            bglog(`tabId=${tab.id} 已确认接收 PROCESS_SHIP_PAGE:`, resp);
          }
        }
      );
      startShipPageTimer(tab.id, url, index, total);
    } catch (err) {
      bglog('❌ 发货页处理失败', err);
      chrome.tabs.remove(tab.id).catch(() => {});
      batchState.currentIndex += 1;
      batchState.processingTabId = null;
      openNextShipTab();
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 先从存储恢复状态（Service Worker 可能刚被唤醒），再分发处理
  hydrateBatchState().then(() => {
    handleMessage(message, sender, sendResponse);
  });
  return true;
});

// 异常自动上传日志包（带防抖：30 秒内只传一次，避免失败风暴打爆存储）
let lastAutoUploadAt = 0;
function autoUploadLogOnFailure(reason) {
  const now = Date.now();
  if (now - lastAutoUploadAt < 30000) {
    bglog('⏭ 异常上传防抖（30s 内已上传过）:', reason?.reason || '');
    return;
  }
  lastAutoUploadAt = now;
  bglog('☁️ 检测到异常，自动上传日志包:', JSON.stringify(reason));
  // 触发邮件告警（云端 5 分钟冷却）
  sendAlertEmail(reason?.reason || 'unknown', (reason?.error || reason?.skipMessage || '') + (reason?.shipUrl ? ' | ' + reason.shipUrl : ''));
  if (!self.TCBLogExport || typeof self.TCBLogExport.uploadLogPackage !== 'function') {
    bglog('❌ 上传模块未加载，跳过自动上传');
    return;
  }
  self.TCBLogExport
    .uploadLogPackage({
      getBatchState: () => {
        try {
          return { ...batchState };
        } catch (e) {
          return null;
        }
      },
    })
    .then((result) => {
      if (result.ok) {
        bglog(`☁️ 异常日志包已上传: ${result.filename} → ${result.cloudPath || ''}`);
      } else {
        bglog('❌ 异常日志包上传失败:', result.error);
      }
    })
    .catch((err) => bglog('❌ 异常日志包上传异常:', err.message));
}

// —— 统计上报（供云端后台面板实时查看） ——
const STATS_ENDPOINT = 'https://gitbolg-d7gmnsrw46e011706-1256429518.ap-shanghai.app.tcloudbase.com/tcb-admin';
const STATS_TOKEN = 'tcb-admin-2026';
let statsQueue = [];
let statsFlushTimer = null;

// —— 心跳上报（后台在线状态）+ 异常邮件告警 ——
let heartbeatTimer = null;
let lastShopNameForHeartbeat = '';
function startHeartbeatReporting() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  const sendHeartbeat = () => {
    const shop = lastShopNameForHeartbeat || cachedShopNameForReport || '';
    const payload = {
      shopName: shop || '未识别店铺',
      version: (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return ''; } })(),
      status: batchState.active ? (batchState.paused ? 'paused' : 'processing') : 'idle',
      ts: Date.now(),
    };
    fetch(STATS_ENDPOINT + '/heartbeat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Admin-Token': STATS_TOKEN },
      body: JSON.stringify(payload),
    }).catch(() => {});
  };
  sendHeartbeat();
  heartbeatTimer = setInterval(sendHeartbeat, 5 * 60 * 1000); // 每 5 分钟
}

// 异常邮件告警（带 5 分钟冷却由云端处理）
function sendAlertEmail(reason, detail) {
  fetch(STATS_ENDPOINT + '/alert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Admin-Token': STATS_TOKEN },
    body: JSON.stringify({
      shopName: lastShopNameForHeartbeat || cachedShopNameForReport || '',
      reason: reason || 'unknown',
      detail: String(detail || '').slice(0, 500),
    }),
  }).catch(() => {});
}

function enqueueStats(payload) {
  if (payload.shopName) cachedShopNameForReport = payload.shopName;
  statsQueue.push({ ...payload, ts: Date.now() });
  if (!statsFlushTimer) {
    statsFlushTimer = setTimeout(flushStats, 5000);
  }
}

function flushStats() {
  if (statsFlushTimer) {
    clearTimeout(statsFlushTimer);
    statsFlushTimer = null;
  }
  if (!statsQueue.length) return;
  const batch = statsQueue.splice(0, statsQueue.length);
  bglog(`📊 上报统计 ${batch.length} 条`);
  fetch(STATS_ENDPOINT + '/report', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Admin-Token': STATS_TOKEN },
    body: JSON.stringify({ events: batch }),
  })
    .then((resp) => resp.json().catch(() => ({})))
    .then((result) => {
      if (result && result.ok) {
        bglog('✅ 统计上报成功');
      } else {
        bglog('⚠️ 统计上报失败:', result && result.message);
      }
    })
    .catch((err) => bglog('⚠️ 统计上报异常:', err.message));
}

// —— 历史数据补报：安装/升级后把本地积累的完成记录批量上报给后台 ——
const HISTORY_SYNC_KEY = 'tcbHistorySyncedVersion';
function syncHistoryToServer() {
  getCompletedShipRecords().then((records) => {
    const keys = Object.keys(records);
    if (!keys.length) {
      bglog('📊 无历史完成记录可上报');
      return;
    }
    // 组装历史事件：每条完成记录 → ship_done 历史事件
    const events = keys.map((key) => {
      const rec = records[key] || {};
      const certUploaded = Number(rec.certUploaded) || 0;
      const certSkipped = Number(rec.certSkipped) || 0;
      const certFailed = Number(rec.certFailed) || 0;
      const noCertButtons = !!rec.noCertButtons;
      const orderOk = certFailed === 0 && !noCertButtons && (certUploaded > 0 || certSkipped > 0);
      return {
        type: 'ship_done',
        shopName: String(rec.shopName || rec.authorizedShop || '').slice(0, 100),
        certTotal: Number(rec.certTotal) || (certUploaded + certSkipped + certFailed),
        certUploaded,
        certSkipped,
        certFailed,
        noCertButtons,
        orderOk,
        error: '',
        shipUrl: String(rec.url || '').slice(0, 300),
        ts: Number(rec.completedAt) || Date.now(),
        orderKey: key, // 用于服务端去重
        history: true,
      };
    });
    bglog(`📤 补报历史数据 ${events.length} 条`);
    fetch(STATS_ENDPOINT + '/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Admin-Token': STATS_TOKEN },
      body: JSON.stringify({ events, history: true }),
    })
      .then((resp) => resp.json().catch(() => ({})))
      .then((result) => {
        if (result && result.ok) {
          bglog(`✅ 历史数据补报成功（新增 ${result.added || 0} 条）`);
          // 记录已同步版本，避免重复补报
          chrome.storage.local.set({ [HISTORY_SYNC_KEY]: '1' });
        } else {
          bglog('⚠️ 历史数据补报失败:', result && result.message);
        }
      })
      .catch((err) => bglog('⚠️ 历史数据补报异常:', err.message));
  });
}

function handleMessage(message, sender, sendResponse) {
  bglog('📨 收到消息:', message.action, 'from tabId=', sender.tab?.id);

  if (message.action === 'TASK_HEARTBEAT') {
    if (!batchState.active || sender.tab?.id !== batchState.processingTabId) {
      sendResponse({ ok: false, error: '非当前处理中的发货页' });
      return true;
    }

    touchTaskProgress({ stage: message.stage, detail: message.detail || '' });
    forwardHeartbeatToSold({
      shipIndex: message.shipIndex,
      shipTotal: message.shipTotal,
      stage: message.stage,
      detail: message.detail || '',
      certIndex: message.certIndex,
      certTotal: message.certTotal,
      attempt: message.attempt,
    });

    sendResponse({
      ok: true,
      batchActive: batchState.active,
      paused: batchState.paused,
      soldTabAlive: !!batchState.soldTabId,
    });
    return true;
  }

  if (message.action === 'SOLD_HEARTBEAT') {
    if (!batchState.active) {
      sendResponse({ ok: true, active: false });
      return true;
    }
    sendResponse({
      ok: true,
      active: batchState.active,
      paused: batchState.paused,
      current: batchState.currentIndex,
      total: batchState.shipUrls.length,
      processingTabId: batchState.processingTabId,
      lastStage: batchState.lastHeartbeatStage,
      lastDetail: batchState.lastHeartbeatDetail,
      lastProgressAt: batchState.lastProgressAt,
    });
    return true;
  }

  if (message.action === 'START_BATCH') {
    loadInjectedWhitelistBg().then(() => {
      if (!isShopAllowedBg(message.shopName)) {
        bglog('❌ 店铺未授权，拒绝启动批次:', message.shopName || '(未提供)');
        sendResponse({
          ok: false,
          error: `店铺未授权: ${message.shopName || '无法识别店铺名称'}`,
        });
        return;
      }

      if (batchState.active) {
        bglog('⚠️ 已有任务进行中，拒绝新的 START_BATCH');
        sendResponse({ ok: false, error: '已有任务在进行中' });
        return;
      }

      batchState = {
        active: true,
        paused: false,
        soldTabId: message.soldTabId ?? sender.tab?.id ?? null,
        shipUrls: message.shipUrls || [],
        currentIndex: 0,
        processingTabId: null,
        skippedAtStart: message.skippedAtStart ?? 0,
        lastProgressAt: 0,
        lastHeartbeatStage: '',
        lastHeartbeatDetail: '',
        watchMode: !!message.watchMode,
        sessionOrdersDone: 0,
        sessionCertsUploaded: 0,
        sessionCertsSkipped: 0,
        sessionCertsFailed: 0,
      };

      bglog(`🚀 启动批次，soldTabId=${batchState.soldTabId}，共 ${batchState.shipUrls.length} 个订单`);
      persistBatchState();
      sendResponse({ ok: true });
      openNextShipTab();
    });
    return true;
  }

  if (message.action === 'SHIP_PAGE_DONE') {
    clearShipPageTimer();
    const idx = batchState.currentIndex + 1;
    const total = batchState.shipUrls.length;
    const shipUrl = message.shipUrl || batchState.shipUrls[batchState.currentIndex];
    const certTotal = message.certTotal ?? 0;
    const certUploaded = message.certUploaded ?? 0;
    const certSkipped = message.certSkipped ?? 0;
    const certFailed = message.certFailed ?? 0;
    const noCertButtons = !!message.noCertButtons;
    bglog(
      `发货页完成 (${idx}/${total})，证书: 共${certTotal} 上传${certUploaded} 跳过${certSkipped} 失败${certFailed}${noCertButtons ? '（无证书按钮）' : ''}`,
      '关闭标签页并继续'
    );

    // 修复点：以下情况不写入完成记录，订单下次扫描仍会出现，避免「假成功 + 刷不出来」：
    //  1) certFailed > 0
    //  2) noCertButtons（找不到按钮≠没有证书）
    //  3) 没有找到任何证书按钮且没有任何上传/跳过（无法确认是否完成）
    const canMarkCompleted =
      certFailed === 0 &&
      !noCertButtons &&
      (certUploaded > 0 || certSkipped > 0);

    if (shipUrl && canMarkCompleted) {
      markShipCompleted(shipUrl, {
        certTotal,
        certUploaded,
        certSkipped,
        noCertButtons: false,
      }).then((key) => bglog(`📝 已记录完成订单: ${key}`));
    } else if (shipUrl) {
      bglog(
        `⚠️ 本单未写入完成记录：${noCertButtons ? '未找到证书按钮' : `失败 ${certFailed} 个`}，下次扫描会重新处理`
      );
      // 异常自动上传日志包（带现场），便于远程定位
      autoUploadLogOnFailure({ reason: noCertButtons ? 'no-cert-buttons' : 'cert-failed', certFailed, shipUrl: shipUrl.slice(0, 200) });
    }

    const tabId = sender.tab?.id;
    if (tabId) {
      chrome.tabs.remove(tabId).catch(() => {});
    }

    // 统计上报：每完成一个发货页上报一次
    enqueueStats({
      type: 'ship_done',
      shopName: message.shopName || '',
      certTotal,
      certUploaded,
      certSkipped,
      certFailed,
      noCertButtons,
      orderOk: canMarkCompleted,
      shipUrl: shipUrl ? shipUrl.slice(0, 300) : '',
    });

    batchState.currentIndex += 1;
    batchState.processingTabId = null;
    batchState.sessionOrdersDone += 1;
    batchState.sessionCertsUploaded += certUploaded;
    batchState.sessionCertsSkipped += certSkipped;
    batchState.sessionCertsFailed += certFailed;
    persistBatchState();

    if (batchState.soldTabId) {
      chrome.tabs.sendMessage(batchState.soldTabId, {
        action: 'SHIP_PROGRESS',
        current: batchState.currentIndex,
        total: batchState.shipUrls.length,
        shipIndex: message.shipIndex,
        shipTotal: message.shipTotal,
        certTotal,
        certUploaded,
        certSkipped,
        certFailed,
        noCertButtons,
        paused: batchState.paused,
      }).catch(() => {});
    }

    if (batchState.paused) {
      bglog('⏸ 当前订单完成后进入暂停，等待恢复');
      notifySold('BATCH_PAUSED', {
        current: batchState.currentIndex,
        total: batchState.shipUrls.length,
      });
      sendResponse({ ok: true });
      return true;
    }

    setTimeout(openNextShipTab, 500);
    sendResponse({ ok: true });
    return true;
  }

  if (message.action === 'SHIP_PAGE_ERROR') {
    clearShipPageTimer();
    console.error('[淘宝证书上传] 发货页错误:', message.error);
    autoUploadLogOnFailure({ reason: 'ship-page-error', error: message.error, shipUrl: (message.shipUrl || '').slice(0, 200) });
    enqueueStats({
      type: 'ship_error',
      shopName: message.shopName || '',
      error: String(message.error || '').slice(0, 300),
      shipUrl: (message.shipUrl || '').slice(0, 300),
    });
    const tabId = sender.tab?.id;
    if (tabId) {
      chrome.tabs.remove(tabId).catch(() => {});
    }

    batchState.currentIndex += 1;
    batchState.processingTabId = null;
    persistBatchState();

    if (batchState.soldTabId) {
      chrome.tabs
        .sendMessage(batchState.soldTabId, {
          action: 'SHIP_PROGRESS',
          current: batchState.currentIndex,
          total: batchState.shipUrls.length,
          shipIndex: message.shipIndex,
          shipTotal: message.shipTotal,
          errored: true,
          errorMessage: message.error,
          paused: batchState.paused,
        })
        .catch(() => {});
    }

    if (batchState.paused) {
      notifySold('BATCH_PAUSED', {
        current: batchState.currentIndex,
        total: batchState.shipUrls.length,
      });
      sendResponse({ ok: true });
      return true;
    }
    setTimeout(openNextShipTab, 500);
    sendResponse({ ok: true });
    return true;
  }

  if (message.action === 'PAUSE_BATCH') {
    if (!batchState.active) {
      sendResponse({ ok: false, error: '没有进行中的任务' });
      return true;
    }
    batchState.paused = true;
    persistBatchState();
    bglog('⏸ 用户暂停批次');
    notifySold('BATCH_PAUSED', {
      current: batchState.currentIndex,
      total: batchState.shipUrls.length,
    });
    sendResponse({ ok: true, paused: true });
    return true;
  }

  if (message.action === 'RESUME_BATCH') {
    if (!batchState.active) {
      sendResponse({ ok: false, error: '没有进行中的任务' });
      return true;
    }
    batchState.paused = false;
    persistBatchState();
    bglog('▶ 用户恢复批次');
    notifySold('BATCH_RESUMED', {
      current: batchState.currentIndex,
      total: batchState.shipUrls.length,
    });
    openNextShipTab();
    sendResponse({ ok: true, paused: false });
    return true;
  }

  if (message.action === 'GET_BATCH_STATE') {
    sendResponse({ ...batchState });
    return true;
  }

  if (message.action === 'CANCEL_BATCH') {
    const soldTabId = batchState.soldTabId;
    const current = batchState.currentIndex;
    const total = batchState.shipUrls.length;
    if (batchState.processingTabId) {
      chrome.tabs.remove(batchState.processingTabId).catch(() => {});
    }
    resetBatch();
    if (soldTabId) {
      chrome.tabs
        .sendMessage(soldTabId, { action: 'BATCH_CANCELLED', current, total })
        .catch(() => {});
    }
    bglog('🛑 用户取消批次');
    sendResponse({ ok: true });
    return true;
  }

  if (message.action === 'GET_COMPLETED_SHIP_COUNT') {
    getCompletedShipRecords().then((records) => {
      sendResponse({ ok: true, count: Object.keys(records).length });
    });
    return true;
  }

  if (message.action === 'WHITELIST_SESSION_STATUS') {
    readAdminSessionExpiry().then((authenticated) => {
      sendResponse({ ok: true, authenticated });
    });
    return true;
  }

  if (message.action === 'WHITELIST_LOGIN') {
    tcbLoadAdminPasswordHash(() => {
      if (!tcbVerifyAdminPassword(message.password || '')) {
        sendResponse({ ok: false, error: '密码错误' });
        return;
      }
      setAdminSession();
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.action === 'WHITELIST_LOGOUT') {
    clearAdminSession();
    sendResponse({ ok: true });
    return true;
  }

  if (message.action === 'WHITELIST_GET_ALL') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      loadWhitelistCachesBg().then((snapshot) => {
        sendResponse({
          ok: true,
          injected: snapshot.injected,
          removedBuiltin: snapshot.removedBuiltin,
          activeBuiltin: snapshot.activeBuiltin,
          builtin: tcbGetBuiltInWhitelist(),
          effective: snapshot.effective,
        });
      });
    });
    return true;
  }

  if (message.action === 'WHITELIST_ADD') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      tcbAddInjectedShop(message.shopName, (result) => {
        if (!result.ok) {
          sendResponse(result);
          return;
        }
        bglog('✅ 注入白名单店铺:', result.added);
        afterWhitelistChanged(sendResponse, result);
      });
    });
    return true;
  }

  if (message.action === 'WHITELIST_REMOVE') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      tcbRemoveInjectedShop(message.shopName, (result) => {
        if (!result.ok) {
          sendResponse(result);
          return;
        }
        bglog('🗑 移除注入白名单店铺:', result.removed);
        afterWhitelistChanged(sendResponse, result);
      });
    });
    return true;
  }

  if (message.action === 'WHITELIST_REMOVE_BUILTIN') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      tcbRemoveBuiltinShop(message.shopName, (result) => {
        if (!result.ok) {
          sendResponse(result);
          return;
        }
        bglog('🗑 移除内置白名单店铺:', result.removed);
        afterWhitelistChanged(sendResponse, result);
      });
    });
    return true;
  }

  if (message.action === 'WHITELIST_RESTORE_BUILTIN') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      tcbRestoreBuiltinShop(message.shopName, (result) => {
        if (!result.ok) {
          sendResponse(result);
          return;
        }
        bglog('↩️ 恢复内置白名单店铺:', result.restored);
        afterWhitelistChanged(sendResponse, result);
      });
    });
    return true;
  }

  if (message.action === 'WHITELIST_EXPORT_CRX') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      exportCrxPackageBytes()
        .then((result) => sendResponse({ ok: true, ...result }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
    });
    return true;
  }

  if (message.action === 'WHITELIST_CHANGE_PASSWORD') {
    ensureAdminAuthenticated(sendResponse).then((authed) => {
      if (!authed) return;
      tcbChangeAdminPassword(message.oldPassword, message.newPassword, (result) => {
        if (!result.ok) {
          sendResponse(result);
          return;
        }
        bglog('🔐 管理密码已更新');
        sendResponse({ ok: true });
      });
    });
    return true;
  }

  // —— 日志收集 / 导出 / 异常记录清理 ——
  if (message.action === 'LOG_EXPORT') {
    if (self.TCBLogExport) {
      // 超时看门狗：避免任何一步异常导致 sendResponse 永不回调、发起方卡死
      let settled = false;
      const watchdog = setTimeout(() => {
        if (settled) return;
        settled = true;
        bglog('⏱ 日志包导出超时（15s 看门狗）');
        sendResponse({ ok: false, error: '日志包导出超时' });
      }, 15000);
      // 传入批次的直接状态快照，避免在 SW 内自我 sendMessage 导致回调永不触发
      self.TCBLogExport
        .exportLogPackage({
          getBatchState: () => {
            try {
              return { ...batchState };
            } catch (e) {
              return null;
            }
          },
        })
        .then((result) => {
          if (settled) return;
          settled = true;
          clearTimeout(watchdog);
          if (result.ok) {
            bglog(`📦 日志包已导出: ${result.filename}（${result.entryCount} 条日志，${result.sizeBytes} 字节）`);
          } else {
            bglog('❌ 日志包导出失败:', result.error);
          }
          sendResponse(result);
        })
        .catch((err) => {
          if (settled) return;
          settled = true;
          clearTimeout(watchdog);
          bglog('❌ 日志包导出异常:', err);
          sendResponse({ ok: false, error: err.message });
        });
    } else {
      sendResponse({ ok: false, error: '日志模块未加载' });
    }
    return true;
  }

  if (message.action === 'LOG_CLEANUP_ABNORMAL') {
    if (self.TCBLogExport) {
      self.TCBLogExport.cleanupAbnormalShipRecords().then((result) => {
        if (result.ok) {
          bglog(
            `🧹 异常记录清理完成：移除 ${result.removedCount} 条，保留 ${result.keptCount} 条`
          );
        }
        sendResponse(result);
      });
    } else {
      sendResponse({ ok: false, error: '日志模块未加载' });
    }
    return true;
  }

  // 上传日志包到腾讯云 COS（云函数代理，扩展不持有密钥）
  if (message.action === 'LOG_UPLOAD') {
    if (self.TCBLogExport && typeof self.TCBLogExport.uploadLogPackage === 'function') {
      let settled = false;
      const watchdog = setTimeout(() => {
        if (settled) return;
        settled = true;
        bglog('⏱ 日志包上传超时（30s 看门狗）');
        sendResponse({ ok: false, error: '日志包上传超时' });
      }, 30000);
      self.TCBLogExport
        .uploadLogPackage({
          getBatchState: () => {
            try {
              return { ...batchState };
            } catch (e) {
              return null;
            }
          },
        })
        .then((result) => {
          if (settled) return;
          settled = true;
          clearTimeout(watchdog);
          if (result.ok) {
            bglog(`☁️ 日志包已上传: ${result.filename} → ${result.cloudPath || ''}`);
            if (result.url) bglog(`   下载: ${result.url.slice(0, 100)}...`);
          } else {
            bglog('❌ 日志包上传失败:', result.error);
          }
          sendResponse(result);
        })
        .catch((err) => {
          if (settled) return;
          settled = true;
          clearTimeout(watchdog);
          bglog('❌ 日志包上传异常:', err);
          sendResponse({ ok: false, error: err.message });
        });
    } else {
      sendResponse({ ok: false, error: '上传模块未加载' });
    }
    return true;
  }

  if (message.action === 'CLEAR_LOGS') {
    if (self.TCBLogger) {
      self.TCBLogger.clear();
      bglog('🗑 日志已清空');
    }
    sendResponse({ ok: true });
    return true;
  }

  // —— 自动更新 ——
  if (message.action === 'UPDATE_CHECK') {
    if (self.TCBUpdater) {
      self.TCBUpdater.checkForUpdate(true).then((result) => {
        if (result.hasUpdate) {
          bglog(`🔄 发现新版本 ${result.currentVersion} → ${result.latestVersion}`);
        }
        sendResponse({ ok: true, ...result });
      });
    } else {
      sendResponse({ ok: false, error: '更新模块未加载' });
    }
    return true;
  }

  if (message.action === 'UPDATE_DOWNLOAD') {
    if (self.TCBUpdater) {
      self.TCBUpdater.downloadLatest(message.which || 'chrome').then((result) => {
        if (result.ok) bglog(`⬇️ 已触发新版下载: ${result.filename}`);
        sendResponse(result);
      });
    } else {
      sendResponse({ ok: false, error: '更新模块未加载' });
    }
    return true;
  }

  if (message.action === 'UPDATE_STATE') {
    if (self.TCBUpdater) {
      self.TCBUpdater.getUpdateState().then((state) => sendResponse({ ok: true, ...state }));
    } else {
      sendResponse({ ok: false, error: '更新模块未加载' });
    }
    return true;
  }

  return false;
}
