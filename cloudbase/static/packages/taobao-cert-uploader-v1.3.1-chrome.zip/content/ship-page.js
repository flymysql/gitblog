(function () {
  const TCB = window.TCB;
  if (!TCB) {
    console.error('[证书上传] ship-page.js: TCB 未就绪（helpers 未加载）');
    return;
  }

  const MSG_TAG = 'TCB_CERT_UPLOADER';
  const CERT_IFRAME_SELECTOR = 'iframe[src*="jewel-certificate-deliver"]';
  const CLOSE_BTN_SELECTOR = 'a[aria-label="关闭"]';

  const KEEP_OPEN_ON_ERROR = false;
  const IFRAME_REQUEST_TIMEOUT_MS = 90000;
  const MAX_CERT_RETRIES = 3;

  TCB.log('🚢 ship-page.js（顶层协调）已注入，当前 URL:', location.href);

  function listCertIframes() {
    return Array.from(document.querySelectorAll(CERT_IFRAME_SELECTOR)).filter(
      (f) => f.contentWindow
    );
  }

  async function waitForNewCertIframe(beforeSrcs, timeout = 10000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const frames = listCertIframes();
      const fresh = frames.find((f) => !beforeSrcs.has(f.src));
      if (fresh) {
        TCB.log(`✅ 找到新证书弹窗 iframe（耗时 ${Date.now() - start}ms）: ${fresh.src}`);
        return fresh;
      }
      await TCB.sleep(200);
    }
    // 兜底：取「可见且 src 非空」的最后一个，避免复用已关闭/隐藏的旧 iframe
    const frames = listCertIframes();
    const visible = frames.filter((f) => {
      try {
        const r = f.getBoundingClientRect();
        const cs = window.getComputedStyle(f);
        if (r.width < 2 || r.height < 2) return false;
        if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
        return true;
      } catch (e) {
        return true;
      }
    });
    if (visible.length) {
      const last = visible[visible.length - 1];
      TCB.warn(`未检测到全新 iframe，兜底使用最后一个可见 iframe: ${last.src}`);
      return last;
    }
    if (frames.length) {
      const last = frames[frames.length - 1];
      TCB.warn(`可见 iframe 列表为空，兜底使用最后一个 iframe: ${last.src}（可能已关闭）`);
      return last;
    }
    return null;
  }

  async function clickCloseDialog() {
    await TCB.sleep(400, '等待顶层关闭按钮出现');
    const closeBtn = document.querySelector(CLOSE_BTN_SELECTOR);
    if (closeBtn) {
      TCB.clickElement(closeBtn, '顶层关闭弹窗');
      await TCB.sleep(800, '关闭弹窗后等待');
      return true;
    }
    TCB.warn('顶层未找到关闭按钮: ' + CLOSE_BTN_SELECTOR);
    return false;
  }

  /** 向 iframe 发指令并等待指定 action 回执 */
  function requestIframe(iframe, action, certIndex, doneAction, timeout = IFRAME_REQUEST_TIMEOUT_MS) {
    return new Promise((resolve, reject) => {
      // 发送前快速校验 iframe 仍挂载且可见，避免向已关闭的 iframe 发消息空等 90 秒
      if (!iframe || !iframe.isConnected || !iframe.contentWindow) {
        reject(new Error(`iframe 已失效（未挂载或无 contentWindow）: ${action}`));
        return;
      }
      const reqId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
      let acked = false;

      const timer = setTimeout(() => {
        cleanup();
        reject(new Error(`等待 iframe 回执超时（${action}）`));
      }, timeout);

      const sendDial = { count: 0 };
      const retry = setInterval(() => {
        if (acked || sendDial.count >= 5) {
          clearInterval(retry);
          return;
        }
        sendDial.count += 1;
        TCB.log(`📤 向 iframe 发送 ${action} reqId=${reqId}（第 ${sendDial.count} 次）`);
        try {
          iframe.contentWindow.postMessage({ tag: MSG_TAG, action, reqId }, '*');
        } catch (e) {
          TCB.warn(`向 iframe 发消息失败: ${e.message}`);
        }
      }, 1500);

      function onMessage(event) {
        const d = event.data;
        if (!d || d.tag !== MSG_TAG || d.reqId !== reqId) return;
        acked = true;
        clearInterval(retry);

        if (d.action === doneAction) {
          cleanup();
          if (d.ok) {
            resolve(d);
          } else {
            reject(new Error(d.error || 'iframe 处理失败'));
          }
        } else if (d.action === 'CERT_PROGRESS') {
          TCB.log(`   [iframe] ${d.text}`);
          reportHeartbeat('证书弹窗', d.text);
        }
      }

      function cleanup() {
        clearTimeout(timer);
        clearInterval(retry);
        window.removeEventListener('message', onMessage);
      }

      window.addEventListener('message', onMessage);
      TCB.log(`📤 向 iframe 发送 ${action} reqId=${reqId}（第 0 次）`);
      try {
        iframe.contentWindow.postMessage({ tag: MSG_TAG, action, reqId }, '*');
      } catch (e) {
        cleanup();
        reject(new Error(`向 iframe 发消息失败: ${e.message}`));
        return;
      }
    });
  }

  function requestUploadInIframe(iframe, certIndex) {
    return requestIframe(iframe, 'DO_UPLOAD', certIndex, 'CERT_DONE').then((d) => {
      TCB.log(`📥 iframe 回执：证书 ${certIndex} 上传成功 ${d.serial ? '(' + d.serial + ')' : ''}`);
      return d;
    });
  }

  function requestCheckInIframe(iframe, certIndex, expectedSerial) {
    return requestIframe(iframe, 'DO_CHECK', certIndex, 'CERT_CHECK_DONE').then((d) => {
      const found = d.serial || '';
      const matched = expectedSerial ? found === expectedSerial : !!found;
      TCB.log(
        `📥 iframe 回执：证书 ${certIndex} 检查结果 alreadyUploaded=${d.alreadyUploaded} serial=${found || '（空）'} expected=${expectedSerial || '（无）'} matched=${matched}`
      );
      return { ...d, serial: found, serialMatched: matched };
    });
  }

  async function openCertDialogAndGetIframe(beforeSrcs) {
    await TCB.sleep(1000, '点击证书链接后等待弹窗 iframe 渲染');
    const iframe = await waitForNewCertIframe(beforeSrcs, 10000);
    if (!iframe) {
      TCB.warn('未找到证书弹窗 iframe，打印诊断信息：');
      TCB.dumpFrameDiagnostics();
      throw new Error('未找到证书弹窗 iframe');
    }
    return iframe;
  }

  function isCertDialogStillOpen() {
    const iframe = document.querySelector(CERT_IFRAME_SELECTOR);
    if (!iframe) return false;
    const rect = iframe.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return false;
    const style = window.getComputedStyle(iframe);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return false;
    }
    return iframe.offsetParent !== null || rect.top >= 0;
  }

  async function closeCertDialogIfOpen() {
    if (isCertDialogStillOpen()) {
      await clickCloseDialog();
    }
    await TCB.sleep(500, '关闭证书弹窗后等待页面恢复');
  }

  async function tryVerifyDialogClosed(certIndex) {
    await TCB.sleep(1000, '确定后等待弹窗自动关闭');
    if (!isCertDialogStillOpen()) {
      TCB.log(`✅ 证书 ${certIndex} 弹窗已自动关闭`);
      return true;
    }
    TCB.warn(`⚠️ 证书 ${certIndex} 弹窗仍在，将通过复查确认是否成功`);
    return false;
  }

  async function closeCheckDialog(check) {
    if (check.closedInFrame) {
      await TCB.sleep(800, 'iframe 内已关闭，等待弹窗消失');
      return;
    }
    await clickCloseDialog();
  }

  /**
   * 重新点开证书链接，检查该品 Tab 的证书编号是否与期望编号一致。
   * 修复点：只认「当前品 Tab 的编号 === 期望编号」才算成功，
   * 避免把其他品 Tab 的编号误判为当前品已上传。
   */
  async function confirmCertUploadedByReopen(item, certIndex, expectedSerial) {
    await closeCertDialogIfOpen();
    const beforeSrcs = new Set(listCertIframes().map((f) => f.src));
    TCB.clickElement(item.el, `复查证书 ${certIndex}「${item.text}」`);
    const iframe = await openCertDialogAndGetIframe(beforeSrcs);
    const check = await requestCheckInIframe(iframe, certIndex, expectedSerial);
    if (check.serialMatched) {
      TCB.log(`✅ 证书 ${certIndex} 复查确认：编号一致 ${check.serial}`);
      await closeCheckDialog(check);
      return true;
    }
    if (check.alreadyUploaded) {
      TCB.warn(
        `证书 ${certIndex} 复查：当前 Tab 有编号但${expectedSerial ? `与期望不一致（${check.serial} ≠ ${expectedSerial}）` : '不是插件生成的编号'}，按失败处理`
      );
    } else {
      TCB.warn(`证书 ${certIndex} 复查：仍未发现证书编号`);
    }
    await clickCloseDialog().catch(() => {});
    return false;
  }

  async function processCertificateWithRetry(item, certIndex, certTotal) {
    TCB.log(`────── 证书 ${certIndex}/${certTotal} [${item.text}] 开始（最多 ${MAX_CERT_RETRIES} 次）──────`);

    for (let attempt = 1; attempt <= MAX_CERT_RETRIES; attempt++) {
      TCB.log(`>>> 证书 ${certIndex}/${certTotal} 第 ${attempt}/${MAX_CERT_RETRIES} 次尝试`);
      reportHeartbeat('处理证书', `第 ${certIndex}/${certTotal} 个，第 ${attempt} 次尝试`, {
        certIndex,
        certTotal,
        attempt,
      });
      heartbeatContext.lastExtra = { certIndex, certTotal, attempt };

      await closeCertDialogIfOpen();
      const beforeSrcs = new Set(listCertIframes().map((f) => f.src));
      TCB.clickElement(item.el, `第 ${certIndex} 个「${item.text}」链接（第 ${attempt} 次）`);

      const iframe = await openCertDialogAndGetIframe(beforeSrcs);
      const check = await requestCheckInIframe(iframe, certIndex);

      if (check.alreadyUploaded) {
        TCB.log(`证书 ${certIndex} 已存在证书编号（${check.serial || '未知'}），跳过`);
        await closeCheckDialog(check);
        return attempt === 1 ? 'skipped' : 'uploaded';
      }

      let uploadedSerial = '';
      try {
        TCB.log(`证书 ${certIndex} 未上传，执行注入上传流程（第 ${attempt} 次）`);
        reportHeartbeat('上传证书', `第 ${certIndex}/${certTotal} 个，注入并提交`, {
          certIndex,
          certTotal,
          attempt,
        });
        const done = await requestUploadInIframe(iframe, certIndex);
        uploadedSerial = done.serial || '';
        const closed = await tryVerifyDialogClosed(certIndex);
        if (!closed) {
          await clickCloseDialog().catch(() => {});
        }
      } catch (err) {
        TCB.warn(`证书 ${certIndex} 第 ${attempt} 次上传过程异常: ${err.message}`);
        await clickCloseDialog().catch(() => {});
      }

      if (!uploadedSerial) {
        TCB.warn(`证书 ${certIndex} 上传回执未带编号，尝试从复查中确认`);
      }
      const verified = await confirmCertUploadedByReopen(item, certIndex, uploadedSerial);
      reportHeartbeat('复查证书', `第 ${certIndex}/${certTotal} 个，确认是否已有编号`, {
        certIndex,
        certTotal,
        attempt,
      });
      if (verified) {
        TCB.log(`────── 证书 ${certIndex}/${certTotal} 第 ${attempt} 次尝试确认成功 ──────`);
        return 'uploaded';
      }

      if (attempt < MAX_CERT_RETRIES) {
        TCB.warn(`证书 ${certIndex} 第 ${attempt} 次未确认成功，准备重试`);
        await TCB.sleep(800, '重试前等待');
      }
    }

    throw new Error(`证书 ${certIndex} 重试 ${MAX_CERT_RETRIES} 次后仍未确认成功`);
  }

  async function processAllCertificates() {
    reportHeartbeat('扫描证书', '正在查找上传/查看证书按钮');
    const certLinks = await TCB.waitForCertActionLinks(15000);
    TCB.log(`扫描证书按钮完成: 共 ${certLinks.length} 个`);

    if (certLinks.length === 0) {
      TCB.warn('⏭ 本页未找到任何「上传证书」或「查看证书」按钮');
      const allLinkTexts = Array.from(document.querySelectorAll('a, button'))
        .map((el) => el.textContent.replace(/\s+/g, '').trim())
        .filter(Boolean);
      TCB.log('当前页面所有链接/按钮文案（前 50 个）:', allLinkTexts.slice(0, 50));
      // 修复点：找不到按钮≠没有证书。返回 failed（而非 0 失败），
      // 让 background 不写入完成记录，订单下次扫描仍会出现。
      return { total: 0, uploaded: 0, skipped: 0, failed: 1, noCertButtons: true };
    }

    reportHeartbeat('扫描完成', `共找到 ${certLinks.length} 个证书待处理`, {
      certTotal: certLinks.length,
    });

    let uploaded = 0;
    let skipped = 0;
    let failed = 0;

    for (let i = 0; i < certLinks.length; i++) {
      const links = TCB.findCertActionLinks();
      const item = links[i];
      if (!item) {
        TCB.warn(`第 ${i + 1} 个证书链接已不存在，按失败统计（可能页面 DOM 变化）`);
        failed += 1;
        continue;
      }

      TCB.log(`>>> 处理第 ${i + 1}/${certLinks.length} 个证书 [${item.text}] <<<`);
      reportHeartbeat('开始证书任务', `第 ${i + 1}/${certLinks.length} 个「${item.text}」`, {
        certIndex: i + 1,
        certTotal: certLinks.length,
      });

      try {
        const result = await processCertificateWithRetry(item, i + 1, certLinks.length);
        TCB.log(`证书 ${i + 1}/${certLinks.length} 结果: ${result}`);
        if (result === 'uploaded') uploaded += 1;
        if (result === 'skipped') skipped += 1;
      } catch (err) {
        failed += 1;
        TCB.error(`证书 ${i + 1}/${certLinks.length} 处理失败，跳过继续:`, err.message);
        await clickCloseDialog().catch(() => {});
        await TCB.sleep(500, '证书失败后等待页面恢复');
      }
    }

    TCB.log(`本页证书统计: 共 ${certLinks.length}，上传 ${uploaded}，已存在跳过 ${skipped}，失败 ${failed}`);
    return { total: certLinks.length, uploaded, skipped, failed };
  }

  let isProcessing = false;
  let shopAllowed = null;
  let currentShopName = '';
  let heartbeatContext = null;
  let heartbeatInterval = null;
  let batchPausedByMain = false;

  function setHeartbeatContext(ctx) {
    heartbeatContext = ctx;
  }

  function reportHeartbeat(stage, detail, extra = {}) {
    if (!heartbeatContext) return;
    heartbeatContext.lastStage = stage;
    heartbeatContext.lastDetail = detail || '';

    const payload = {
      action: 'TASK_HEARTBEAT',
      stage,
      detail: detail || '',
      shipIndex: heartbeatContext.shipIndex,
      shipTotal: heartbeatContext.shipTotal,
      shipUrl: heartbeatContext.shipUrl,
      ts: Date.now(),
      ...extra,
    };

    if (heartbeatContext.isBatch) {
      chrome.runtime.sendMessage(payload, (resp) => {
        if (chrome.runtime.lastError) return;
        if (resp?.paused) batchPausedByMain = true;
      });
    }

    if (heartbeatContext.onStatus) {
      heartbeatContext.onStatus(stage, detail);
    }
  }

  function startHeartbeatInterval() {
    stopHeartbeatInterval();
    heartbeatInterval = setInterval(() => {
      if (!isProcessing || !heartbeatContext) return;
      reportHeartbeat(
        heartbeatContext.lastStage || '处理中',
        heartbeatContext.lastDetail || '等待阶段更新',
        heartbeatContext.lastExtra || {}
      );
    }, 30000);
  }

  function stopHeartbeatInterval() {
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
      heartbeatInterval = null;
    }
  }

  const MANUAL_WRAP_ID = 'tcb-ship-manual-wrap';
  const MANUAL_BTN_ID = 'tcb-ship-manual-cert-btn';
  const MANUAL_STATUS_ID = 'tcb-ship-manual-status';

  function isBatchConsignPage() {
    return location.href.includes('batch-consign');
  }

  function isManualShipPage() {
    if (isBatchConsignPage()) return false;
    return (
      !!document.querySelector('.order-info-card') ||
      /consign/i.test(location.pathname + location.search)
    );
  }

  function findOrderCardHeaderRow() {
    const orderCard = document.querySelector('.order-info-card');
    if (!orderCard) return null;
    const card = orderCard.closest('.next-card');
    if (!card) return null;
    return card.querySelector(':scope > .flex.flex-justify-between.flex-align-center');
  }

  async function waitForOrderCardHeader(timeout = 20000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const row = findOrderCardHeaderRow();
      if (row) return row;
      await TCB.sleep(300);
    }
    return null;
  }

  function setManualStatus(text) {
    const el = document.getElementById(MANUAL_STATUS_ID);
    if (el) el.textContent = text || '';
  }

  function setManualButtonEnabled(enabled) {
    const btn = document.getElementById(MANUAL_BTN_ID);
    if (!btn) return;
    btn.disabled = !enabled;
    btn.textContent = enabled ? '自动生成证书' : '处理中…';
  }

  function removeManualButton() {
    const wrap = document.getElementById(MANUAL_WRAP_ID);
    if (wrap) wrap.remove();
  }

  function injectManualButton(headerRow) {
    if (!shopAllowed || !headerRow) return false;
    if (document.getElementById(MANUAL_WRAP_ID)) return true;

    const wrap = document.createElement('div');
    wrap.id = MANUAL_WRAP_ID;
    wrap.className = 'tcb-ship-manual-wrap';
    wrap.innerHTML = `
      <button type="button" id="${MANUAL_BTN_ID}" class="tcb-ship-cert-btn">自动生成证书</button>
      <span id="${MANUAL_STATUS_ID}" class="tcb-ship-cert-status"></span>
    `;

    const collapse = headerRow.querySelector('.flex.flex-align-center[style*="cursor"]');
    if (collapse) {
      headerRow.insertBefore(wrap, collapse);
    } else {
      headerRow.appendChild(wrap);
    }

    wrap.querySelector(`#${MANUAL_BTN_ID}`).addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onManualCertClick();
    });

    TCB.log('已注入发货页「自动生成证书」单页辅助按钮');
    return true;
  }

  async function refreshShopAuthForShip() {
    const auth = await TCB.ensureShopAllowed();
    shopAllowed = !!auth.allowed;
    if (auth.shopName) currentShopName = auth.shopName;
    if (!shopAllowed) {
      TCB.log(`发货页店铺未授权，不显示单页辅助按钮: ${auth.shopName || '无法识别'}`);
      removeManualButton();
    }
    return auth;
  }

  function formatCertStats(stats) {
    const { total, uploaded, skipped, failed, noCertButtons } = stats;
    if (noCertButtons) return '本页未找到证书按钮';
    return `完成：共 ${total} 个，新上传 ${uploaded}，跳过 ${skipped}${failed ? `，失败 ${failed}` : ''}`;
  }

  async function onManualCertClick() {
    if (isProcessing) return;

    const auth = await TCB.ensureShopAllowed();
    if (!auth.allowed) {
      shopAllowed = false;
      removeManualButton();
      return;
    }

    isProcessing = true;
    setManualButtonEnabled(false);
    setManualStatus('正在扫描证书按钮…');
    setHeartbeatContext({
      isBatch: false,
      onStatus: (stage, detail) => setManualStatus(detail ? `${stage}：${detail}` : stage),
    });
    startHeartbeatInterval();
    reportHeartbeat('单页模式', '开始处理当前发货页');

    try {
      await TCB.sleep(500, '单页模式开始前短暂等待');
      const stats = await processAllCertificates();
      reportHeartbeat('单页完成', formatCertStats(stats));
      setManualStatus(formatCertStats(stats));
      TCB.log(`单页辅助完成：${formatCertStats(stats)}`);
    } catch (err) {
      TCB.error('单页辅助处理出错:', err.message);
      setManualStatus(`出错：${err.message}`);
    } finally {
      isProcessing = false;
      setManualButtonEnabled(true);
      stopHeartbeatInterval();
      setHeartbeatContext(null);
    }
  }

  async function setupManualShipAssist() {
    if (!isManualShipPage()) return;

    let auth = await refreshShopAuthForShip();
    if (!shopAllowed && !auth.shopName) {
      await TCB.sleep(3000, '发货页店铺名未加载，稍后重试鉴权');
      auth = await refreshShopAuthForShip();
    }
    if (!shopAllowed) return;

    const headerRow = await waitForOrderCardHeader();
    if (!headerRow) {
      TCB.warn('未找到「确认订单信息」卡片，无法注入单页辅助按钮');
      return;
    }

    injectManualButton(headerRow);

    const card = document.querySelector('.order-info-card')?.closest('.next-card');
    const observeRoot = card || document.body;
    const observer = new MutationObserver(() => {
      if (!shopAllowed || !isManualShipPage()) {
        removeManualButton();
        return;
      }
      const row = findOrderCardHeaderRow();
      if (row && !document.getElementById(MANUAL_WRAP_ID)) {
        injectManualButton(row);
      }
    });
    observer.observe(observeRoot, { childList: true, subtree: true });
  }

  async function handleShipPage(message) {
    if (isProcessing) {
      TCB.warn('已在处理中，忽略重复的 PROCESS_SHIP_PAGE 消息');
      return;
    }
    isProcessing = true;
    batchPausedByMain = false;

    const { shipIndex, shipTotal, shipUrl } = message;
    TCB.log(`🏁 开始处理发货页 ${shipIndex}/${shipTotal}，URL: ${location.href}`);

    setHeartbeatContext({ shipIndex, shipTotal, shipUrl, isBatch: true });
    startHeartbeatInterval();
    reportHeartbeat('开始处理发货页', `第 ${shipIndex}/${shipTotal} 个订单`);

    try {
      await TCB.sleep(1500, '发货页处理前的初始等待');

      const stats = await processAllCertificates();
      const { total, uploaded, skipped, failed, noCertButtons } = stats;

      if (noCertButtons) {
        TCB.log(`⏭ 发货页 ${shipIndex}/${shipTotal} 无证书按钮，未记完成，稍后重新扫描`);
      } else {
        TCB.log(
          `🎉 发货页 ${shipIndex}/${shipTotal} 完成：共 ${total} 个证书，新上传 ${uploaded}，已存在跳过 ${skipped}，失败跳过 ${failed ?? 0}`
        );
      }

      reportHeartbeat('发货页完成', '证书处理结束，准备关闭页面');
      chrome.runtime.sendMessage({
        action: 'SHIP_PAGE_DONE',
        shipIndex,
        shipTotal,
        shipUrl: shipUrl || location.href,
        shopName: currentShopName,
        certTotal: total,
        certUploaded: uploaded,
        certSkipped: skipped,
        certFailed: failed ?? 0,
        noCertButtons: !!noCertButtons,
      });
      TCB.log(`已发送 SHIP_PAGE_DONE: 上传 ${uploaded} 跳过 ${skipped} 失败 ${failed ?? 0}`);
    } catch (err) {
      TCB.error(`发货页 ${shipIndex}/${shipTotal} 处理出错:`, err.message, err);
      if (KEEP_OPEN_ON_ERROR) {
        TCB.warn('⛔ KEEP_OPEN_ON_ERROR=true，本页保持打开以便调试，不会自动关闭或继续下一个。');
      } else {
        chrome.runtime.sendMessage({
          action: 'SHIP_PAGE_ERROR',
          error: err.message,
          shipIndex,
          shipTotal,
          shipUrl: shipUrl || location.href,
          shopName: currentShopName,
        });
        TCB.log('已发送 SHIP_PAGE_ERROR');
      }
    } finally {
      isProcessing = false;
      stopHeartbeatInterval();
      setHeartbeatContext(null);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'WHITELIST_UPDATED') {
      refreshShopAuthForShip().then((auth) => {
        if (auth.allowed && isManualShipPage()) {
          waitForOrderCardHeader().then((headerRow) => {
            if (headerRow) injectManualButton(headerRow);
          });
        }
      });
      return false;
    }

    TCB.log('📨 收到消息:', message.action, message);
    if (message.action === 'PROCESS_SHIP_PAGE') {
      handleShipPage(message);
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });

  if (document.readyState === 'complete') {
    setupManualShipAssist();
  } else {
    window.addEventListener('load', setupManualShipAssist);
  }
})();
