(function () {
  const TCB = window.TCB;
  if (!TCB || !TCB.uploadCertificate) {
    console.error('[证书上传] cert-dialog.js: TCB 未就绪（helpers/cert-generator 未加载）', TCB);
    return;
  }

  const MSG_TAG = 'TCB_CERT_UPLOADER';

  const ADD_TAB_SELECTORS = [
    '#ice-container > div > div > div > div > div.ant-tabs-nav > div.ant-tabs-nav-wrap > div > button',
    '.ant-tabs-nav-add',
    '#ice-container .ant-tabs-nav-wrap > div > button',
  ];
  const CONFIRM_BTN_SELECTOR =
    '#item > div > div > div > div > div > div > div > button';
  const CONFIRM_TEXTS = ['确定', '确认', '提交', '保存'];
  const CLOSE_BTN_SELECTOR = 'a[aria-label="关闭"]';

  const isTop = window.top === window;
  TCB.log(`📄 cert-dialog.js 已注入（${isTop ? '顶层' : 'iframe'}），URL: ${location.href}`);

  function reportProgress(source, reqId, text) {
    try {
      source.postMessage({ tag: MSG_TAG, action: 'CERT_PROGRESS', reqId, text }, '*');
    } catch (e) {
      /* ignore */
    }
  }

  /**
   * 检查「当前激活 Tab」是否已有证书编号。
   * 修复点：不再扫整页 [title="证书编号"]（会把其他品 Tab 的编号误判成当前品已上传），
   * 而是只读取可见 Tab 面板内的编号输入框/编号行（antd 非激活面板 display:none）。
   */
  function readActiveTabSerial() {
    const doc = document;

    // 1) 优先：可见的编号输入框（非激活面板 display:none 会被过滤掉）
    const inputs = Array.from(
      doc.querySelectorAll(
        '#item_showSerialNo, input[placeholder*="证书编号"], input[placeholder*="编号"], input[aria-label*="编号"]'
      )
    );
    const visibleInputs = inputs.filter((inp) => {
      try {
        const r = inp.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) return false;
        const cs = doc.defaultView.getComputedStyle(inp);
        if (cs.display === 'none' || cs.visibility === 'hidden') return false;
        return true;
      } catch (e) {
        return true;
      }
    });
    for (const inp of visibleInputs) {
      const v = (inp.value || inp.getAttribute('value') || '').trim();
      if (v) return { serial: v, source: 'visible-input' };
    }

    // 2) 兜底：激活 Tab 作用域内的编号行
    const tabs = Array.from(
      doc.querySelectorAll('.ant-tabs-tab, .next-tabs-tab, [role="tab"]')
    );
    let active = tabs.find((t) =>
      /active|selected/.test((t.className || '') + ' ' + (t.getAttribute('aria-selected') || ''))
    );
    if (!active) active = tabs[0];
    if (active) {
      const wrap = active.closest('.ant-tabs, .next-tabs') || doc;
      const label = wrap.querySelector('[title="证书编号"], label[title="证书编号"]');
      if (label) {
        const row = label.closest('div, tr, .ant-form-item') || label.parentElement;
        if (row) {
          const v = (row.textContent || '').replace(/\s+/g, '').trim();
          if (v) return { serial: v, source: 'label-row' };
        }
      }
    }

    return { serial: '', source: 'none' };
  }

  function hasCertNumberLabel() {
    const { serial, source } = readActiveTabSerial();
    const plausible = TCB.isPlausibleSerial ? TCB.isPlausibleSerial(serial) : !!serial;
    TCB.log(`[iframe] 激活 Tab 证书编号: ${serial || '（空）'} source=${source} plausible=${plausible}`);
    // 只要当前品面板内有编号即视为已上传；plausible 仅作诊断参考
    return !!serial;
  }

  function clickCloseInFrame() {
    const closeBtn = document.querySelector(CLOSE_BTN_SELECTOR);
    if (closeBtn) {
      TCB.clickElement(closeBtn, 'iframe 内关闭弹窗');
      return true;
    }
    return false;
  }

  async function doCheckSteps(source, reqId) {
    await TCB.sleep(800, '[iframe] 等待弹窗内容渲染（检查是否已上传）');
    const { serial: foundSerial, source: serialSource } = readActiveTabSerial();
    const alreadyUploaded = !!foundSerial;
    TCB.log(
      `[iframe] 证书编号读取: ${foundSerial || '（空）'} source=${serialSource} alreadyUploaded=${alreadyUploaded}`
    );

    let closedInFrame = false;
    if (alreadyUploaded) {
      closedInFrame = clickCloseInFrame();
      reportProgress(source, reqId, closedInFrame ? '已上传，iframe 内已点关闭' : '已上传，iframe 内未找到关闭按钮');
    }

    return { alreadyUploaded, closedInFrame, serial: foundSerial, serialSource };
  }

  function clickButtonRobustly(el) {
    const opts = { bubbles: true, cancelable: true, view: window };
    try {
      el.focus?.();
    } catch (e) {
      /* ignore */
    }
    el.dispatchEvent(new PointerEvent('pointerdown', opts));
    el.dispatchEvent(new MouseEvent('mousedown', opts));
    el.dispatchEvent(new PointerEvent('pointerup', opts));
    el.dispatchEvent(new MouseEvent('mouseup', opts));
    el.dispatchEvent(new MouseEvent('click', opts));
    if (typeof el.click === 'function') el.click();
    TCB.log(`👆 已对确定按钮派发完整点击事件（文字「${btnText(el)}」）`);
  }

  function isClickable(el) {
    if (!el) return false;
    if (el.disabled) return false;
    if (el.getAttribute('aria-disabled') === 'true') return false;
    if (el.className && /disabled/.test(el.className)) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function btnText(el) {
    return (el?.textContent || '').replace(/\s+/g, '').trim();
  }

  /** 优先用 selector，其次在 #item / 文档内按文字「确定」查找可点击的确定按钮 */
  function findConfirmButton() {
    const bySelector = document.querySelector(CONFIRM_BTN_SELECTOR);
    if (bySelector && CONFIRM_TEXTS.includes(btnText(bySelector)) && isClickable(bySelector)) {
      return bySelector;
    }

    const scopes = [document.querySelector('#item'), document];
    for (const scope of scopes) {
      if (!scope) continue;
      const buttons = Array.from(scope.querySelectorAll('button'));
      const match = buttons.find(
        (b) => CONFIRM_TEXTS.includes(btnText(b)) && isClickable(b)
      );
      if (match) return match;
    }

    // 兜底：selector 命中但文字不符也返回，便于日志排查
    if (bySelector) return bySelector;
    return null;
  }

  async function doUploadSteps(source, reqId) {
    await TCB.sleep(800, '[iframe] 等待弹窗内容渲染');
    const hit = await TCB.waitForAny(ADD_TAB_SELECTORS, 8000);
    if (!hit) {
      TCB.warn('[iframe] 未找到新增 Tab 按钮，打印诊断：');
      TCB.dumpFrameDiagnostics();
      throw new Error('未找到新增 Tab 按钮');
    }
    TCB.clickElement(hit.el, '新增证书 Tab 按钮');
    reportProgress(source, reqId, '已点击新增 Tab');
    TCB.log(`[iframe] 新增 Tab 按钮已点击: ${hit.selector}`);

    await TCB.sleep(1000, '[iframe] 点击新增 Tab 后等待上传区域渲染');
    const serial = await TCB.uploadCertificate();
    reportProgress(source, reqId, `已注入证书 ${serial}`);
    TCB.log(`[iframe] 证书图片已注入: ${serial}`);

    await TCB.sleep(2000, '[iframe] 注入证书后等待 2 秒再填编号');
    await TCB.fillSerialNumber(serial);
    reportProgress(source, reqId, `已填入证书编号 ${serial}`);
    TCB.log(`[iframe] 证书编号已填入: ${serial}`);

    const inst = await TCB.ensureInstitutionSelected();
    reportProgress(source, reqId, '已确认检测机构选项');
    TCB.log(`[iframe] 检测机构: ${inst || '（未选择/不存在）'}`);

    await TCB.sleep(1000, '[iframe] 填编号后等待 1 秒再点确定');

    let confirmBtn = document.querySelector(CONFIRM_BTN_SELECTOR);
    if (!confirmBtn) {
      confirmBtn = findConfirmButton();
    }
    if (!confirmBtn) {
      TCB.error('[iframe] 未找到「确定」按钮，selector: ' + CONFIRM_BTN_SELECTOR);
      throw new Error('未找到确定按钮');
    }
    TCB.log(
      `[iframe] 点击确定按钮，文字「${btnText(confirmBtn)}」disabled=${confirmBtn.disabled}`
    );
    clickButtonRobustly(confirmBtn);

    await TCB.sleep(1000, '[iframe] 点击确定后等待 1 秒');
    TCB.log(`✅ [iframe] 确定已点击，通知顶层检查弹窗 reqId=${reqId}`);
    source.postMessage({ tag: MSG_TAG, action: 'CERT_DONE', reqId, ok: true, serial }, '*');

    return serial;
  }

  let busy = false;

  window.addEventListener('message', async (event) => {
    const d = event.data;
    if (!d || d.tag !== MSG_TAG) return;

    const source = event.source;
    const reqId = d.reqId;

    if (d.action === 'DO_CHECK') {
      TCB.log(`📨 [iframe] 收到检查指令 reqId=${reqId}`);
      if (busy) {
        TCB.warn('[iframe] 正在处理中，忽略重复检查指令');
        return;
      }
      busy = true;
      try {
        const result = await doCheckSteps(source, reqId);
        TCB.log(`[iframe] DO_CHECK 完成: ${JSON.stringify(result)}`);
        source.postMessage(
          { tag: MSG_TAG, action: 'CERT_CHECK_DONE', reqId, ok: true, ...result },
          '*'
        );
      } catch (err) {
        TCB.error('[iframe] DO_CHECK 出错:', err.message);
        source.postMessage(
          { tag: MSG_TAG, action: 'CERT_CHECK_DONE', reqId, ok: false, error: err.message },
          '*'
        );
      } finally {
        busy = false;
      }
      return;
    }

    if (d.action === 'DO_UPLOAD') {
      TCB.log(`📨 [iframe] 收到上传指令 reqId=${reqId}`);
      if (busy) {
        TCB.warn('[iframe] 正在处理中，忽略重复上传指令');
        return;
      }
      busy = true;
      try {
        // 成功回执已在 doUploadSteps 内点击「确定」后立即发送
        const serial = await doUploadSteps(source, reqId);
        TCB.log(`✅ [iframe] 上传流程完成 reqId=${reqId} serial=${serial}`);
      } catch (err) {
        TCB.error('[iframe] 上传流程出错:', err.message, err);
        source.postMessage(
          { tag: MSG_TAG, action: 'CERT_DONE', reqId, ok: false, error: err.message },
          '*'
        );
      } finally {
        busy = false;
      }
    }
  });

  TCB.log('👂 [iframe] 已就绪，等待顶层页面的检查/上传指令');
})();
