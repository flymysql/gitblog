(function () {
  const TCB = window.TCB;
  if (!TCB) {
    console.error('[证书上传] sold-page.js: TCB 未就绪（helpers 未加载）');
    return;
  }

  const SOLD_PAGE_PATTERN = /\/home\.htm\/trade-platform\/tp\/sold/;
  const TAB_NAV_SELECTOR = 'ul.next-tabs-nav';
  const CERT_TAB_BTN_ID = 'tcb-auto-cert-tab';
  const MONITOR_PANEL_ID = 'tcb-monitor-panel';
  const NOTICE_BLOCK_SELECTORS = ['.sold_notice-block__yMQLw', '[class*="sold_notice-block"]'];
  const WATCH_POLL_INTERVAL_MS = 60000;

  TCB.log('🏪 sold-page.js 已注入，当前 URL:', location.href);

  let monitorPanel = null;
  let batchPaused = false;
  let isScanning = false;
  let buttonInjected = false;
  let shopAllowed = null;
  let soldHeartbeatTimer = null;
  let watchModeActive = false;
  let watchPollTimer = null;
  let watchPollCount = 0;
  let sessionRoundUploaded = 0;
  let cachedShopName = '';
  let lastMonitorState = null;
  let lastQueuedOrders = [];

  function startSoldHeartbeat() {
    stopSoldHeartbeat();
    soldHeartbeatTimer = setInterval(() => {
      chrome.runtime.sendMessage({ action: 'SOLD_HEARTBEAT' }, (resp) => {
        if (chrome.runtime.lastError) return;
        if (!watchModeActive && !resp?.active) stopSoldHeartbeat();
      });
    }, 45000);
  }

  function stopSoldHeartbeat() {
    if (soldHeartbeatTimer) {
      clearInterval(soldHeartbeatTimer);
      soldHeartbeatTimer = null;
    }
  }

  function startWatchPoll() {
    stopWatchPoll();
    if (!watchModeActive || batchPaused) return;
    watchPollTimer = setInterval(() => {
      pollForNewOrders();
    }, WATCH_POLL_INTERVAL_MS);
    TCB.log(`已启动待发货监控轮询，间隔 ${WATCH_POLL_INTERVAL_MS / 1000}s`);
  }

  function stopWatchPoll() {
    if (watchPollTimer) {
      clearInterval(watchPollTimer);
      watchPollTimer = null;
    }
  }

  function formatHeartbeatSub(message) {
    const parts = [];
    if (message.stage) parts.push(message.stage);
    if (message.detail) parts.push(message.detail);
    if (message.certIndex != null && message.certTotal != null) {
      parts.push(`证书 ${message.certIndex}/${message.certTotal}`);
    }
    if (message.attempt) parts.push(`第 ${message.attempt} 次尝试`);
    return parts.join(' · ');
  }

  function findNoticeBlockAnchor() {
    for (const sel of NOTICE_BLOCK_SELECTORS) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  async function loadDelaySettingIntoPanel(panel = monitorPanel) {
    if (!panel) return;
    const input = panel.querySelector('#tcb-delay-hours');
    if (!input) return;
    const delayMs = await TCB.getCertUploadDelayMs();
    input.value = String(delayMs / (60 * 60 * 1000));
  }

  async function onSaveDelayClick() {
    const panel = monitorPanel;
    if (!panel) return;
    const input = panel.querySelector('#tcb-delay-hours');
    const hours = parseFloat(input?.value);
    if (!Number.isFinite(hours) || hours < 0) {
      alert('请输入有效的延迟小时数（≥ 0）');
      return;
    }
    await TCB.setCertUploadDelayMs(hours * 60 * 60 * 1000);
    TCB.log(`证书注入延迟已保存：${hours} 小时`);
    const sub = panel.querySelector('#tcb-sub');
    if (sub) {
      sub.textContent = `注入延迟已更新为 ${hours} 小时`;
    }
    if (watchModeActive && !isScanning) {
      pollForNewOrders();
    }
  }

  function formatQueueSub(queued, delayMs) {
    if (!queued?.length) return '';
    const nextReadyAt = queued.reduce(
      (min, item) => Math.min(min, item.readyAt || Infinity),
      Infinity
    );
    const nextWait =
      nextReadyAt < Infinity ? TCB.formatDelayWait(nextReadyAt - Date.now()) : '';
    const delayHours = (delayMs / (60 * 60 * 1000)).toFixed(
      delayMs % (60 * 60 * 1000) === 0 ? 0 : 1
    );
    return `队列等待 ${queued.length} 个（延迟 ${delayHours} 小时）${
      nextWait ? `，最近 ${nextWait} 后可处理` : ''
    }`;
  }

  function updateQueueDisplay(queued, readyCount = 0, delayMs = 0, waitingCount = null) {
    if (queued?.length) lastQueuedOrders = queued;
    const queuedCount = queued?.length ?? waitingCount ?? 0;
    const el = monitorPanel?.querySelector('#tcb-queue-info');
    if (!el) return;
    if (!queuedCount && !readyCount) {
      el.textContent = '';
      el.style.display = 'none';
      return;
    }
    const parts = [];
    if (readyCount > 0) parts.push(`可处理 ${readyCount} 个`);
    if (queuedCount > 0) parts.push(`等待中 ${queuedCount} 个`);
    el.textContent = parts.join(' · ');
    el.style.display = 'block';
    if (delayMs && queuedCount > 0 && lastQueuedOrders.length) {
      el.title = formatQueueSub(lastQueuedOrders, delayMs);
    } else {
      el.title = '';
    }
  }

  async function processShipOrdersFlow(allOrders) {
    const delayMs = await TCB.getCertUploadDelayMs();
    const { pending, skipped } = await TCB.filterPendingShipOrders(allOrders);
    const { ready, queued } = TCB.splitOrdersByCreateDelay(pending, delayMs);
    lastQueuedOrders = queued;
    return {
      readyUrls: ready.map((o) => o.url),
      readyOrders: ready,
      queuedOrders: queued,
      skipped,
      delayMs,
    };
  }

  function ensureMonitorPanel() {
    if (monitorPanel && document.body.contains(monitorPanel)) return monitorPanel;

    const panel = document.createElement('div');
    panel.id = MONITOR_PANEL_ID;
    panel.className = 'tcb-monitor-panel';
    panel.innerHTML = `
      <div class="tcb-monitor-header">
        <div class="tcb-monitor-title-wrap">
          <h3 class="tcb-monitor-title">证书自动上传监控</h3>
          <span class="tcb-monitor-badge" id="tcb-monitor-mode">待机</span>
        </div>
        <div class="tcb-monitor-actions" id="tcb-monitor-actions">
          <button type="button" class="tcb-btn tcb-btn-warn tcb-btn-sm" id="tcb-pause">暂停</button>
          <button type="button" class="tcb-btn tcb-btn-danger tcb-btn-sm" id="tcb-cancel-batch">取消</button>
        </div>
      </div>
      <div class="tcb-monitor-stats">
        <div class="tcb-stat-item">
          <div class="tcb-stat-value" id="tcb-stat-orders">0</div>
          <div class="tcb-stat-label">历史完成订单</div>
        </div>
        <div class="tcb-stat-item">
          <div class="tcb-stat-value" id="tcb-stat-certs">0</div>
          <div class="tcb-stat-label">历史写入证书</div>
        </div>
        <div class="tcb-stat-item">
          <div class="tcb-stat-value" id="tcb-stat-session">0</div>
          <div class="tcb-stat-label">本轮新上传</div>
        </div>
        <div class="tcb-stat-item">
          <div class="tcb-stat-value" id="tcb-stat-polls">0</div>
          <div class="tcb-stat-label">监控刷新次数</div>
        </div>
      </div>
      <div class="tcb-monitor-progress-wrap">
        <div class="tcb-monitor-progress-bar">
          <div class="tcb-monitor-progress-fill" id="tcb-bar-fill"></div>
          <span class="tcb-monitor-progress-text" id="tcb-bar-text">0 / 0</span>
        </div>
      </div>
      <div class="tcb-monitor-settings">
        <label for="tcb-delay-hours">注入延迟</label>
        <input type="number" id="tcb-delay-hours" class="tcb-delay-input" min="0" step="0.5" value="1">
        <span class="tcb-delay-unit">小时</span>
        <button type="button" class="tcb-btn tcb-btn-sm tcb-btn-default" id="tcb-save-delay">保存</button>
        <span class="tcb-delay-hint">订单创建满该时间后才注入证书</span>
      </div>
      <div class="tcb-monitor-queue" id="tcb-queue-info"></div>
      <div class="tcb-monitor-detail" id="tcb-detail">准备中…</div>
      <div class="tcb-monitor-sub" id="tcb-sub"></div>
      <div class="tcb-monitor-tools">
        <button type="button" class="tcb-btn tcb-btn-sm tcb-btn-default" id="tcb-export-log">📦 导出日志包</button>
        <button type="button" class="tcb-btn tcb-btn-sm tcb-btn-default" id="tcb-upload-log">☁️ 上传日志包</button>
        <button type="button" class="tcb-btn tcb-btn-sm tcb-btn-default" id="tcb-cleanup-abnormal">🧹 清理异常记录</button>
        <button type="button" class="tcb-btn tcb-btn-sm tcb-btn-default" id="tcb-feedback">💬 提交反馈</button>
      </div>
      <div class="tcb-monitor-tool-msg" id="tcb-tool-msg"></div>
    `;

    const anchor = findNoticeBlockAnchor();
    if (anchor) {
      anchor.insertAdjacentElement('afterend', panel);
    } else {
      TCB.warn('未找到 sold_notice-block，监控面板降级插入到 body');
      document.body.insertBefore(panel, document.body.firstChild);
    }

    panel.querySelector('#tcb-pause').addEventListener('click', onPauseResumeClick);
    panel.querySelector('#tcb-cancel-batch').addEventListener('click', onCancelBatchClick);
    panel.querySelector('#tcb-save-delay').addEventListener('click', onSaveDelayClick);
    panel.querySelector('#tcb-export-log').addEventListener('click', onExportLogClick);
    panel.querySelector('#tcb-upload-log').addEventListener('click', onUploadLogClick);
    panel.querySelector('#tcb-cleanup-abnormal').addEventListener('click', onCleanupAbnormalClick);
    panel.querySelector('#tcb-feedback').addEventListener('click', onFeedbackClick);
    loadDelaySettingIntoPanel(panel);

    monitorPanel = panel;

    // 面板被 SPA 重渲染删除后重新创建时，恢复上一次的展示状态
    if (lastMonitorState) {
      applyMonitorState(lastMonitorState);
    }
    refreshHistoryStats();
    return panel;
  }

  function setMonitorMode(mode) {
    const badge = monitorPanel?.querySelector('#tcb-monitor-mode');
    if (!badge) return;
    const map = {
      processing: '处理中',
      watching: '监控中',
      paused: '已暂停',
      scanning: '扫描中',
      cancelled: '已取消',
      idle: '待机',
    };
    badge.textContent = map[mode] || mode;
    badge.className = `tcb-monitor-badge tcb-monitor-badge-${mode}`;
  }

  async function refreshHistoryStats() {
    const stats = await TCB.getCompletedShipStats();
    const panel = monitorPanel;
    if (!panel) return;
    const ordersEl = panel.querySelector('#tcb-stat-orders');
    const certsEl = panel.querySelector('#tcb-stat-certs');
    const sessionEl = panel.querySelector('#tcb-stat-session');
    const pollsEl = panel.querySelector('#tcb-stat-polls');
    if (ordersEl) ordersEl.textContent = String(stats.orderCount);
    if (certsEl) certsEl.textContent = String(stats.certUploaded);
    if (sessionEl) sessionEl.textContent = String(sessionRoundUploaded);
    if (pollsEl) pollsEl.textContent = String(watchPollCount);
  }

  // 仅负责把状态写入 DOM（不创建面板），供首次更新与重建后恢复复用
  function applyMonitorState(state) {
    const panel = monitorPanel;
    if (!panel || !document.body.contains(panel)) return;

    const { current = 0, total = 0, detail, sub, mode = 'processing', paused = false } = state;
    panel.style.display = 'block';
    panel.classList.toggle('tcb-monitor-paused', paused || batchPaused);
    setMonitorMode(paused || batchPaused ? 'paused' : mode);

    const pct = total > 0 ? Math.round((current / total) * 100) : 0;
    const fill = panel.querySelector('#tcb-bar-fill');
    const barText = panel.querySelector('#tcb-bar-text');
    const detailEl = panel.querySelector('#tcb-detail');
    const subEl = panel.querySelector('#tcb-sub');
    const actions = panel.querySelector('#tcb-monitor-actions');

    if (fill) fill.style.width = (mode === 'watching' && total === 0 ? 100 : pct) + '%';
    if (barText) {
      barText.textContent =
        mode === 'watching' && total === 0 ? '监控中' : `${current} / ${total}（${pct}%）`;
    }
    if (detail != null && detailEl) detailEl.textContent = detail;
    if (subEl) subEl.textContent = sub || '';
    if (actions) actions.style.display = watchModeActive ? 'flex' : 'none';

    if (state.queueReady != null || state.queueWaiting != null) {
      updateQueueDisplay(
        lastQueuedOrders,
        state.queueReady || 0,
        state.delayMs || 0,
        state.queueWaiting || 0
      );
    }

    setPauseButton(paused || batchPaused);
    refreshHistoryStats();
  }

  function updateMonitor(args) {
    // 合并保存最新状态，便于面板被 SPA 重渲染删除后完整恢复
    lastMonitorState = { ...(lastMonitorState || {}), ...args };
    ensureMonitorPanel();
    applyMonitorState(lastMonitorState);
  }

  function setPauseButton(paused) {
    batchPaused = paused;
    const panel = monitorPanel;
    if (!panel) return;
    const btn = panel.querySelector('#tcb-pause');
    if (btn) {
      btn.textContent = paused ? '继续' : '暂停';
      btn.classList.toggle('tcb-btn-resume', paused);
    }
  }

  function onPauseResumeClick() {
    if (batchPaused) {
      batchPaused = false;
      setPauseButton(false);
      chrome.runtime.sendMessage({ action: 'GET_BATCH_STATE' }, (state) => {
        if (state?.active && state.paused) {
          chrome.runtime.sendMessage({ action: 'RESUME_BATCH' }, (resp) => {
            if (!resp?.ok) {
              updateMonitor({ mode: 'watching', detail: '已恢复监控', sub: '', paused: false });
              startWatchPoll();
            }
          });
        } else {
          updateMonitor({
            mode: 'watching',
            detail: '已恢复自动监控',
            sub: '将继续刷新待发货列表并处理新订单',
            paused: false,
          });
          startWatchPoll();
        }
      });
      return;
    }

    batchPaused = true;
    stopWatchPoll();
    setPauseButton(true);
    chrome.runtime.sendMessage({ action: 'GET_BATCH_STATE' }, (state) => {
      if (state?.active) {
        chrome.runtime.sendMessage({ action: 'PAUSE_BATCH' }, (resp) => {
          if (resp?.ok) {
            updateMonitor({
              mode: 'paused',
              detail: '已暂停监控与批量处理',
              sub: '当前订单处理完后将停止，可点「继续」恢复',
              paused: true,
            });
          }
        });
      } else {
        updateMonitor({
          mode: 'paused',
          detail: '已暂停监控',
          sub: '点击「继续」恢复自动刷新待发货',
          paused: true,
        });
      }
    });
  }

  function onCancelBatchClick() {
    if (!confirm('确定要停止监控并取消任务吗？\n\n当前正在处理的订单会中断，历史记录不会回滚。')) {
      return;
    }
    watchModeActive = false;
    stopWatchPoll();
    stopSoldHeartbeat();
    chrome.runtime.sendMessage({ action: 'CANCEL_BATCH' }, () => {});
    updateMonitor({
      mode: 'cancelled',
      detail: '监控已停止',
      sub: '可再次点击「自动生成证书」重新启动',
    });
    batchPaused = false;
  }

  function setToolMsg(text, isError = false) {
    const el = monitorPanel?.querySelector('#tcb-tool-msg');
    if (!el) return;
    el.textContent = text || '';
    el.classList.toggle('tcb-tool-msg-error', !!isError);
  }

  /** 带超时的 background 消息发送（避免 MV3 下无响应永久卡住） */
  function sendBgMessage(payload, timeoutMs = 15000) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve({ ok: false, error: '操作超时（' + (timeoutMs / 1000) + 's 无响应），请重试' });
      }, timeoutMs);
      chrome.runtime.sendMessage(payload, (resp) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(resp || { ok: false, error: '无响应' });
      });
    });
  }

  /** 页面内下载 base64 zip（content script 无 chrome.downloads，走 blob URL + a 标签） */
  function downloadZipInPage(base64, filename) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type: 'application/zip' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  async function onExportLogClick() {
    const btn = monitorPanel?.querySelector('#tcb-export-log');
    if (btn) btn.disabled = true;
    setToolMsg('正在收集并打包日志…');
    sendBgMessage({ action: 'LOG_EXPORT' }, 20000).then((resp) => {
      if (btn) btn.disabled = false;
      if (!resp.ok) {
        setToolMsg('导出日志包失败：' + resp.error, true);
        TCB.error('导出日志包失败:', resp.error);
        return;
      }
      try {
        downloadZipInPage(resp.zipBase64, resp.filename);
        setToolMsg(`✅ 日志包已导出：${resp.filename}（共 ${resp.entryCount} 条日志）`);
        TCB.log('📦 日志包导出成功:', resp.filename);
      } catch (err) {
        setToolMsg(`导出失败：${err.message}`, true);
        TCB.error('下载日志包失败:', err.message);
      }
    });
  }

  async function onUploadLogClick() {
    const btn = monitorPanel?.querySelector('#tcb-upload-log');
    if (btn) btn.disabled = true;
    setToolMsg('正在上传日志包到云端…');
    sendBgMessage({ action: 'LOG_UPLOAD' }, 40000).then((resp) => {
      if (btn) btn.disabled = false;
      if (!resp.ok) {
        setToolMsg('上传失败：' + resp.error, true);
        TCB.error('上传日志包失败:', resp.error);
        return;
      }
      setToolMsg(`✅ 已上传：${resp.filename}（云端可拉取）`);
      TCB.log('☁️ 日志包上传成功:', resp.filename);
    });
  }

  /** 提交反馈：打开反馈页（带店铺名/版本预填） */
  function onFeedbackClick() {
    const FEEDBACK_URL = 'https://gitbolg-d7gmnsrw46e011706-1256429518.tcloudbaseapp.com/feedback.html';
    let url = FEEDBACK_URL;
    const params = new URLSearchParams();
    if (cachedShopName) params.set('shop', cachedShopName);
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
        params.set('version', chrome.runtime.getManifest().version || '');
      }
    } catch (e) { /* ignore */ }
    const qs = params.toString();
    if (qs) url += '?' + qs;
    window.open(url, '_blank');
    setToolMsg('💬 已打开反馈页，请描述遇到的问题');
  }

  async function onCleanupAbnormalClick() {
    if (
      !confirm(
        '将删除「完成记录」中疑似异常的订单（有失败标记 / 未找到证书按钮但无上传 / 批量发货 / 心跳超时）。\n\n这些订单将被重新扫描处理，确定继续？'
      )
    ) {
      return;
    }
    setToolMsg('正在清理异常记录…');
    sendBgMessage({ action: 'LOG_CLEANUP_ABNORMAL' }, 15000).then((resp) => {
      if (!resp.ok) {
        setToolMsg('清理失败：' + resp.error, true);
        return;
      }
      setToolMsg(`✅ 已移除 ${resp.removedCount} 条异常记录，保留 ${resp.keptCount} 条正常记录`);
      refreshHistoryStats();
    });
  }

  function showScanningModal(detail, sub) {
    const overlay = document.createElement('div');
    overlay.className = 'tcb-modal-overlay';
    overlay.innerHTML = `
      <div class="tcb-modal tcb-modal-scan">
        <h3>正在识别待发货列表</h3>
        <p id="tcb-scan-detail">${detail || '请稍候…'}</p>
        <p class="tcb-modal-sub" id="tcb-scan-sub">${sub || ''}</p>
        <div class="tcb-scan-spinner"></div>
      </div>
    `;
    document.body.appendChild(overlay);
    return {
      update(text, subText) {
        const d = overlay.querySelector('#tcb-scan-detail');
        const s = overlay.querySelector('#tcb-scan-sub');
        if (text && d) d.textContent = text;
        if (subText && s) s.textContent = subText;
      },
      close() {
        overlay.remove();
      },
    };
  }

  function showConfirmModal({ readyCount, queuedCount, pageCount, skippedCount, delayHours }, onConfirm, onCancel) {
    const pageHint =
      pageCount > 1 ? `（已扫描 <strong>${pageCount}</strong> 页列表）` : '';
    const skipHint =
      skippedCount > 0
        ? `<p class="tcb-modal-sub">其中 <strong>${skippedCount}</strong> 个订单此前已处理完成，将自动跳过。</p>`
        : '';
    const queueHint =
      queuedCount > 0
        ? `<p class="tcb-modal-sub">另有 <strong>${queuedCount}</strong> 个订单创建未满延迟时间，将先进入等待队列。</p>`
        : '';
    const countText =
      readyCount > 0
        ? `本次将先处理 <strong>${readyCount}</strong> 个，随后持续监控新待发货。`
        : queuedCount > 0
          ? `当前 <strong>${queuedCount}</strong> 个订单在等待队列，确认后将持续监控并在到期后自动处理。`
          : `当前无待处理订单，确认后将<strong>持续监控</strong>待发货列表并自动处理新订单。`;
    const overlay = document.createElement('div');
    overlay.className = 'tcb-modal-overlay';
    overlay.innerHTML = `
      <div class="tcb-modal">
        <h3>启动证书自动上传</h3>
        <p>识别到待发货订单${pageHint}。${countText}</p>
        ${skipHint}
        ${queueHint}
        <div class="tcb-modal-setting">
          <label for="tcb-confirm-delay-hours">证书注入延迟</label>
          <input type="number" id="tcb-confirm-delay-hours" class="tcb-delay-input" min="0" step="0.5" value="${delayHours}">
          <span class="tcb-delay-unit">小时</span>
          <p class="tcb-modal-sub">优先按订单创建时间判断：创建满该时间后才注入证书，未满则暂存队列。</p>
        </div>
        <p class="tcb-modal-sub">启动后监控面板将嵌入页面，请勿关闭本页。</p>
        <div class="tcb-modal-actions">
          <button class="tcb-btn tcb-btn-default" id="tcb-cancel">取消</button>
          <button class="tcb-btn tcb-btn-primary" id="tcb-start">开始</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    overlay.querySelector('#tcb-start').addEventListener('click', async () => {
      const hours = parseFloat(overlay.querySelector('#tcb-confirm-delay-hours').value);
      if (!Number.isFinite(hours) || hours < 0) {
        alert('请输入有效的延迟小时数（≥ 0）');
        return;
      }
      await TCB.setCertUploadDelayMs(hours * 60 * 60 * 1000);
      overlay.remove();
      onConfirm();
    });
    overlay.querySelector('#tcb-cancel').addEventListener('click', () => {
      overlay.remove();
      onCancel?.();
    });
  }

  function collectShipOrdersFromPage() {
    const seen = new Set();
    const orders = [];

    const addOrder = (url, orderId, createdAt, createdAtText) => {
      if (!url || seen.has(url)) return;
      seen.add(url);
      orders.push({ url, orderId, createdAt, createdAtText });
    };

    const tables = document.querySelectorAll('table.next-table-row');
    if (tables.length > 0) {
      tables.forEach((table) => {
        const header = table.querySelector('tr.next-table-group-header');
        if (!header) return;
        const createEl = header.querySelector('[class*="sold_create-time"]');
        const createText = createEl?.textContent?.trim() || '';
        const createdAt = TCB.parseOrderCreateTime(createText);
        const orderMatch = header.textContent.match(/订单号[：:]\s*(\d+)/);
        const orderId = orderMatch?.[1] || '';

        table.querySelectorAll('a[href]').forEach((a) => {
          if (a.textContent.replace(/\s+/g, '') !== '发货') return;
          const href = a.href;
          if (!href?.startsWith('http')) return;
          let id = orderId;
          try {
            const u = new URL(href);
            id =
              u.searchParams.get('tradeId') ||
              u.searchParams.get('ORDER_ID') ||
              u.searchParams.get('orderId') ||
              orderId;
          } catch {
            /* ignore */
          }
          addOrder(href, id, createdAt, createText);
        });
      });
      return orders;
    }

    TCB.findLinksByText('发货', true).forEach((a) => {
      if (!a.href?.startsWith('http')) return;
      let createdAt = null;
      let createdAtText = '';
      let orderId = '';
      const table = a.closest('table');
      if (table) {
        const header = table.querySelector('tr.next-table-group-header');
        if (header) {
          const createEl = header.querySelector('[class*="sold_create-time"]');
          createdAtText = createEl?.textContent?.trim() || '';
          createdAt = TCB.parseOrderCreateTime(createdAtText);
          const orderMatch = header.textContent.match(/订单号[：:]\s*(\d+)/);
          orderId = orderMatch?.[1] || '';
        }
      }
      addOrder(a.href, orderId, createdAt, createdAtText);
    });
    return orders;
  }

  function collectShipLinks() {
    return collectShipOrdersFromPage().map((o) => o.url);
  }

  function getPaginationButtons() {
    return Array.from(
      document.querySelectorAll('.next-pagination-list .next-pagination-item')
    ).filter((btn) => {
      const label = btn.getAttribute('aria-label') || '';
      return /第\d+页/.test(label);
    });
  }

  async function collectAllShipLinksAcrossPages() {
    const urlSet = new Set();
    const orders = [];
    const perPage = [];

    function addFromCurrentPage() {
      const pageOrders = collectShipOrdersFromPage();
      let added = 0;
      pageOrders.forEach((order) => {
        if (!urlSet.has(order.url)) {
          urlSet.add(order.url);
          orders.push(order);
          added += 1;
        }
      });
      return added;
    }

    const pageBtns = getPaginationButtons();
    const totalPages = pageBtns.length || 1;

    if (totalPages <= 1) {
      const n = addFromCurrentPage();
      perPage.push(n);
      return { orders, hrefs: orders.map((o) => o.url), totalPages: 1, perPage };
    }

    for (let i = 0; i < totalPages; i++) {
      const btn = pageBtns[i];
      const pageNum = i + 1;
      const isCurrent = btn.classList.contains('next-current');
      if (!isCurrent) {
        TCB.clickElement(btn, `分页第 ${pageNum} 页`);
        await TCB.sleep(2000, `切换到第 ${pageNum} 页后等待列表刷新`);
      }
      const added = addFromCurrentPage();
      perPage.push(added);
    }

    return { orders, hrefs: orders.map((o) => o.url), totalPages, perPage };
  }

  function findPendingShipTab() {
    const tabs = Array.from(document.querySelectorAll(`${TAB_NAV_SELECTOR} li.next-tabs-tab`));
    const tab = tabs.find((li) => {
      const text = li.textContent.replace(/\s+/g, '');
      return text.includes('待发货') && !li.classList.contains('tcb-cert-tab');
    });
    return tab?.querySelector('.next-tabs-tab-inner') || tab;
  }

  async function switchToPendingShipTab() {
    const tabBtn = findPendingShipTab();
    if (!tabBtn) {
      TCB.warn('未找到「待发货」Tab');
      return false;
    }
    TCB.clickElement(tabBtn, '「待发货」Tab');
    await TCB.sleep(2000, '切换/刷新待发货 Tab');
    return true;
  }

  async function isBatchActive() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'GET_BATCH_STATE' }, (resp) => {
        resolve(!!resp?.active);
      });
    });
  }

  function beginMonitoring({ shipUrls, skippedCount, totalPages, queuedCount = 0, delayMs = 0 }) {
    watchModeActive = true;
    watchPollCount = 0;
    sessionRoundUploaded = 0;
    cachedShopName = cachedShopName || '';

    TCB.log(
      `开始监控: shipUrls=${shipUrls.length} 历史跳过=${skippedCount} 队列=${queuedCount} delayMs=${delayMs}`
    );

    ensureMonitorPanel();
    refreshHistoryStats();
    startSoldHeartbeat();

    const queueSub = queuedCount > 0 ? formatQueueSub(lastQueuedOrders, delayMs) : '';
    updateMonitor({
      mode: shipUrls.length ? 'processing' : 'watching',
      current: 0,
      total: shipUrls.length,
      detail: shipUrls.length
        ? `开始处理 ${shipUrls.length} 个发货订单`
        : queuedCount > 0
          ? `暂无到期订单，${queuedCount} 个在队列等待`
          : '暂无待处理订单，已进入持续监控',
      sub: [
        skippedCount ? `已跳过 ${skippedCount} 个历史已完成订单` : '',
        queueSub,
        `每 ${WATCH_POLL_INTERVAL_MS / 1000}s 刷新待发货`,
      ]
        .filter(Boolean)
        .join(' · '),
      queueReady: shipUrls.length,
      queueWaiting: queuedCount,
      delayMs,
    });

    if (shipUrls.length > 0) {
      chrome.runtime.sendMessage(
        {
          action: 'START_BATCH',
          shipUrls,
          skippedAtStart: skippedCount,
          shopName: cachedShopName,
          watchMode: true,
        },
        (response) => {
          if (chrome.runtime.lastError) {
            TCB.error('START_BATCH 失败:', chrome.runtime.lastError.message);
            updateMonitor({
              mode: 'watching',
              detail: '启动批次失败',
              sub: chrome.runtime.lastError.message,
            });
            startWatchPoll();
            return;
          }
          if (!response?.ok) {
            TCB.error('START_BATCH 被拒绝:', response?.error || '未知错误');
            updateMonitor({
              mode: 'watching',
              detail: '启动批次失败',
              sub: response?.error || '未知错误',
            });
            startWatchPoll();
          } else {
            TCB.log('START_BATCH 已接受，后台开始逐个处理发货页');
          }
        }
      );
    } else {
      TCB.log('无到期订单，进入持续监控模式');
      startWatchPoll();
    }
  }

  async function pollForNewOrders() {
    if (!watchModeActive || batchPaused || isScanning) return;
    if (await isBatchActive()) {
      TCB.log('后台仍有批次进行中，跳过本轮监控扫描');
      return;
    }

    isScanning = true;
    watchPollCount += 1;
    updateMonitor({
      mode: 'scanning',
      detail: '正在刷新待发货列表…',
      sub: `第 ${watchPollCount} 次自动监控刷新`,
    });
    TCB.log(`🔁 开始第 ${watchPollCount} 次自动监控刷新`);

    try {
      await switchToPendingShipTab();
      const { orders: allOrders, totalPages } = await collectAllShipLinksAcrossPages();
      const { readyUrls, queuedOrders, skipped, delayMs } = await processShipOrdersFlow(allOrders);
      await refreshHistoryStats();
      TCB.log(
        `监控刷新 #${watchPollCount}: 共 ${allOrders.length} 个链接，可处理 ${readyUrls.length}，队列 ${queuedOrders.length}，历史跳过 ${skipped.length}`
      );

      if (readyUrls.length > 0) {
        stopWatchPoll();
        TCB.log(
          `监控发现 ${readyUrls.length} 个可处理订单（队列等待 ${queuedOrders.length} 个），自动开始处理`
        );
        updateMonitor({
          mode: 'processing',
          current: 0,
          total: readyUrls.length,
          detail: `发现 ${readyUrls.length} 个可处理订单，开始自动注入证书`,
          sub: [
            `本次监控刷新第 ${watchPollCount} 次`,
            queuedOrders.length ? formatQueueSub(queuedOrders, delayMs) : '',
          ]
            .filter(Boolean)
            .join(' · '),
          queueReady: readyUrls.length,
          queueWaiting: queuedOrders.length,
          delayMs,
        });
        chrome.runtime.sendMessage(
          {
            action: 'START_BATCH',
            shipUrls: readyUrls,
            skippedAtStart: skipped.length,
            shopName: cachedShopName,
            watchMode: true,
          },
          (response) => {
            if (chrome.runtime.lastError || !response?.ok) {
              TCB.error('监控发现新订单但 START_BATCH 失败:', chrome.runtime.lastError?.message || response?.error);
              updateMonitor({
                mode: 'watching',
                detail: '发现新订单但启动失败',
                sub: chrome.runtime.lastError?.message || response?.error || '',
                queueWaiting: queuedOrders.length,
                delayMs,
              });
              startWatchPoll();
            } else {
              TCB.log(`START_BATCH 成功，开始处理 ${readyUrls.length} 个订单`);
            }
          }
        );
      } else {
        TCB.log(`监控刷新 #${watchPollCount} 无可处理订单，继续监控`);
        updateMonitor({
          mode: 'watching',
          current: 0,
          total: 0,
          detail:
            queuedOrders.length > 0
              ? `持续监控中，${queuedOrders.length} 个订单等待创建满延迟`
              : '持续监控中，暂无新待发货',
          sub: [
            `已刷新 ${watchPollCount} 次`,
            skipped.length ? `历史已完成 ${skipped.length} 个` : '',
            queuedOrders.length ? formatQueueSub(queuedOrders, delayMs) : '',
          ]
            .filter(Boolean)
            .join(' · '),
          queueReady: 0,
          queueWaiting: queuedOrders.length,
          delayMs,
        });
        startWatchPoll();
      }
    } catch (err) {
      TCB.error('监控刷新失败:', err.message);
      updateMonitor({
        mode: 'watching',
        detail: '监控刷新出错',
        sub: err.message,
      });
      startWatchPoll();
    } finally {
      isScanning = false;
      refreshHistoryStats();
    }
  }

  async function waitForTabNav(timeout = 20000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const nav = document.querySelector(TAB_NAV_SELECTOR);
      if (nav && nav.querySelectorAll('li.next-tabs-tab').length > 0) return nav;
      await TCB.sleep(300);
    }
    return null;
  }

  function removeCertButton() {
    const btn = document.getElementById(CERT_TAB_BTN_ID);
    if (btn) btn.remove();
    buttonInjected = false;
  }

  async function refreshShopAuth() {
    const auth = await TCB.ensureShopAllowed();
    shopAllowed = !!auth.allowed;
    if (auth.shopName) cachedShopName = auth.shopName;
    if (!shopAllowed) {
      removeCertButton();
    }
    return auth;
  }

  function injectCertButton() {
    if (!shopAllowed) return false;
    const tabNav = document.querySelector(TAB_NAV_SELECTOR);
    if (!tabNav) return false;
    if (document.getElementById(CERT_TAB_BTN_ID)) return true;

    const li = document.createElement('li');
    li.role = 'tab';
    li.tabIndex = -1;
    li.className = 'next-tabs-tab tcb-cert-tab';
    li.id = CERT_TAB_BTN_ID;
    li.innerHTML = '<div class="next-tabs-tab-inner tcb-cert-tab-inner">自动生成证书</div>';
    li.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onCertButtonClick();
    });
    tabNav.insertBefore(li, tabNav.firstChild);
    buttonInjected = true;
    return true;
  }

  function setCertButtonEnabled(enabled) {
    const btn = document.getElementById(CERT_TAB_BTN_ID);
    if (!btn) return;
    btn.classList.toggle('tcb-cert-tab-disabled', !enabled);
    btn.style.pointerEvents = enabled ? '' : 'none';
    btn.style.opacity = enabled ? '' : '0.6';
  }

  async function onCertButtonClick() {
    if (isScanning || watchModeActive) return;
    if (!shopAllowed) return;

    const auth = await TCB.ensureShopAllowed();
    if (!auth.allowed) {
      shopAllowed = false;
      removeCertButton();
      TCB.warn('店铺未授权，移除自动证书按钮:', auth.shopName || '(未识别)');
      return;
    }
    cachedShopName = auth.shopName || cachedShopName;

    isScanning = true;
    setCertButtonEnabled(false);
    const scanModal = showScanningModal('正在识别待发货列表数量…', '准备切换到「待发货」Tab');
    TCB.log('👆 用户点击「自动生成证书」，开始扫描待发货列表');

    try {
      await switchToPendingShipTab();
      scanModal.update('正在扫描发货按钮…', '如有分页将自动逐页统计');

      const { orders: allOrders, totalPages, perPage } = await collectAllShipLinksAcrossPages();
      const { readyUrls, queuedOrders, skipped, delayMs } = await processShipOrdersFlow(allOrders);
      TCB.log(
        `扫描完成：共 ${allOrders.length} 个链接，可处理 ${readyUrls.length}，队列 ${queuedOrders.length}，历史跳过 ${skipped.length}，页数 ${totalPages}`,
        { perPage, delayHours: delayMs / 3600000 }
      );

      scanModal.close();

      if (allOrders.length === 0) {
        TCB.warn('扫描到 0 个待发货按钮，弹出提示');
        alert('未找到待发货按钮，请确认当前在「待发货」列表且页面已加载完成。');
        return;
      }

      const delayHours = delayMs / (60 * 60 * 1000);
      showConfirmModal(
        {
          readyCount: readyUrls.length,
          queuedCount: queuedOrders.length,
          pageCount: totalPages,
          skippedCount: skipped.length,
          delayHours,
        },
        () => {
          TCB.log(`用户确认启动，开始处理 ${readyUrls.length} 个订单`);
          beginMonitoring({
            shipUrls: readyUrls,
            skippedCount: skipped.length,
            totalPages,
            queuedCount: queuedOrders.length,
            delayMs,
          });
        }
      );
    } catch (err) {
      TCB.error('扫描待发货列表异常:', err.message);
      scanModal.close();
      alert(`扫描出错：${err.message}`);
    } finally {
      isScanning = false;
      setCertButtonEnabled(true);
    }
  }

  let domObserver = null;
  let ensureTimer = null;
  let authResolved = false;

  function startDomObserver() {
    if (domObserver) return;
    domObserver = new MutationObserver(() => {
      if (!SOLD_PAGE_PATTERN.test(location.href)) return;
      if (shopAllowed && !document.getElementById(CERT_TAB_BTN_ID)) {
        injectCertButton();
      }
      if (watchModeActive && !document.getElementById(MONITOR_PANEL_ID)) {
        ensureMonitorPanel();
      }
    });
    domObserver.observe(document.body, { childList: true, subtree: true });
  }

  // 持续确保按钮出现：SPA 首次进入时店铺名/Tab 栏可能异步渲染，
  // 单次初始化会因 return 而永不重试，这里用轮询直到鉴权成功并注入按钮。
  async function ensureCertButtonLoop() {
    if (!SOLD_PAGE_PATTERN.test(location.href)) return;

    const nav = document.querySelector(TAB_NAV_SELECTOR);
    if (!nav || nav.querySelectorAll('li.next-tabs-tab').length === 0) return;

    if (!authResolved || !shopAllowed) {
      const auth = await refreshShopAuth();
      if (auth.allowed) {
        authResolved = true;
      } else if (auth.shopName) {
        // 已读到店铺名但不在白名单 → 确定拒绝，停止重试
        authResolved = true;
        return;
      } else {
        // 店铺名还没加载出来，下次轮询再试
        return;
      }
    }

    if (shopAllowed && !document.getElementById(CERT_TAB_BTN_ID)) {
      injectCertButton();
    }

    // 监控进行中但面板被 SPA 重渲染删除 → 重建并恢复状态
    if (watchModeActive && !document.getElementById(MONITOR_PANEL_ID)) {
      ensureMonitorPanel();
      if (lastMonitorState) applyMonitorState(lastMonitorState);
    }
  }

  function setupSoldPage() {
    startDomObserver();
    ensureCertButtonLoop();
    if (ensureTimer) clearInterval(ensureTimer);
    ensureTimer = setInterval(ensureCertButtonLoop, 1500);
  }

  // 监听 SPA 路由变化（pushState/replaceState/popstate），切回已卖出页时重新初始化
  function hookSpaNavigation() {
    let lastUrl = location.href;
    const onUrlMaybeChanged = () => {
      if (location.href === lastUrl) return;
      lastUrl = location.href;
      if (SOLD_PAGE_PATTERN.test(location.href)) {
        authResolved = false;
        ensureCertButtonLoop();
      }
    };
    const origPush = history.pushState;
    const origReplace = history.replaceState;
    history.pushState = function (...args) {
      const r = origPush.apply(this, args);
      setTimeout(onUrlMaybeChanged, 0);
      return r;
    };
    history.replaceState = function (...args) {
      const r = origReplace.apply(this, args);
      setTimeout(onUrlMaybeChanged, 0);
      return r;
    };
    window.addEventListener('popstate', onUrlMaybeChanged);
    window.addEventListener('hashchange', onUrlMaybeChanged);
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'WHITELIST_UPDATED') {
      authResolved = false;
      shopAllowed = null;
      ensureCertButtonLoop();
      return;
    }

    // 有新版本可用 → 监控面板显示更新提示
    if (message.action === 'TCB_UPDATE_AVAILABLE') {
      setToolMsg(`🔄 发现新版本 v${message.version}，点击弹窗「下载更新」升级`, false);
      return;
    }

    if (message.action === 'TASK_HEARTBEAT') {
      const sub = formatHeartbeatSub(message);
      updateMonitor({
        mode: 'processing',
        current: message.shipIndex ? Math.max(0, message.shipIndex - 1) : message.current ?? 0,
        total: message.shipTotal ?? message.total ?? 0,
        detail: message.shipIndex
          ? `正在处理第 ${message.shipIndex} / ${message.shipTotal} 个发货订单`
          : `正在处理订单`,
        sub: sub ? `💓 ${sub}` : '💓 处理中…',
        paused: batchPaused,
      });
    }

    if (message.action === 'SHIP_PROGRESS') {
      refreshHistoryStats();
      const certParts = [];
      if (message.certTotal != null) {
        certParts.push(`证书 ${message.certTotal} 个`);
        certParts.push(`新上传 ${message.certUploaded ?? 0}`);
        certParts.push(`已存在跳过 ${message.certSkipped ?? 0}`);
        if (message.certFailed) {
          certParts.push(`失败 ${message.certFailed}⚠️`);
        }
      }
      if (message.noCertButtons) {
        certParts.length = 0;
        if (message.skipReason === 'batch-consign') {
          certParts.push(message.skipMessage || '批量发货页，已自动跳过');
        } else if (message.skipReason === 'heartbeat-timeout') {
          certParts.push(message.skipMessage || '超过 3 分钟无进展，已自动跳过');
        } else {
          certParts.push('⚠️ 本单未找到证书按钮，未记完成，将重新扫描');
        }
      }
      const timeoutHint =
        message.skipReason === 'heartbeat-timeout' || message.timedOut ? '⏱ 超时跳过 · ' : '';
      const sub = certParts.length
        ? `${timeoutHint}${message.errored ? '⚠️ 出错跳过 · ' : ''}刚完成：${certParts.join(' · ')}`
        : '';
      const hasFailure = (message.certFailed ?? 0) > 0 || !!message.noCertButtons;
      updateMonitor({
        mode: watchModeActive ? 'processing' : 'processing',
        current: message.current,
        total: message.total,
        detail: hasFailure
          ? `已完成 ${message.current} / ${message.total} 个发货订单（其中 ${message.certFailed ?? 0} 个证书失败，稍后将重试）`
          : `已完成 ${message.current} / ${message.total} 个发货订单`,
        sub,
        paused: message.paused,
      });
    }

    if (message.action === 'BATCH_PAUSED') {
      setPauseButton(true);
      stopWatchPoll();
      updateMonitor({
        current: message.current,
        total: message.total,
        detail: `已暂停 · 已完成 ${message.current} / ${message.total}`,
        sub: '点击「继续」恢复监控与批量处理',
        mode: 'paused',
        paused: true,
      });
    }

    if (message.action === 'BATCH_RESUMED') {
      setPauseButton(false);
      updateMonitor({
        current: message.current,
        total: message.total,
        detail: `已恢复 · 继续处理 ${message.current} / ${message.total}`,
        sub: '监控与批量处理已恢复',
        mode: 'processing',
        paused: false,
      });
      startWatchPoll();
    }

    if (message.action === 'BATCH_CANCELLED') {
      watchModeActive = false;
      stopWatchPoll();
      stopSoldHeartbeat();
      updateMonitor({
        current: message.current ?? 0,
        total: message.total ?? 0,
        detail: '监控已取消',
        sub: '剩余订单未处理',
        mode: 'cancelled',
      });
      batchPaused = false;
    }

    if (message.action === 'BATCH_COMPLETE') {
      if (message.sessionStats?.uploaded) {
        sessionRoundUploaded += message.sessionStats.uploaded;
      }
      refreshHistoryStats();

      const failedCount = message.sessionStats?.failed ?? 0;
      const failHint =
        failedCount > 0
          ? `，其中 <strong>${failedCount}</strong> 个证书失败（稍后监控会自动重新扫描这些订单）`
          : '';

      if (message.watchMode || watchModeActive) {
        const queueHint =
          lastQueuedOrders.length > 0
            ? ` · ${formatQueueSub(lastQueuedOrders, lastMonitorState?.delayMs || TCB.DEFAULT_CERT_DELAY_MS)}`
            : '';
        updateMonitor({
          current: message.total ?? 0,
          total: message.total ?? 0,
          detail: `本轮 ${message.total ?? 0} 个订单处理完成${failHint}`,
          sub: `本轮新上传 ${message.sessionStats?.uploaded ?? 0} 个证书 · 继续监控新待发货…${queueHint}`,
          mode: 'watching',
          queueWaiting: lastQueuedOrders.length,
        });
        startWatchPoll();
      } else {
        stopSoldHeartbeat();
        updateMonitor({
          current: message.total ?? 0,
          total: message.total ?? 0,
          detail: `全部处理完成${failHint}`,
          sub: failedCount > 0 ? '部分证书失败，可点击「清理异常记录」后重新扫描' : '任务已结束',
          mode: failedCount > 0 ? 'watching' : 'idle',
        });
      }
      batchPaused = false;
    }
  });

  hookSpaNavigation();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupSoldPage);
    window.addEventListener('load', setupSoldPage);
  } else {
    setupSoldPage();
    window.addEventListener('load', setupSoldPage);
  }
})();
