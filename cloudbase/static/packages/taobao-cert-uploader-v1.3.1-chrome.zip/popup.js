const loginPanel = document.getElementById('login-panel');
const managePanel = document.getElementById('manage-panel');
const passwordInput = document.getElementById('admin-password');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('logout-btn');
const shopNameInput = document.getElementById('shop-name');
const addShopBtn = document.getElementById('add-shop-btn');
const exportCrxBtn = document.getElementById('export-crx-btn');
const actionMessage = document.getElementById('action-message');
const passwordMessage = document.getElementById('password-message');
const oldPasswordInput = document.getElementById('old-password');
const newPasswordInput = document.getElementById('new-password');
const confirmPasswordInput = document.getElementById('confirm-password');
const changePasswordBtn = document.getElementById('change-password-btn');
const injectedListEl = document.getElementById('injected-list');
const builtinListEl = document.getElementById('builtin-list');
const removedListEl = document.getElementById('removed-list');
const injectedEmptyEl = document.getElementById('injected-empty');
const removedEmptyEl = document.getElementById('removed-empty');
const injectedCountEl = document.getElementById('injected-count');
const builtinCountEl = document.getElementById('builtin-count');
const removedCountEl = document.getElementById('removed-count');
const exportLogBtn = document.getElementById('export-log-btn');
const uploadLogBtn = document.getElementById('upload-log-btn');
const cleanupAbnormalBtn = document.getElementById('cleanup-abnormal-btn');
const logMessage = document.getElementById('log-message');
const updatePanel = document.getElementById('update-panel');
const updateVersionEl = document.getElementById('update-version');
const updateDownloadBtn = document.getElementById('update-download-btn');
const feedbackBtn = document.getElementById('feedback-btn');

// —— 提交反馈入口 ——
feedbackBtn.addEventListener('click', () => {
  const FEEDBACK_URL = 'https://gitbolg-d7gmnsrw46e011706-1256429518.tcloudbaseapp.com/feedback.html';
  const params = new URLSearchParams();
  try {
    params.set('version', chrome.runtime.getManifest().version || '');
  } catch (e) { /* ignore */ }
  const qs = params.toString();
  window.open(FEEDBACK_URL + (qs ? '?' + qs : ''), '_blank');
});

// —— 自动更新检查 ——
function checkUpdate() {
  sendMessage({ action: 'UPDATE_CHECK' }, 20000).then((resp) => {
    if (!resp || !resp.ok) return;
    if (resp.hasUpdate) {
      updateVersionEl.textContent = `${resp.currentVersion} → ${resp.latestVersion}`;
      updatePanel.hidden = false;
    } else {
      updatePanel.hidden = true;
    }
  });
}
updateDownloadBtn.addEventListener('click', () => {
  updateDownloadBtn.disabled = true;
  sendMessage({ action: 'UPDATE_DOWNLOAD', which: 'chrome' }, 30000).then((resp) => {
    updateDownloadBtn.disabled = false;
    if (resp && resp.ok) {
      updatePanel.hidden = true;
      alert('已开始下载新版安装包，请解压后到 chrome://extensions 重新加载。\n\n下载完成后，把解压出的文件夹在扩展页重新「加载已解压的扩展程序」即可完成更新。');
    } else {
      alert('下载失败：' + (resp && resp.error) || '未知错误');
    }
  });
});

function sendMessage(payload, timeoutMs = 15000) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false, error: '操作超时（' + (timeoutMs / 1000) + 's 无响应），请重试' });
    }, timeoutMs);
    chrome.runtime.sendMessage(payload, (response) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: '无响应' });
    });
  });
}

function showLoginError(text) {
  loginError.hidden = !text;
  loginError.textContent = text || '';
}

function showActionMessage(text, isError = false) {
  actionMessage.hidden = !text;
  actionMessage.textContent = text || '';
  actionMessage.classList.toggle('is-error', !!isError);
}

function showPasswordMessage(text, isError = false) {
  passwordMessage.hidden = !text;
  passwordMessage.textContent = text || '';
  passwordMessage.classList.toggle('is-error', !!isError);
}

function showLogMessage(text, isError = false) {
  logMessage.hidden = !text;
  logMessage.textContent = text || '';
  logMessage.classList.toggle('is-error', !!isError);
}

function handleAuthFailure(response) {
  if (response?.needLogin) {
    showLoginPanel();
    showLoginError(response.error || '请重新输入管理密码');
    return true;
  }
  return false;
}

function formatExportMessage(response) {
  if (!response?.filename) return '';
  return `已打开另存为：${response.filename}`;
}

function downloadCrxInPopup(crxBase64, filename) {
  const binary = atob(crxBase64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([bytes], { type: 'application/x-chrome-extension' }));
  return new Promise((resolve, reject) => {
    chrome.downloads.download(
      {
        url,
        filename,
        saveAs: true,
        conflictAction: 'uniquify',
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          URL.revokeObjectURL(url);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        resolve({ ok: true, downloadId, filename });
      }
    );
  });
}

/** 通用：把 background 返回的 base64 字节流下载为文件（弹窗优先走 chrome.downloads） */
function downloadBase64AsFile(base64, filename, mime = 'application/zip') {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  return new Promise((resolve, reject) => {
    if (typeof chrome !== 'undefined' && chrome.downloads && typeof chrome.downloads.download === 'function') {
      chrome.downloads.download(
        { url, filename, saveAs: true, conflictAction: 'uniquify' },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            URL.revokeObjectURL(url);
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          setTimeout(() => URL.revokeObjectURL(url), 60000);
          resolve({ ok: true, downloadId, filename });
        }
      );
      return;
    }
    // 兜底：a 标签
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    resolve({ ok: true, filename });
  });
}

function renderList(container, items, options = {}) {
  container.innerHTML = '';
  items.forEach((name) => {
    const li = document.createElement('li');
    const label = document.createElement('span');
    label.textContent = name;
    li.appendChild(label);

    if (options.removable) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'popup-btn popup-btn-danger';
      btn.textContent = options.removeLabel || '移除';
      btn.addEventListener('click', () => options.onRemove(name));
      li.appendChild(btn);
    }

    container.appendChild(li);
  });
}

async function loadWhitelistView() {
  const response = await sendMessage({ action: 'WHITELIST_GET_ALL' });
  if (!response.ok) {
    if (handleAuthFailure(response)) return;
    showActionMessage(response.error || '加载白名单失败', true);
    return;
  }

  const injected = response.injected || [];
  const activeBuiltin = response.activeBuiltin || [];
  const removedBuiltin = response.removedBuiltin || [];

  injectedCountEl.textContent = String(injected.length);
  builtinCountEl.textContent = String(activeBuiltin.length);
  removedCountEl.textContent = String(removedBuiltin.length);
  injectedEmptyEl.hidden = injected.length > 0;
  removedEmptyEl.hidden = removedBuiltin.length > 0;

  renderList(injectedListEl, injected, {
    removable: true,
    onRemove: removeInjectedShop,
  });
  renderList(builtinListEl, activeBuiltin, {
    removable: true,
    removeLabel: '移除',
    onRemove: removeBuiltinShop,
  });
  renderList(removedListEl, removedBuiltin, {
    removable: true,
    removeLabel: '恢复',
    onRemove: restoreBuiltinShop,
  });
}

function showManagePanel() {
  loginPanel.hidden = true;
  managePanel.hidden = false;
  showLoginError('');
  loadWhitelistView();
}

function showLoginPanel() {
  loginPanel.hidden = false;
  managePanel.hidden = true;
  passwordInput.value = '';
  showActionMessage('');
  showPasswordMessage('');
}

async function checkSession() {
  const response = await sendMessage({ action: 'WHITELIST_SESSION_STATUS' });
  if (response.ok && response.authenticated) {
    showManagePanel();
  } else {
    showLoginPanel();
  }
}

async function login() {
  const password = passwordInput.value.trim();
  if (!password) {
    showLoginError('请输入管理密码');
    return;
  }

  loginBtn.disabled = true;
  const response = await sendMessage({ action: 'WHITELIST_LOGIN', password });
  loginBtn.disabled = false;

  if (!response.ok) {
    showLoginError(response.error || '密码错误');
    return;
  }

  passwordInput.value = '';
  showManagePanel();
}

async function logout() {
  await sendMessage({ action: 'WHITELIST_LOGOUT' });
  showLoginPanel();
}

async function handleMutationResponse(response, successPrefix) {
  if (!response.ok) {
    if (handleAuthFailure(response)) return;
    showActionMessage(response.error || '操作失败', true);
    return;
  }

  showActionMessage(successPrefix);
  await loadWhitelistView();
}

async function addShop() {
  const name = shopNameInput.value.trim();
  if (!name) {
    showActionMessage('请输入店铺名', true);
    return;
  }

  addShopBtn.disabled = true;
  const response = await sendMessage({ action: 'WHITELIST_ADD', shopName: name });
  addShopBtn.disabled = false;

  if (!response.ok) {
    if (handleAuthFailure(response)) return;
    showActionMessage(response.error || '注入失败', true);
    return;
  }

  shopNameInput.value = '';
  shopNameInput.focus();
  await handleMutationResponse(response, `已注入：${response.added}（可继续添加）`);
}

async function removeInjectedShop(name) {
  const response = await sendMessage({ action: 'WHITELIST_REMOVE', shopName: name });
  await handleMutationResponse(response, `已移除注入店铺：${name}`);
}

async function removeBuiltinShop(name) {
  const response = await sendMessage({ action: 'WHITELIST_REMOVE_BUILTIN', shopName: name });
  await handleMutationResponse(response, `已移除内置店铺：${name}`);
}

async function restoreBuiltinShop(name) {
  const response = await sendMessage({ action: 'WHITELIST_RESTORE_BUILTIN', shopName: name });
  await handleMutationResponse(response, `已恢复内置店铺：${name}`);
}

async function exportCrx() {
  exportCrxBtn.disabled = true;
  const response = await sendMessage({ action: 'WHITELIST_EXPORT_CRX' });
  exportCrxBtn.disabled = false;

  if (!response.ok) {
    if (handleAuthFailure(response)) return;
    showActionMessage(response.error || '导出失败', true);
    return;
  }

  try {
    await downloadCrxInPopup(response.crxBase64, response.filename);
    showActionMessage(formatExportMessage(response) || '已触发 CRX 导出');
  } catch (err) {
    showActionMessage(`导出 CRX 失败：${err.message}`, true);
  }
}

async function changePassword() {
  const oldPassword = oldPasswordInput.value;
  const newPassword = newPasswordInput.value;
  const confirmPassword = confirmPasswordInput.value;

  if (!oldPassword || !newPassword || !confirmPassword) {
    showPasswordMessage('请填写完整的密码信息', true);
    return;
  }
  if (newPassword !== confirmPassword) {
    showPasswordMessage('两次输入的新密码不一致', true);
    return;
  }
  if (newPassword.length < 4) {
    showPasswordMessage('新密码至少 4 位', true);
    return;
  }

  changePasswordBtn.disabled = true;
  const response = await sendMessage({
    action: 'WHITELIST_CHANGE_PASSWORD',
    oldPassword,
    newPassword,
  });
  changePasswordBtn.disabled = false;

  if (!response.ok) {
    if (handleAuthFailure(response)) return;
    showPasswordMessage(response.error || '密码更新失败', true);
    return;
  }

  oldPasswordInput.value = '';
  newPasswordInput.value = '';
  confirmPasswordInput.value = '';
  showPasswordMessage('密码已更新，请牢记新密码');
}

async function exportLog() {
  exportLogBtn.disabled = true;
  showLogMessage('正在收集并打包日志…');
  const response = await sendMessage({ action: 'LOG_EXPORT' });
  exportLogBtn.disabled = false;

  if (!response.ok) {
    showLogMessage(response.error || '导出日志包失败', true);
    return;
  }

  try {
    await downloadBase64AsFile(response.zipBase64, response.filename, 'application/zip');
    showLogMessage(`✅ 日志包已导出：${response.filename}（共 ${response.entryCount} 条日志）`);
  } catch (err) {
    showLogMessage(`导出失败：${err.message}`, true);
  }
}

async function uploadLog() {
  uploadLogBtn.disabled = true;
  showLogMessage('正在上传日志包到云端…');
  const response = await sendMessage({ action: 'LOG_UPLOAD' });
  uploadLogBtn.disabled = false;

  if (!response.ok) {
    showLogMessage(response.error || '上传日志包失败', true);
    return;
  }
  showLogMessage(`✅ 已上传：${response.filename}（可在云端拉取）`);
}

async function cleanupAbnormal() {
  if (!confirm('将删除「完成记录」中疑似异常的订单（有失败标记 / 未找到证书按钮但无上传 / 批量发货 / 心跳超时）。\n\n这些订单将被重新扫描处理，确定继续？')) {
    return;
  }
  cleanupAbnormalBtn.disabled = true;
  showLogMessage('正在清理异常记录…');
  const response = await sendMessage({ action: 'LOG_CLEANUP_ABNORMAL' });
  cleanupAbnormalBtn.disabled = false;

  if (!response.ok) {
    showLogMessage(response.error || '清理失败', true);
    return;
  }
  showLogMessage(`✅ 已移除 ${response.removedCount} 条异常记录，保留 ${response.keptCount} 条正常记录`);
}

loginBtn.addEventListener('click', login);
logoutBtn.addEventListener('click', logout);
addShopBtn.addEventListener('click', addShop);
exportCrxBtn.addEventListener('click', exportCrx);
changePasswordBtn.addEventListener('click', changePassword);
exportLogBtn.addEventListener('click', exportLog);
uploadLogBtn.addEventListener('click', uploadLog);
cleanupAbnormalBtn.addEventListener('click', cleanupAbnormal);
passwordInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') login();
});
shopNameInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') addShop();
});

checkSession();
checkUpdate();
