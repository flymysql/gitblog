(function () {
const TCB = window.TCB || {};
const LOGGER = window.TCBLogger || null;

function tcbTimestamp() {
  const d = new Date();
  const pad = (n, l = 2) => String(n).padStart(l, '0');
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
}

TCB.log = function log(...args) {
  console.log(`%c[证书上传 ${tcbTimestamp()}]`, 'color:#1677ff;font-weight:bold', ...args);
  if (LOGGER) {
    LOGGER.log('log', 'TCB.log', args.length === 1 ? args[0] : args);
  }
};

TCB.warn = function warn(...args) {
  console.warn(`[证书上传 ${tcbTimestamp()}]`, ...args);
  if (LOGGER) {
    LOGGER.warn('TCB.warn', args.length === 1 ? args[0] : args);
  }
};

TCB.error = function error(...args) {
  console.error(`[证书上传 ${tcbTimestamp()}]`, ...args);
  if (LOGGER) {
    LOGGER.error('TCB.error', args.length === 1 ? args[0] : args);
  }
};

TCB.sleep = function sleep(ms, label) {
  if (label) TCB.log(`⏳ 等待 ${ms}ms（${label}）`);
  return new Promise((resolve) => setTimeout(resolve, ms));
};

TCB.waitForSelector = async function waitForSelector(selector, timeout = 15000) {
  TCB.log(`🔍 开始等待元素: ${selector}（超时 ${timeout}ms）`);
  const start = Date.now();
  let attempts = 0;
  while (Date.now() - start < timeout) {
    attempts += 1;
    const el = document.querySelector(selector);
    if (el) {
      TCB.log(`✅ 找到元素（第 ${attempts} 次尝试，耗时 ${Date.now() - start}ms）: ${selector}`);
      return el;
    }
    await TCB.sleep(200);
  }
  TCB.error(`❌ 等待元素超时（${attempts} 次尝试）: ${selector}`);
  throw new Error(`等待元素超时: ${selector}`);
};

TCB.waitForAny = async function waitForAny(selectors, timeout = 8000) {
  const list = Array.isArray(selectors) ? selectors : [selectors];
  TCB.log(`🔍 等待任一元素出现（超时 ${timeout}ms）:`, list);
  const start = Date.now();
  while (Date.now() - start < timeout) {
    for (const sel of list) {
      const el = document.querySelector(sel);
      if (el) {
        TCB.log(`✅ 命中候选 selector（耗时 ${Date.now() - start}ms）: ${sel}`);
        return { el, selector: sel };
      }
    }
    await TCB.sleep(200);
  }
  return null;
};

TCB.dumpFrameDiagnostics = function dumpFrameDiagnostics() {
  const isTop = window.top === window;
  TCB.warn(`🧭 诊断信息 —— 当前是否顶层框架: ${isTop}`);

  const iframes = Array.from(document.querySelectorAll('iframe'));
  TCB.warn(`页面 iframe 数量: ${iframes.length}`);
  iframes.forEach((f, i) => {
    let accessible = false;
    try {
      accessible = !!f.contentDocument;
    } catch (e) {
      accessible = false;
    }
    TCB.warn(`  iframe[${i}] src=${f.src || '(空)'} 同源可访问=${accessible}`);
  });

  const checks = {
    '#ice-container': document.querySelector('#ice-container'),
    '#item': document.querySelector('#item'),
    '.ant-tabs-nav-add': document.querySelector('.ant-tabs-nav-add'),
    '.ant-tabs-card': document.querySelector('.ant-tabs-card'),
    '.ant-modal': document.querySelector('.ant-modal'),
    'input[type=file]': document.querySelector('input[type=file]'),
  };
  Object.entries(checks).forEach(([k, v]) => {
    TCB.warn(`  顶层文档存在 ${k} ? ${!!v}`);
  });
};

TCB.findLinksByText = function findLinksByText(text, exact = true) {
  const all = Array.from(document.querySelectorAll('a'));
  const matched = all.filter((a) => {
    const content = a.textContent.replace(/\s+/g, '').trim();
    return exact ? content === text : content.includes(text);
  });
  TCB.log(`🔗 查找文本为「${text}」的链接：页面共 ${all.length} 个 a，匹配 ${matched.length} 个（${exact ? '精确' : '包含'}）`);
  return matched;
};

/** 收集「上传证书」「查看证书」链接，保持 DOM 顺序 */
TCB.findCertActionLinks = function findCertActionLinks() {
  const labels = ['上传证书', '查看证书'];
  const seen = new Set();
  const matched = [];

  const candidates = Array.from(
    document.querySelectorAll('a, button, span, div[role="button"]')
  );

  candidates.forEach((el) => {
    const text = el.textContent.replace(/\s+/g, '').trim();
    if (!labels.includes(text)) return;
    if (seen.has(el)) return;
    seen.add(el);
    matched.push({
      el,
      text,
      type: text === '上传证书' ? 'upload' : 'view',
    });
  });

  const uploadN = matched.filter((m) => m.type === 'upload').length;
  const viewN = matched.filter((m) => m.type === 'view').length;
  TCB.log(`🔗 证书相关按钮：共 ${matched.length} 个（上传 ${uploadN}，查看 ${viewN}）`);
  return matched;
};

/** 从证书弹窗 iframe 中读取「当前激活 Tab」的证书编号（多品订单每个品一个 Tab） */
TCB.getActiveTabSerialFromFrame = function getActiveTabSerialFromFrame(frame) {
  try {
    if (!frame || !frame.contentDocument) return { found: false, serial: '', tabCount: 0 };
    const doc = frame.contentDocument;
    const tabs = Array.from(
      doc.querySelectorAll('.ant-tabs-tab, .next-tabs-tab, [role="tab"]')
    );
    const tabCount = tabs.length;
    let activeTab = tabs.find((t) =>
      /active|selected/.test((t.className || '') + ' ' + (t.getAttribute('aria-selected') || ''))
    );
    if (!activeTab) activeTab = tabs[0];
    if (!activeTab) return { found: false, serial: '', tabCount };

    const scoped = activeTab.closest('.ant-tabs, .next-tabs') || doc;
    const input = scoped.querySelector(
      '#item_showSerialNo, input[placeholder*="证书编号"], input[placeholder*="编号"], input[aria-label*="编号"]'
    );
    let serial = '';
    if (input) {
      serial = (input.value || input.getAttribute('value') || '').trim();
    }
    if (!serial) {
      const label = scoped.querySelector('[title="证书编号"], label[title="证书编号"]');
      if (label) {
        const row = label.closest('div, tr, .ant-form-item');
        if (row) {
          serial = (row.textContent || '').replace(/\s+/g, '').trim();
        }
      }
    }
    TCB.log(`[iframe] 读取激活 Tab 证书编号: ${serial ? '有 ' + serial : '（空）'}（Tab 数 ${tabCount}）`);
    return { found: !!serial, serial, tabCount };
  } catch (e) {
    TCB.warn('读取 iframe 证书编号失败:', e.message);
    return { found: false, serial: '', tabCount: 0 };
  }
};

TCB.waitForCertActionLinks = async function waitForCertActionLinks(timeout = 15000) {
  TCB.log(`🔍 等待「上传证书/查看证书」按钮出现（超时 ${timeout}ms）`);
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const links = TCB.findCertActionLinks();
    if (links.length) {
      TCB.log(`✅ 找到 ${links.length} 个证书按钮（耗时 ${Date.now() - start}ms）`);
      return links;
    }
    await TCB.sleep(500);
  }
  TCB.warn(`⏭ 等待 ${timeout}ms 后仍未找到证书按钮`);
  return [];
};

TCB.SHOP_WHITELIST = typeof TCB_SHOP_WHITELIST !== 'undefined' ? TCB_SHOP_WHITELIST : [
  '金街黄金珠宝店',
  '周韵福黄金珠宝',
  '周满福黄金珠宝',
  '周满福黄金 3D硬金足金水贝黄金珠宝批发',
  '周满福珠宝',
  '周满福珠宝黄金',
];

TCB.INJECTED_WHITELIST_CACHE = [];
TCB.REMOVED_BUILTIN_CACHE = [];

TCB.loadInjectedWhitelist = function loadInjectedWhitelist(force) {
  if (!force && TCB._injectedWhitelistLoaded) {
    return Promise.resolve(TCB.INJECTED_WHITELIST_CACHE);
  }
  return TCB.loadWhitelistCaches(force).then((snapshot) => snapshot.injected);
};

TCB.loadWhitelistCaches = function loadWhitelistCaches(force) {
  if (!force && TCB._injectedWhitelistLoaded) {
    return Promise.resolve({
      injected: TCB.INJECTED_WHITELIST_CACHE,
      removedBuiltin: TCB.REMOVED_BUILTIN_CACHE,
      activeBuiltin: typeof tcbGetActiveBuiltinWhitelist === 'function'
        ? tcbGetActiveBuiltinWhitelist(TCB.REMOVED_BUILTIN_CACHE)
        : [],
      effective: [],
    });
  }
  return new Promise((resolve) => {
    // 优先从云端后台拉取白名单（后台可在线管理，插件实时生效）
    const finishLocal = (localInjected) => {
      TCB.INJECTED_WHITELIST_CACHE = localInjected || [];
      TCB.REMOVED_BUILTIN_CACHE = [];
      TCB._injectedWhitelistLoaded = true;
      resolve({
        injected: TCB.INJECTED_WHITELIST_CACHE,
        removedBuiltin: [],
        activeBuiltin: typeof tcbGetActiveBuiltinWhitelist === 'function'
          ? tcbGetActiveBuiltinWhitelist([])
          : [],
        effective: TCB.INJECTED_WHITELIST_CACHE,
        source: 'local',
      });
    };
    const CLOUD_WL_API = 'https://gitbolg-d7gmnsrw46e011706-1256429518.ap-shanghai.app.tcloudbase.com/tcb-admin/public-whitelist';
    fetch(CLOUD_WL_API, { method: 'GET' })
      .then((resp) => resp.json().catch(() => ({})))
      .then((data) => {
        if (data && data.ok && Array.isArray(data.list) && data.list.length) {
          TCB.INJECTED_WHITELIST_CACHE = data.list;
          TCB.REMOVED_BUILTIN_CACHE = [];
          TCB._injectedWhitelistLoaded = true;
          TCB.log(`☁️ 白名单已从后台获取（${data.list.length} 个店铺）`);
          resolve({
            injected: data.list,
            removedBuiltin: [],
            activeBuiltin: data.list,
            effective: data.list,
            source: 'cloud',
          });
          return;
        }
        // 云端返回空/失败 → 回退本地 storage
        TCB.log('⚠️ 后台白名单为空或失败，回退本地白名单');
        chrome.storage.local.get(['tcbInjectedWhitelist'], (storageData) => {
          const localInjected = Array.isArray(storageData.tcbInjectedWhitelist)
            ? storageData.tcbInjectedWhitelist
            : [];
          finishLocal(localInjected);
        });
      })
      .catch(() => {
        chrome.storage.local.get(['tcbInjectedWhitelist'], (storageData) => {
          const localInjected = Array.isArray(storageData.tcbInjectedWhitelist)
            ? storageData.tcbInjectedWhitelist
            : [];
          finishLocal(localInjected);
        });
      });
  });
};

TCB.normalizeShopName = function normalizeShopName(name) {
  return (name || '').replace(/\s+/g, '').trim();
};

TCB.isShopNameAllowed = function isShopNameAllowed(name) {
  if (typeof tcbIsShopNameAllowed === 'function') {
    return tcbIsShopNameAllowed(name, TCB.INJECTED_WHITELIST_CACHE, TCB.REMOVED_BUILTIN_CACHE);
  }
  const normalized = TCB.normalizeShopName(name);
  if (!normalized) return false;
  if (TCB.REMOVED_BUILTIN_CACHE.some((item) => TCB.normalizeShopName(item) === normalized)) {
    return false;
  }
  const lists = [TCB.SHOP_WHITELIST, TCB.INJECTED_WHITELIST_CACHE];
  return lists.some((list) =>
    list.some((item) => TCB.normalizeShopName(item) === normalized)
  );
};

TCB.refreshInjectedWhitelist = function refreshInjectedWhitelist() {
  TCB._injectedWhitelistLoaded = false;
  return TCB.loadWhitelistCaches(true);
};

TCB.SHOP_NAME_SELECTORS = [
  '#icestark-container > div > div > div.user-area-pop-up-panel > div > div > div',
  '.user-area-pop-up-panel > div > div > div',
  '.user-area-pop-up-panel div div div',
  '[class*="shopName"]',
  '[class*="shop-name"]',
  '[class*="ShopName"]',
];

TCB.tryOpenUserAreaPanel = function tryOpenUserAreaPanel() {
  const triggers = [
    '.user-area-pop-up-panel',
    '.user-area',
    '[class*="user-area"]',
    '#icestark-container [class*="userArea"]',
    '#icestark-container [class*="user-area"]',
  ];
  for (const sel of triggers) {
    const el = document.querySelector(sel);
    if (el) {
      TCB.clickElement(el, `尝试展开用户面板 (${sel})`);
      return true;
    }
  }
  return false;
};

TCB.getShopName = function getShopName() {
  for (const sel of TCB.SHOP_NAME_SELECTORS) {
    const el = document.querySelector(sel);
    const text = (el?.innerText || el?.textContent || '').trim();
    if (text) return text;
  }
  return null;
};

TCB.ensureShopAllowed = async function ensureShopAllowed() {
  let shopName = TCB.getShopName();

  if (!shopName) {
    TCB.log('首次未读到店铺名，尝试展开用户面板…');
    TCB.tryOpenUserAreaPanel();
    await TCB.sleep(800, '等待用户面板展开');
    shopName = TCB.getShopName();
  }

  if (!shopName) {
    const start = Date.now();
    while (Date.now() - start < 5000) {
      await TCB.sleep(500);
      shopName = TCB.getShopName();
      if (shopName) break;
    }
  }

  if (!shopName) {
    shopName = await TCB.getCachedShopName();
    if (shopName) TCB.log(`使用已缓存的店铺名: ${shopName}`);
  }

  await TCB.loadWhitelistCaches();

  const allowed = TCB.isShopNameAllowed(shopName);
  TCB.log(`店铺鉴权：${shopName || '(未识别)'} → ${allowed ? '✅ 通过' : '❌ 拒绝'}`);
  if (allowed && shopName) {
    TCB.cacheAuthorizedShopName(shopName);
  }
  return { allowed, shopName };
};

TCB.AUTHORIZED_SHOP_CACHE_KEY = 'tcbAuthorizedShopName';

TCB.getCachedShopName = function getCachedShopName() {
  return new Promise((resolve) => {
    chrome.storage.local.get(TCB.AUTHORIZED_SHOP_CACHE_KEY, (data) => {
      resolve(data[TCB.AUTHORIZED_SHOP_CACHE_KEY] || null);
    });
  });
};

TCB.cacheAuthorizedShopName = function cacheAuthorizedShopName(name) {
  if (!name) return;
  chrome.storage.local.set({ [TCB.AUTHORIZED_SHOP_CACHE_KEY]: name });
};

TCB.clickElement = function clickElement(el, label) {
  if (!el) {
    TCB.error(`点击失败，元素不存在${label ? '（' + label + '）' : ''}`);
    throw new Error('元素不存在');
  }
  const desc = label || el.textContent?.trim()?.slice(0, 20) || el.tagName;
  TCB.log(`👆 点击元素: ${desc}`);
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
  el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
  el.click();
};

TCB.SHIP_RECORD_KEY = 'tcbCompletedShipOrders';

TCB.shipUrlKey = function shipUrlKey(url) {
  try {
    const u = new URL(url);
    const orderId =
      u.searchParams.get('orderId') ||
      u.searchParams.get('bizOrderId') ||
      u.searchParams.get('tradeId') ||
      u.searchParams.get('tid');
    if (orderId) return `order:${orderId}`;
    u.hash = '';
    ['spm', 'utparam', 'scm', 'from'].forEach((p) => u.searchParams.delete(p));
    return `url:${u.origin}${u.pathname}${u.search}`;
  } catch {
    return `url:${url}`;
  }
};

TCB.getCompletedShipRecords = function getCompletedShipRecords() {
  return new Promise((resolve) => {
    chrome.storage.local.get(TCB.SHIP_RECORD_KEY, (data) => {
      resolve(data[TCB.SHIP_RECORD_KEY] || {});
    });
  });
};

TCB.filterPendingShipUrls = async function filterPendingShipUrls(urls) {
  const records = await TCB.getCompletedShipRecords();
  const pending = [];
  const skipped = [];
  urls.forEach((url) => {
    const key = TCB.shipUrlKey(url);
    if (records[key]) {
      skipped.push({ url, key, record: records[key] });
    } else {
      pending.push(url);
    }
  });
  return { pending, skipped };
};

TCB.CERT_DELAY_MS_KEY = 'tcbCertUploadDelayMs';
TCB.DEFAULT_CERT_DELAY_MS = 60 * 60 * 1000;

TCB.getCertUploadDelayMs = function getCertUploadDelayMs() {
  return new Promise((resolve) => {
    chrome.storage.local.get(TCB.CERT_DELAY_MS_KEY, (data) => {
      const v = data[TCB.CERT_DELAY_MS_KEY];
      resolve(typeof v === 'number' && v >= 0 ? v : TCB.DEFAULT_CERT_DELAY_MS);
    });
  });
};

TCB.setCertUploadDelayMs = function setCertUploadDelayMs(ms) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [TCB.CERT_DELAY_MS_KEY]: ms }, resolve);
  });
};

TCB.parseOrderCreateTime = function parseOrderCreateTime(text) {
  const m = String(text || '').match(
    /创建时间[：:]\s*(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})/
  );
  if (!m) return null;
  const ts = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime();
  return Number.isFinite(ts) ? ts : null;
};

TCB.splitOrdersByCreateDelay = function splitOrdersByCreateDelay(orders, delayMs, now = Date.now()) {
  const ready = [];
  const queued = [];
  orders.forEach((order) => {
    if (order.createdAt == null) {
      ready.push(order);
      return;
    }
    const age = now - order.createdAt;
    if (age >= delayMs) {
      ready.push(order);
    } else {
      queued.push({
        ...order,
        waitMs: delayMs - age,
        readyAt: order.createdAt + delayMs,
      });
    }
  });
  return { ready, queued };
};

TCB.filterPendingShipOrders = async function filterPendingShipOrders(orders) {
  const records = await TCB.getCompletedShipRecords();
  const pending = [];
  const skipped = [];
  orders.forEach((order) => {
    const key = TCB.shipUrlKey(order.url);
    if (records[key]) {
      skipped.push({ ...order, key, record: records[key] });
    } else {
      pending.push(order);
    }
  });
  return { pending, skipped };
};

TCB.formatDelayWait = function formatDelayWait(ms) {
  if (ms <= 0) return '即将处理';
  const mins = Math.ceil(ms / 60000);
  if (mins < 60) return `${mins} 分钟`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `${h} 小时 ${m} 分` : `${h} 小时`;
};

TCB.getCompletedShipStats = async function getCompletedShipStats() {
  const records = await TCB.getCompletedShipRecords();
  const list = Object.values(records);
  return {
    orderCount: list.length,
    certUploaded: list.reduce((sum, item) => sum + (item.certUploaded || 0), 0),
    certSkipped: list.reduce((sum, item) => sum + (item.certSkipped || 0), 0),
  };
};

/** 判断是否存在疑似异常记录（可用于清理提示） */
TCB.countAbnormalShipRecords = async function countAbnormalShipRecords() {
  const records = await TCB.getCompletedShipRecords();
  const list = Object.values(records);
  const abnormal = list.filter(
    (rec) =>
      (rec.certFailed && rec.certFailed > 0) ||
      (rec.noCertButtons && !rec.certUploaded) ||
      rec.skipReason === 'batch-consign' ||
      rec.skipReason === 'heartbeat-timeout'
  );
  return abnormal.length;
};

window.TCB = TCB;
TCB.loadWhitelistCaches().catch(() => {});

// 桥接：content script 内 window.TCBLogger 已由 logger.js 注入
if (window.TCBLogger && window.TCB) {
  window.TCB._logger = window.TCBLogger;
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.action === 'WHITELIST_UPDATED') {
    TCB.refreshInjectedWhitelist();
  }
});

console.log('[证书上传] helpers.js 已加载');
})();
