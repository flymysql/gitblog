(function () {
const TCB = window.TCB || {};

TCB.CERT_CONFIG = {
  prefixHead: 'KLM',
  prefixTail: 'M1_',
  randomDigits: 2,
  startNumber: 1,
  numberLength: 5,
  canvasWidth: 1280,
  canvasHeight: 360,
  fileType: 'image/png',
  inputSelector:
    '#item > div > div > div:nth-child(1) > div > span > div > div > span > input[type=file]',
  serialNoSelector: '#item_showSerialNo',
  institutionInputSelector: '#item_institutionName',
  institutionName: '深圳市中首珠宝检测有限公司',
};

/**
 * 判断一个编号是否符合本插件生成的证书编号格式。
 * 格式：prefixHead + randomDigits位随机数字 + prefixTail + numberLength位数字
 * 例：KLM12M1_00042
 */
TCB.isPlausibleSerial = function isPlausibleSerial(text) {
  const cfg = TCB.CERT_CONFIG;
  const s = String(text || '').replace(/\s+/g, '').trim();
  if (!s) return false;
  try {
    const re = new RegExp(
      '^' +
        TCB.escapeRegExp(cfg.prefixHead) +
        '\\d{' + cfg.randomDigits + '}' +
        TCB.escapeRegExp(cfg.prefixTail) +
        '\\d{' + cfg.numberLength + '}$'
    );
    return re.test(s);
  } catch (e) {
    return false;
  }
};

TCB.escapeRegExp = function escapeRegExp(s) {
  return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

TCB.padNumber = function padNumber(n, len) {
  return String(n).padStart(len, '0');
};

TCB.randomDigits = function randomDigits(len) {
  let s = '';
  for (let i = 0; i < len; i++) {
    s += Math.floor(Math.random() * 10);
  }
  return s;
};

TCB.drawCertImage = function drawCertImage(text) {
  const cfg = TCB.CERT_CONFIG;
  const canvas = document.createElement('canvas');
  canvas.width = cfg.canvasWidth;
  canvas.height = cfg.canvasHeight;

  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const borderWidth = Math.max(2, Math.round(canvas.height / 90));
  ctx.strokeStyle = '#dddddd';
  ctx.lineWidth = borderWidth;
  ctx.beginPath();
  ctx.moveTo(0, borderWidth / 2);
  ctx.lineTo(canvas.width, borderWidth / 2);
  ctx.moveTo(0, canvas.height - borderWidth / 2);
  ctx.lineTo(canvas.width, canvas.height - borderWidth / 2);
  ctx.stroke();

  // 字号按画布高度自适应，并根据文字宽度自动收缩以保证完整显示
  const padding = Math.round(canvas.width * 0.04);
  let fontSize = Math.round(canvas.height * 0.42);
  ctx.fillStyle = '#000000';
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'left';

  const maxTextWidth = canvas.width - padding * 2;
  do {
    ctx.font = `bold ${fontSize}px "Times New Roman", Times, serif`;
    if (ctx.measureText(text).width <= maxTextWidth) break;
    fontSize -= 4;
  } while (fontSize > 12);

  ctx.fillText(text, padding, canvas.height / 2);

  return canvas;
};

TCB.canvasToBlob = function canvasToBlob(canvas, type) {
  return new Promise((resolve) => canvas.toBlob(resolve, type));
};

TCB.injectFile = function injectFile(input, file) {
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
};

TCB.getNextSerial = async function getNextSerial() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['certSerial'], (result) => {
      const current = result.certSerial ?? TCB.CERT_CONFIG.startNumber;
      chrome.storage.local.set({ certSerial: current + 1 }, () => resolve(current));
    });
  });
};

TCB.generateCertFile = async function generateCertFile() {
  const cfg = TCB.CERT_CONFIG;
  const serial = await TCB.getNextSerial();
  const number = TCB.padNumber(serial, cfg.numberLength);
  const rand = TCB.randomDigits(cfg.randomDigits);
  const text = `${cfg.prefixHead}${rand}${cfg.prefixTail}${number}`;

  const canvas = TCB.drawCertImage(text);
  const blob = await TCB.canvasToBlob(canvas, cfg.fileType);
  const ext = cfg.fileType.split('/')[1] || 'png';

  const file = new File([blob], `${text}.${ext}`, {
    type: cfg.fileType,
    lastModified: Date.now(),
  });

  return { file, text };
};

TCB.fillSerialNumber = async function fillSerialNumber(text) {
  const cfg = TCB.CERT_CONFIG;
  TCB.log(`✏️ 准备填入证书编号: ${text}`);
  const input = await TCB.waitForSelector(cfg.serialNoSelector, 8000);

  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  if (setter) {
    setter.call(input, text);
  } else {
    input.value = text;
  }
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  TCB.log(`✅ 已填入证书编号输入框: ${text}`);
  return text;
};

TCB.getInstitutionSelectState = function getInstitutionSelectState() {
  const cfg = TCB.CERT_CONFIG;
  const input = document.querySelector(cfg.institutionInputSelector);
  if (!input) return { exists: false, value: '', input: null, select: null };

  const select = input.closest('.ant-select');
  if (!select) return { exists: false, value: '', input, select: null };

  const item = select.querySelector('.ant-select-selection-item');
  const value =
    item?.getAttribute('title')?.trim() ||
    item?.textContent?.replace(/\s+/g, '').trim() ||
    '';

  return { exists: true, value, input, select };
};

TCB.normalizeInstitutionName = function normalizeInstitutionName(name) {
  return (name || '').replace(/\s+/g, '').trim();
};

TCB.getInstitutionOptionLabel = function getInstitutionOptionLabel(option) {
  return (
    option.getAttribute('title')?.trim() ||
    option.textContent?.replace(/\s+/g, ' ').trim() ||
    ''
  );
};

TCB.findInstitutionOption = function findInstitutionOption(options, targetName) {
  const normalizedTarget = TCB.normalizeInstitutionName(targetName);
  if (!normalizedTarget) return null;

  let partial = null;
  for (const option of options) {
    const label = TCB.getInstitutionOptionLabel(option);
    const normalized = TCB.normalizeInstitutionName(label);
    if (normalized === normalizedTarget) return option;
    if (
      !partial &&
      (normalized.includes(normalizedTarget) || normalizedTarget.includes(normalized))
    ) {
      partial = option;
    }
  }
  return partial;
};

TCB.collectInstitutionOptions = async function collectInstitutionOptions(input, timeout = 6000) {
  const listId = input.getAttribute('aria-owns') || 'item_institutionName_list';
  let options = [];
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const list = document.getElementById(listId);
    if (list) {
      options = Array.from(
        list.querySelectorAll('.ant-select-item-option:not(.ant-select-item-option-disabled)')
      );
    }
    if (!options.length) {
      options = Array.from(
        document.querySelectorAll(
          '.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option:not(.ant-select-item-option-disabled)'
        )
      );
    }
    if (options.length) break;
    await TCB.sleep(200);
  }
  return options;
};

// 向搜索型 ant-select 的输入框注入关键字，触发过滤/远程搜索
TCB.typeIntoInstitutionInput = function typeIntoInstitutionInput(input, value) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
  if (setter) {
    setter.call(input, value);
  } else {
    input.value = value;
  }
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a' }));
  input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
};

TCB.ensureInstitutionSelected = async function ensureInstitutionSelected() {
  const cfg = TCB.CERT_CONFIG;
  const targetName = cfg.institutionName || '';
  const state = TCB.getInstitutionSelectState();
  if (!state.exists) {
    TCB.log('未找到检测机构下拉框，跳过');
    return null;
  }

  const currentNormalized = TCB.normalizeInstitutionName(state.value);
  const targetNormalized = TCB.normalizeInstitutionName(targetName);
  if (state.value && currentNormalized === targetNormalized) {
    TCB.log(`检测机构已选中: ${state.value}`);
    return state.value;
  }

  if (state.value) {
    TCB.log(`检测机构当前为「${state.value}」，将切换为「${targetName}」`);
  } else {
    TCB.log(`检测机构未选中，自动选择「${targetName}」`);
  }

  const trigger = state.select.querySelector('.ant-select-selector');
  if (trigger) {
    TCB.clickElement(trigger, '检测机构下拉框');
  } else {
    TCB.clickElement(state.input, '检测机构输入框');
  }

  await TCB.sleep(400, '等待检测机构下拉框聚焦');

  // 搜索型下拉：先注入关键字触发过滤/远程加载，再用过滤后的列表查找
  state.input.focus?.();
  TCB.typeIntoInstitutionInput(state.input, targetName);
  TCB.log(`⌨️ 已向检测机构搜索框注入关键字: ${targetName}`);
  await TCB.sleep(800, '等待检测机构搜索结果加载');

  let options = await TCB.collectInstitutionOptions(state.input, 6000);

  // 关键字过滤后仍为空，退回全名前若干字再试一次（应对全名匹配不到的情况）
  if (!options.length || !TCB.findInstitutionOption(options, targetName)) {
    const shortKey = TCB.normalizeInstitutionName(targetName).slice(0, 4);
    if (shortKey && shortKey !== TCB.normalizeInstitutionName(targetName)) {
      TCB.log(`检测机构全名未命中，改用关键字「${shortKey}」重试`);
      TCB.typeIntoInstitutionInput(state.input, shortKey);
      await TCB.sleep(800, '等待检测机构关键字搜索结果');
      options = await TCB.collectInstitutionOptions(state.input, 6000);
    }
  }

  if (!options.length) {
    TCB.warn('未找到检测机构可选项');
    return null;
  }

  const match = TCB.findInstitutionOption(options, targetName);
  if (!match) {
    const available = options.map((option) => TCB.getInstitutionOptionLabel(option)).filter(Boolean);
    TCB.warn(`未找到检测机构「${targetName}」，当前可选项:`, available);
    return null;
  }

  const label = TCB.getInstitutionOptionLabel(match) || targetName;
  TCB.clickElement(match, `检测机构: ${label}`);
  await TCB.sleep(400, '选择检测机构后等待');

  const after = TCB.getInstitutionSelectState();
  if (after.value && TCB.normalizeInstitutionName(after.value) === targetNormalized) {
    TCB.log(`✅ 已选择检测机构: ${after.value}`);
  } else {
    TCB.log(`✅ 已点击检测机构选项: ${after.value || label}`);
  }
  return after.value || label;
};

TCB.uploadCertificate = async function uploadCertificate() {
  const cfg = TCB.CERT_CONFIG;
  TCB.log('📤 准备上传证书，定位 file input...');
  const input = await TCB.waitForSelector(cfg.inputSelector, 10000);
  const { file, text } = await TCB.generateCertFile();
  TCB.log(`🖼️ 已生成证书图片: ${file.name}（${file.type}, ${file.size} 字节）`);
  TCB.injectFile(input, file);
  TCB.log(`✅ 已注入文件并触发 change 事件，input.files 数量: ${input.files.length}`);
  return text;
};

window.TCB = TCB;
console.log('[证书上传] cert-generator.js 已加载，CERT_CONFIG:', !!TCB.CERT_CONFIG);
})();
