(function (global) {
  const SIGNATURE_CONTEXT = new TextEncoder().encode('CRX3 SignedData\x00');

  function encodeVarint(value) {
    const out = [];
    let n = value >>> 0;
    while (n >= 0x80) {
      out.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    out.push(n);
    return new Uint8Array(out);
  }

  function concatChunks(chunks) {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    chunks.forEach((chunk) => {
      out.set(chunk, offset);
      offset += chunk.length;
    });
    return out;
  }

  function encodeLengthDelimited(fieldNumber, bytes) {
    const tag = encodeVarint((fieldNumber << 3) | 2);
    const len = encodeVarint(bytes.length);
    return concatChunks([tag, len, bytes]);
  }

  function pemToArrayBuffer(pem) {
    const b64 = pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  async function importPrivateKey(pemText) {
    return crypto.subtle.importKey(
      'pkcs8',
      pemToArrayBuffer(pemText),
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      true,
      ['sign']
    );
  }

  async function getPublicSpkiFromPrivateKey(privateKey) {
    const jwk = await crypto.subtle.exportKey('jwk', privateKey);
    const publicJwk = {
      kty: jwk.kty,
      n: jwk.n,
      e: jwk.e,
      alg: 'RS256',
      ext: true,
    };
    const publicKey = await crypto.subtle.importKey(
      'jwk',
      publicJwk,
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      true,
      ['verify']
    );
    return new Uint8Array(await crypto.subtle.exportKey('spki', publicKey));
  }

  async function calculateCrxId(publicSpki) {
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', publicSpki));
    return hash.slice(0, 16);
  }

  async function packCrx3(zipBytes, pemText) {
    const privateKey = await importPrivateKey(pemText);
    const publicSpki = await getPublicSpkiFromPrivateKey(privateKey);
    const crxId = await calculateCrxId(publicSpki);

    // signedData 只含 crxId(16字节),不含 proof
    const signedData = encodeLengthDelimited(1, crxId);

    // 占位生成 proof(用空签名占位,确保 header 长度与最终一致)
    const SIG_LEN = 256;
    const placeholderProof = concatChunks([
      encodeLengthDelimited(1, publicSpki),
      encodeLengthDelimited(2, new Uint8Array(SIG_LEN)),
    ]);

    // CrxFileHeader 顶层结构
    // 注意: outer header 长度 = signed_header_size(参考 chromium 源码)
    // 实际 chromium 验证时,签名载荷是:
    //   [kSignatureContext][header_size_octets][signed_header_data][archive]
    // 其中 header_size_octets = 整个 outer header 的大小(4 字节 LE)
    const placeholderHeader = concatChunks([
      encodeLengthDelimited(2, placeholderProof),         // field 2 = proof
      encodeLengthDelimited(10000, signedData),          // field 10000 = signed_header_data
    ]);

    // 签名载荷
    const headerSizeLE = new Uint8Array(4);
    new DataView(headerSizeLE.buffer).setUint32(0, placeholderHeader.length, true);
    const signPayload = concatChunks([SIGNATURE_CONTEXT, headerSizeLE, signedData, zipBytes]);
    const signature = new Uint8Array(
      await crypto.subtle.sign('RSASSA-PKCS1-v1_5', privateKey, signPayload)
    );
    if (signature.length !== SIG_LEN) {
      throw new Error(`签名长度异常: ${signature.length} (期望 ${SIG_LEN})`);
    }

    // 真实 proof(签名已计算)
    const proof = concatChunks([
      encodeLengthDelimited(1, publicSpki),
      encodeLengthDelimited(2, signature),
    ]);

    // 真实 header
    const header = concatChunks([
      encodeLengthDelimited(2, proof),
      encodeLengthDelimited(10000, signedData),
    ]);
    if (header.length !== placeholderHeader.length) {
      throw new Error(`header 长度变化: 签名用 ${placeholderHeader.length}, 实际 ${header.length}`);
    }

    const magic = new TextEncoder().encode('Cr24');
    const version = new Uint8Array(4);
    new DataView(version.buffer).setUint32(0, 3, true);
    const headerSize = new Uint8Array(4);
    new DataView(headerSize.buffer).setUint32(0, header.length, true);

    return concatChunks([magic, version, headerSize, header, zipBytes]);
  }

  global.TCBCrxPack = { packCrx3 };
})(typeof self !== 'undefined' ? self : this);
