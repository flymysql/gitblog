(function (global) {
  const SIGNATURE_CONTEXT = new TextEncoder().encode('CRX3 SignedData\x00');

  function encodeVarint(value) {
    const out = [];
    let n = value >>> 0;
    while (n >= 0x80) {
      out.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    out.push(n);
    return new Uint8Array(out);
  }

  function concatChunks(chunks) {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    chunks.forEach((chunk) => {
      out.set(chunk, offset);
      offset += chunk.length;
    });
    return out;
  }

  function encodeLengthDelimited(fieldNumber, bytes) {
    const tag = encodeVarint((fieldNumber << 3) | 2);
    const len = encodeVarint(bytes.length);
    return concatChunks([tag, len, bytes]);
  }

  function pemToArrayBuffer(pem) {
    const b64 = pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  async function importPrivateKey(pemText) {
    return crypto.subtle.importKey(
      'pkcs8',
      pemToArrayBuffer(pemText),
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      true,
      ['sign']
    );
  }

  async function getPublicSpkiFromPrivateKey(privateKey) {
    const jwk = await crypto.subtle.exportKey('jwk', privateKey);
    const publicJwk = {
      kty: jwk.kty,
      n: jwk.n,
      e: jwk.e,
      alg: 'RS256',
      ext: true,
    };
    const publicKey = await crypto.subtle.importKey(
      'jwk',
      publicJwk,
      { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
      true,
      ['verify']
    );
    return new Uint8Array(await crypto.subtle.exportKey('spki', publicKey));
  }

  async function calculateCrxId(publicSpki) {
    const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', publicSpki));
    return hash.slice(0, 16);
  }

  async function packCrx3(zipBytes, pemText) {
    const privateKey = await importPrivateKey(pemText);
    const publicSpki = await getPublicSpkiFromPrivateKey(privateKey);
    const crxId = await calculateCrxId(publicSpki);
    const signedData = encodeLengthDelimited(1, crxId);

    const signedHeaderSize = new Uint8Array(4);
    new DataView(signedHeaderSize.buffer).setUint32(0, signedData.length, true);

    const signPayload = concatChunks([SIGNATURE_CONTEXT, signedHeaderSize, signedData, zipBytes]);
    const signature = new Uint8Array(
      await crypto.subtle.sign('RSASSA-PKCS1-v1_5', privateKey, signPayload)
    );

    const proof = concatChunks([
      encodeLengthDelimited(1, publicSpki),
      encodeLengthDelimited(2, signature),
    ]);

    const header = concatChunks([
      encodeLengthDelimited(2, proof),
      encodeLengthDelimited(10000, signedData),
    ]);

    const magic = new TextEncoder().encode('Cr24');
    const version = new Uint8Array(4);
    new DataView(version.buffer).setUint32(0, 3, true);
    const headerSize = new Uint8Array(4);
    new DataView(headerSize.buffer).setUint32(0, header.length, true);

    return concatChunks([magic, version, headerSize, header, zipBytes]);
  }

  global.TCBCrxPack = { packCrx3 };
})(typeof self !== 'undefined' ? self : this);
