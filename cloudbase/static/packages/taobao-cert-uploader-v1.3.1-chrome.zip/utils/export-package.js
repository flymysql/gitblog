const TCB_EXPORT_FILE_PATHS = [
  'background.js',
  'manifest.json',
  'popup.html',
  'popup.js',
  'README.md',
  'content/',
  'content/cert-dialog.js',
  'content/ship-page.js',
  'content/sold-page.js',
  'icons/',
  'styles/',
  'styles/modal.css',
  'styles/popup.css',
  'utils/',
  'utils/cert-generator.js',
  'utils/crx-pack.js',
  'utils/export-package.js',
  'utils/helpers.js',
  'utils/log-export.js',
  'utils/logger.js',
  'utils/shop-whitelist.js',
  'utils/updater.js',
  'utils/zip-store.js',
];

function bumpManifestVersion(manifestText) {
  try {
    const manifest = JSON.parse(manifestText);
    const parts = String(manifest.version || '1.0.0').split('.').map((n) => parseInt(n, 10) || 0);
    while (parts.length < 3) parts.push(0);
    parts[2] += 1;
    manifest.version = parts.join('.');
    return JSON.stringify(manifest, null, 2) + '\n';
  } catch (e) {
    return manifestText;
  }
}

async function fetchExtensionAsset(path) {
  if (path.endsWith('/')) {
    return null;
  }
  const url = chrome.runtime.getURL(path);
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`读取扩展文件失败: ${path}`);
  }
  if (
    path.endsWith('.css') ||
    path.endsWith('.js') ||
    path.endsWith('.html') ||
    path.endsWith('.json') ||
    path.endsWith('.md')
  ) {
    return await response.text();
  }
  return new Uint8Array(await response.arrayBuffer());
}

async function buildShopWhitelistForExport(effectiveList) {
  const passwordHash = await new Promise((resolve) => tcbLoadAdminPasswordHash(resolve));
  let source = String(await fetchExtensionAsset('utils/shop-whitelist.js'));
  const lines = effectiveList
    .map((item) => "  '" + String(item).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "',")
    .join('\n');
  source = source.replace(/var TCB_SHOP_WHITELIST = \[[\s\S]*?\];/, `var TCB_SHOP_WHITELIST = [\n${lines}\n];`);
  source = source.replace(
    /var TCB_DEFAULT_ADMIN_PASSWORD_HASH = '[^']*';/,
    `var TCB_DEFAULT_ADMIN_PASSWORD_HASH = '${passwordHash}';`
  );
  return source;
}

async function buildExportZip(snapshot) {
  const effectiveList = snapshot.effective || [];
  const files = [];

  for (const path of TCB_EXPORT_FILE_PATHS) {
    if (path.endsWith('/')) {
      files.push({ name: path, data: new Uint8Array(0) });
      continue;
    }

    let content = await fetchExtensionAsset(path);
    if (path === 'utils/shop-whitelist.js') {
      content = await buildShopWhitelistForExport(effectiveList);
    } else if (path === 'manifest.json' && typeof content === 'string') {
      content = bumpManifestVersion(content);
    }

    const data =
      content instanceof Uint8Array ? content : TCBZipStore.toBytes(String(content));
    files.push({ name: path.replace(/\\/g, '/'), data });
  }

  return TCBZipStore.createZipDeflate(files);
}

function bytesToBase64(bytes) {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < view.length; i += chunkSize) {
    const chunk = view.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

async function exportCrxPackageBytes() {
  const snapshot = await new Promise((resolve) => {
    tcbGetWhitelistSnapshot(resolve);
  });
  const zipBytes = await buildExportZip(snapshot);
  const pemResponse = await fetch(chrome.runtime.getURL('utils/export-key.dat'));
  if (!pemResponse.ok) {
    throw new Error('未找到打包私钥 utils/export-key.dat');
  }
  const pemText = await pemResponse.text();
  const crxBytes = await TCBCrxPack.packCrx3(zipBytes, pemText);
  const stamp = new Date();
  const suffix = `${stamp.getFullYear()}${String(stamp.getMonth() + 1).padStart(2, '0')}${String(stamp.getDate()).padStart(2, '0')}-${String(stamp.getHours()).padStart(2, '0')}${String(stamp.getMinutes()).padStart(2, '0')}`;
  return {
    crxBase64: bytesToBase64(crxBytes),
    filename: `淘宝证书自动上传2.0-${suffix}.crx`,
  };
}
