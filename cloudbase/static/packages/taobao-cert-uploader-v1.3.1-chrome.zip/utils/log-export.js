/*
 * 日志包导出（background 专用）
 *
 * - 把内存 + storage 中的日志、运行现场快照、当前批次状态、白名单配置、
 *   完成记录统计、storage 关键键值打包成一个 zip
 * - 打包在 background 完成，zip 以 base64 字符串返回给发起方（弹窗/页面）下载，
 *   避免 MV3 service worker 中 blob URL + chrome.downloads 静默失败导致的卡死
 * - 提供「异常订单清理」：根据特征删除误写入完成记录（certFailed>0 或有
 *   失败标记的订单），让它们重新出现在待扫描列表
 */
(function (global) {
  'use strict';

  const LOG_MANIFEST_NAME = 'log-manifest.json';

  function utcStamp(d) {
    const pad = (n, l) => String(n).padStart(l || 2, '0');
    return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}`;
  }

  function safeStringify(obj) {
    try {
      return JSON.stringify(obj, (k, v) => {
        if (typeof v === 'function') return undefined;
        if (v instanceof Error) return { message: v.message, stack: v.stack };
        return v;
      }, 2);
    } catch (e) {
      return String(obj);
    }
  }

  function logStage(stage, detail) {
    try {
      if (global.TCBLogger && typeof global.TCBLogger.log === 'function') {
        global.TCBLogger.log('info', `log-export.${stage}`, detail);
      }
    } catch (e) { /* ignore */ }
  }

  function buildLogManifest(meta, entryCount) {
    const logger = global.TCBLogger;
    const manifest = {
      exportedAt: new Date().toISOString(),
      exportedAtHuman: new Date().toLocaleString('zh-CN'),
      entryCount,
      retentionDays: (logger && typeof logger.getRetentionDays === 'function') ? logger.getRetentionDays() : 7,
      extName: (logger && logger.ctx && logger.ctx.extName) || '',
      extVersion: (logger && logger.ctx && logger.ctx.extVersion) || '',
      env: (logger && logger.ctx && logger.ctx.env) || '',
      url: (logger && logger.ctx && logger.ctx.url) || '',
      tabId: (logger && logger.ctx && logger.ctx.tabId) || 0,
      frame: (logger && logger.ctx && logger.ctx.frame) || '',
      userAgent: (logger && logger.ctx && logger.ctx.userAgent) || '',
      meta: meta || {},
    };
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
      try {
        manifest.manifest = chrome.runtime.getManifest();
      } catch (e) { /* ignore */ }
    }
    return manifest;
  }

  // 收集 storage 里与插件相关的关键键值（去敏感：密码哈希只留前缀）
  // 注意：tcbLogEntries 已单独导出，这里跳过避免重复
  function collectStorageSnapshot() {
    const keys = [
      'tcbCompletedShipOrders',
      'tcbBatchState',
      'tcbInjectedWhitelist',
      'tcbRemovedBuiltinWhitelist',
      'tcbAdminPasswordHash',
      'tcbCertUploadDelayMs',
      'tcbAuthorizedShopName',
      'tcbLogMeta',
      'tcbLogRetentionDays',
      'certSerial',
    ];
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve({});
        return;
      }
      chrome.storage.local.get(keys, (data) => {
        const out = {};
        keys.forEach((k) => {
          const v = data[k];
          if (v === undefined) return;
          if (k === 'tcbAdminPasswordHash' && typeof v === 'string') {
            out[k] = v.slice(0, 8) + '…(隐藏)';
            return;
          }
          out[k] = v;
        });
        resolve(out);
      });
    });
  }

  function bytesToBase64(bytes) {
    const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let binary = '';
    const CHUNK = 0x8000;
    for (let i = 0; i < view.length; i += CHUNK) {
      binary += String.fromCharCode.apply(null, view.subarray(i, i + CHUNK));
    }
    return btoa(binary);
  }

  /**
   * 打包导出日志包。
   * @param {object} [opts] - { getBatchState: () => object|undefined }
   * @returns Promise<{ok, filename, entryCount, zipBase64, sizeBytes} | {ok:false, error}>
   * 注意：不在 background 内直接触发下载（blob URL 在 MV3 SW 中不可靠），
   * 由调用方拿到 zipBase64 后在弹窗/页面内下载。
   *
   * 包内文件：
   *  - log.txt            人类可读的逐条操作记录（正常/异常分支都有，推荐优先查看）
   *  - log-entries.json   全部日志条目（结构化，供程序分析）
   *  - error-scenes.json  异常现场记录（DOM 环境、上下文、动作记录、storage 快照）
   *  - log-context.json   当前运行现场快照
   *  - storage-snapshot.json  storage 关键键值（脱敏）
   *  - batch-state.json   当前批次状态（如进行中）
   *  - log-manifest.json  导出元信息
   */
  async function exportLogPackage(opts) {
    const logger = global.TCBLogger;
    if (!logger) {
      return { ok: false, error: '日志系统未初始化' };
    }
    if (!global.TCBZipStore) {
      return { ok: false, error: 'zip 模块未加载' };
    }

    try {
      logStage('start', '开始打包日志');
      const [entries, meta, storageSnapshot, errorScenes] = await Promise.all([
        logger.collectAll(5000),
        logger.collectMeta(),
        collectStorageSnapshot(),
        logger.collectErrorScenes ? logger.collectErrorScenes(20) : Promise.resolve([]),
      ]);
      logStage('collect', `日志 ${entries.length} 条，异常现场 ${errorScenes.length} 个，storage 键 ${Object.keys(storageSnapshot).length} 个`);

      // 批次状态：优先用调用方传入的（background 直接读 batchState，避免 self-sendMessage 卡死）
      let batchState = null;
      if (opts && typeof opts.getBatchState === 'function') {
        try {
          batchState = opts.getBatchState() || null;
        } catch (e) {
          batchState = null;
        }
      }
      const snapshot = logger.buildSnapshot();

      // —— 人类可读的操作日志文本 ——
      const logText = logger.entriesToText ? logger.entriesToText(entries) : entries.map((e) => JSON.stringify(e)).join('\n');
      // 附加异常现场摘要
      const sceneSummary = errorScenes.length
        ? '\n\n────── 异常现场记录 ──────\n' +
          errorScenes.map((s) => {
            const act = (s.recentActions || []).map((a) => logger.entryToText ? logger.entryToText(a) : JSON.stringify(a)).join('\n      ');
            return (
              `[${s.persistedAt || s.capturedAt || ''}] ${s.reason || 'unknown'}\n` +
              `  场景ID: ${s.sceneId || ''}\n` +
              `  页面: ${s.url || ''}  框架: ${s.frame || ''}\n` +
              `  扩展: ${s.extName || ''} v${s.extVersion || ''}\n` +
              (s.dom ? `  DOM: title=${s.dom.title || ''} readyState=${s.dom.readyState || ''} iframes=${(s.dom.iframes || []).length}\n` : '') +
              (s.storage ? `  storage: ${Object.keys(s.storage).join(', ')}\n` : '') +
              (s.extra && Object.keys(s.extra).length ? `  附加上下文: ${JSON.stringify(s.extra)}\n` : '') +
              (act ? `  近期动作:\n      ${act}\n` : '')
            );
          }).join('\n──────\n')
        : '(无异常现场记录)';
      const fullLogText = logText + '\n' + sceneSummary;

      // 数据文件
      const files = [];
      files.push({
        name: 'log-manifest.json',
        data: safeStringify(buildLogManifest(meta, entries.length)),
      });
      files.push({ name: 'log.txt', data: fullLogText });
      files.push({ name: 'log-entries.json', data: safeStringify(entries) });
      files.push({ name: 'error-scenes.json', data: safeStringify(errorScenes) });
      files.push({ name: 'log-context.json', data: safeStringify(snapshot) });
      files.push({ name: 'storage-snapshot.json', data: safeStringify(storageSnapshot) });
      if (batchState) {
        files.push({ name: 'batch-state.json', data: safeStringify(batchState) });
      }

      const zip = await global.TCBZipStore.createZipDeflate(files);
      const suffix = utcStamp(new Date());
      const filename = `tcb-log-${suffix}.zip`;
      const zipBase64 = bytesToBase64(zip);
      logStage('done', `打包完成 ${filename}，zip ${zip.length} 字节，base64 ${zipBase64.length} 字符`);
      return { ok: true, filename, entryCount: entries.length, errorSceneCount: errorScenes.length, zipBase64, sizeBytes: zip.length };
    } catch (err) {
      logStage('error', err.message || String(err));
      return { ok: false, error: (err && err.message) || String(err) };
    }
  }

  // 异常订单清理：
  //  - 删除完成记录中带失败标记 / 无证书按钮但 certUploaded=0 的记录
  //  - 删除 batch-consign 类型的记录
  // 返回 { ok, removedKeys, keptCount }
  function cleanupAbnormalShipRecords() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve({ ok: false, error: 'storage 不可用' });
        return;
      }
      chrome.storage.local.get('tcbCompletedShipOrders', (data) => {
        const records = data['tcbCompletedShipOrders'] || {};
        const keys = Object.keys(records);
        const removed = [];
        const kept = {};

        keys.forEach((key) => {
          const rec = records[key] || {};
          const isAbnormal =
            (rec.certFailed && rec.certFailed > 0) ||
            (rec.noCertButtons && !rec.certUploaded) ||
            rec.skipReason === 'batch-consign' ||
            rec.skipReason === 'heartbeat-timeout';
          if (isAbnormal) {
            removed.push({ key, skipReason: rec.skipReason || '', certFailed: rec.certFailed || 0 });
          } else {
            kept[key] = rec;
          }
        });

        chrome.storage.local.set({ 'tcbCompletedShipOrders': kept }, () => {
          resolve({ ok: true, removed, removedCount: removed.length, keptCount: keys.length - removed.length });
        });
      });
    });
  }

  /**
   * 上传配置（可被弹窗/面板修改后覆盖）
   */
  const UPLOAD_CONFIG = {
    // CloudBase HTTP 访问服务地址（tcb-log-upload 云函数）
    endpoint: 'https://gitbolg-d7gmnsrw46e011706-1256429518.ap-shanghai.app.tcloudbase.com/tcb-upload',
    token: 'tcb-upload-2026',
    enabled: true,
  };
  const UPLOAD_CONFIG_KEY = 'tcbUploadConfig';

  function loadUploadConfig() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve({ ...UPLOAD_CONFIG });
        return;
      }
      chrome.storage.local.get(UPLOAD_CONFIG_KEY, (data) => {
        const saved = data[UPLOAD_CONFIG_KEY] || {};
        resolve({ ...UPLOAD_CONFIG, ...saved });
      });
    });
  }

  function saveUploadConfig(cfg) {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve();
    return new Promise((resolve) => {
      chrome.storage.local.set({ [UPLOAD_CONFIG_KEY]: cfg }, resolve);
    });
  }

  /**
   * 把日志包上传到腾讯云 COS（经 CloudBase 云函数代理，扩展不持有密钥）
   * @param {object} opts - { getBatchState }
   * @returns Promise<{ok, filename, cloudPath?, url?, entryCount?, error?}>
   */
  async function uploadLogPackage(opts) {
    const cfg = await loadUploadConfig();
    if (!cfg.enabled) {
      return { ok: false, error: '上传未启用' };
    }

    // 先打包（复用 exportLogPackage 逻辑）
    const packed = await exportLogPackage(opts);
    if (!packed.ok || !packed.zipBase64) {
      return { ok: false, error: packed.error || '打包失败' };
    }

    // 二进制转 Uint8Array，构造 multipart 上传
    const binary = atob(packed.zipBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

    const boundary = `tcb-boundary-${Date.now().toString(36)}`;
    const header = `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${packed.filename}"\r\nContent-Type: application/zip\r\n\r\n`;
    const footer = `\r\n--${boundary}--\r\n`;
    const headerBytes = new TextEncoder().encode(header);
    const footerBytes = new TextEncoder().encode(footer);
    const body = new Uint8Array(headerBytes.length + bytes.length + footerBytes.length);
    body.set(headerBytes, 0);
    body.set(bytes, headerBytes.length);
    body.set(footerBytes, headerBytes.length + bytes.length);

    try {
      logStage('upload.start', `上传日志包 ${packed.filename} (${bytes.length} 字节)`);
      // fetch 必须带超时，否则请求挂起时 Promise 永不 settle（MV3 SW 下无默认超时）
      const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const fetchTimeout = setTimeout(() => {
        if (controller) controller.abort();
      }, 20000);
      let resp;
      try {
        resp = await fetch(cfg.endpoint + '/upload', {
          method: 'POST',
          headers: {
            'Content-Type': `multipart/form-data; boundary=${boundary}`,
            'X-Upload-Token': cfg.token,
          },
          body: body,
          signal: controller ? controller.signal : undefined,
        });
      } finally {
        clearTimeout(fetchTimeout);
      }
      const text = await resp.text();
      let result = null;
      try {
        result = JSON.parse(text);
      } catch (e) {
        result = { ok: false, error: text.slice(0, 200) };
      }
      if (resp.ok && result.ok) {
        logStage('upload.done', `上传成功 ${result.filename} → ${result.cloudPath || ''}`);
        return {
          ok: true,
          filename: result.filename,
          cloudPath: result.cloudPath,
          url: result.url,
          entryCount: packed.entryCount,
        };
      }
      logStage('upload.error', result.error || `HTTP ${resp.status}`);
      return { ok: false, error: result.error || `上传失败 HTTP ${resp.status}` };
    } catch (err) {
      logStage('upload.error', err.message || String(err));
      return { ok: false, error: '上传异常: ' + (err.message || String(err)) };
    }
  }

  global.TCBLogExport = { exportLogPackage, cleanupAbnormalShipRecords, uploadLogPackage, loadUploadConfig, saveUploadConfig };
})(typeof self !== 'undefined' ? self : this);
