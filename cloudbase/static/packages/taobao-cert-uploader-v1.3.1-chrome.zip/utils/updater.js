/*
 * 自动更新检查模块（background SW 使用）
 *
 * - 每小时整点检查后台 /public-latest 接口，对比当前版本
 * - 发现新版本 → 记录到 storage(供弹窗/面板展示) + 通知所有页面
 * - 提供 download() 下载最新包（Chrome zip 走 downloads API）
 *
 * MV3 说明：Chrome 扩展无法静默替换自身安装包（需用户经 chrome://extensions
 * 确认），因此实现为「自动检测 + 强提醒 + 一键下载新版包」，用户下载 zip 后
 * 解压覆盖即可（或直接拖拽 crx）。
 */
(function (global) {
  'use strict';

  const UPDATER_CONFIG = {
    // 检查接口（公开，免登录）
    api: 'https://gitbolg-d7gmnsrw46e011706-1256429518.ap-shanghai.app.tcloudbase.com/tcb-admin/public-latest',
    // 检查间隔：每小时对齐整点（分钟=0 秒=0）
    checkEveryMs: 60 * 60 * 1000,
    // 上次检查时间存储键
    lastCheckKey: 'tcbUpdaterLastCheck',
    // 通知标记（避免重复弹通知）
    notifiedKey: 'tcbUpdaterNotifiedVersion',
  };

  let currentVersion = '';
  let latestInfo = null; // { latestVersion, chrome:{url,...}, crx:{url,...}, checkedAt }
  let checkTimer = null;

  function getCurrentVersion() {
    if (currentVersion) return currentVersion;
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
        currentVersion = (chrome.runtime.getManifest().version || '').trim();
      }
    } catch (e) { /* ignore */ }
    return currentVersion;
  }

  /** 语义化版本比较：a > b 返回 1, a < b 返回 -1, 相等返回 0 */
  function compareVersions(a, b) {
    const pa = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const da = pa[i] || 0, db = pb[i] || 0;
      if (da !== db) return da > db ? 1 : -1;
    }
    return 0;
  }

  function hasUpdate() {
    const cur = getCurrentVersion();
    const latest = latestInfo && latestInfo.latestVersion;
    if (!cur || !latest) return false;
    return compareVersions(latest, cur) > 0;
  }

  /** 检查最新版本（返回 { hasUpdate, currentVersion, latestVersion, chrome, crx }） */
  function checkForUpdate(force) {
    return new Promise((resolve) => {
      // 非强制且距上次检查 < 10 分钟，直接用缓存
      if (!force && latestInfo && Date.now() - (latestInfo.checkedAt || 0) < 10 * 60 * 1000) {
        resolve({ hasUpdate: hasUpdate(), currentVersion: getCurrentVersion(), ...latestInfo });
        return;
      }
      fetch(UPDATER_CONFIG.api, { method: 'GET' })
        .then((resp) => resp.json().catch(() => ({})))
        .then((data) => {
          if (data && data.ok && data.latestVersion) {
            latestInfo = {
              latestVersion: data.latestVersion,
              chrome: data.chrome || null,
              crx: data.crx || null,
              checkedAt: Date.now(),
            };
            // 记录检查时间
            try {
              chrome.storage.local.set({ [UPDATER_CONFIG.lastCheckKey]: Date.now() });
            } catch (e) { /* ignore */ }
            const upd = hasUpdate();
            if (upd) notifyPagesOfUpdate();
            resolve({ hasUpdate: upd, currentVersion: getCurrentVersion(), ...latestInfo });
          } else {
            resolve({ hasUpdate: false, currentVersion: getCurrentVersion(), latestVersion: getCurrentVersion(), error: '接口异常' });
          }
        })
        .catch((err) => {
          resolve({ hasUpdate: false, currentVersion: getCurrentVersion(), latestVersion: getCurrentVersion(), error: err.message });
        });
    });
  }

  /** 通知所有标签页有新版（内容脚本收到后可在面板显示更新角标） */
  function notifyPagesOfUpdate() {
    if (typeof chrome === 'undefined' || !chrome.tabs) return;
    chrome.tabs.query({}, (tabs) => {
      (tabs || []).forEach((tab) => {
        if (!tab.id) return;
        chrome.tabs.sendMessage(tab.id, {
          action: 'TCB_UPDATE_AVAILABLE',
          version: latestInfo ? latestInfo.latestVersion : '',
        }).catch(() => {});
      });
    });
  }

  /** 读取存储中的更新状态（供弹窗/面板查询） */
  function getUpdateState() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve({ hasUpdate: hasUpdate(), ...(latestInfo || {}) });
        return;
      }
      chrome.storage.local.get([UPDATER_CONFIG.lastCheckKey, UPDATER_CONFIG.notifiedKey], (data) => {
        resolve({
          hasUpdate: hasUpdate(),
          currentVersion: getCurrentVersion(),
          ...(latestInfo || {}),
          lastCheck: data[UPDATER_CONFIG.lastCheckKey] || 0,
          notifiedVersion: data[UPDATER_CONFIG.notifiedKey] || '',
        });
      });
    });
  }

  /** 下载最新版（chrome zip；360 crx 可选） */
  function downloadLatest(which) {
    return new Promise((resolve) => {
      if (!latestInfo) {
        resolve({ ok: false, error: '尚未检查到版本信息' });
        return;
      }
      const target = which === 'crx' ? latestInfo.crx : latestInfo.chrome;
      if (!target || !target.url) {
        resolve({ ok: false, error: '未找到对应的安装包' });
        return;
      }
      if (typeof chrome !== 'undefined' && chrome.downloads && typeof chrome.downloads.download === 'function') {
        chrome.downloads.download(
          { url: target.url, filename: target.filename || 'taobao-cert-update.zip', saveAs: true, conflictAction: 'uniquify' },
          (id) => {
            if (chrome.runtime.lastError) {
              resolve({ ok: false, error: chrome.runtime.lastError.message });
              return;
            }
            resolve({ ok: true, downloadId: id, filename: target.filename });
          }
        );
      } else {
        resolve({ ok: false, error: '当前环境不支持下载' });
      }
    });
  }

  /** 启动定时检查：对齐整点，每小时一次 */
  function startAutoCheck() {
    if (checkTimer) clearInterval(checkTimer);
    // 计算到下一个整点的毫秒数
    const now = new Date();
    const nextHour = new Date(now);
    nextHour.setHours(now.getHours() + 1, 0, 0, 0);
    const delayToHour = nextHour.getTime() - now.getTime();
    // 首次：10 秒后检查一次（SW 启动时），之后对齐整点
    setTimeout(() => {
      checkForUpdate(false);
    }, 10 * 1000);
    checkTimer = setInterval(() => {
      checkForUpdate(false);
    }, UPDATER_CONFIG.checkEveryMs);
    // 对齐整点的长定时（防止 SW 休眠导致 interval 漂移）
    setTimeout(() => {
      checkForUpdate(true);
      if (checkTimer) clearInterval(checkTimer);
      checkTimer = setInterval(() => checkForUpdate(false), UPDATER_CONFIG.checkEveryMs);
    }, delayToHour);
  }

  global.TCBUpdater = {
    checkForUpdate,
    getUpdateState,
    downloadLatest,
    startAutoCheck,
    compareVersions,
    hasUpdate,
    config: UPDATER_CONFIG,
  };
})(typeof self !== 'undefined' ? self : this);
