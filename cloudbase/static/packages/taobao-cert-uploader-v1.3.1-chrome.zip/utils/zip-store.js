(function (global) {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c;
  }

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
      crc = table[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function toBytes(text) {
    return new TextEncoder().encode(text);
  }

  function writeUint16LE(bytes, offset, value) {
    bytes[offset] = value & 0xff;
    bytes[offset + 1] = (value >>> 8) & 0xff;
  }

  function writeUint32LE(bytes, offset, value) {
    bytes[offset] = value & 0xff;
    bytes[offset + 1] = (value >>> 8) & 0xff;
    bytes[offset + 2] = (value >>> 16) & 0xff;
    bytes[offset + 3] = (value >>> 24) & 0xff;
  }

  async function deflateRaw(bytes) {
    if (!bytes.length) {
      return new Uint8Array([0x03, 0x00]);
    }
    if (typeof CompressionStream === 'undefined') {
      return bytes;
    }
    const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  async function createZipDeflate(files) {
    const chunks = [];
    const central = [];
    let offset = 0;

    for (const file of files) {
      const nameBytes = toBytes(file.name);
      const isDir = file.name.endsWith('/');
      const rawData = isDir
        ? new Uint8Array(0)
        : file.data instanceof Uint8Array
          ? file.data
          : toBytes(String(file.data || ''));
      const compressed = await deflateRaw(rawData);
      const method = typeof CompressionStream === 'undefined' ? 0 : 8;
      const payload = method === 0 ? rawData : compressed;
      const crc = crc32(rawData);

      const localHeader = new Uint8Array(30 + nameBytes.length);
      writeUint32LE(localHeader, 0, 0x04034b50);
      writeUint16LE(localHeader, 4, 20);
      writeUint16LE(localHeader, 6, 0);
      writeUint16LE(localHeader, 8, method);
      writeUint16LE(localHeader, 10, 0);
      writeUint16LE(localHeader, 12, 0);
      writeUint32LE(localHeader, 14, crc);
      writeUint32LE(localHeader, 18, payload.length);
      writeUint32LE(localHeader, 22, rawData.length);
      writeUint16LE(localHeader, 26, nameBytes.length);
      writeUint16LE(localHeader, 28, 0);
      localHeader.set(nameBytes, 30);

      const centralHeader = new Uint8Array(46 + nameBytes.length);
      writeUint32LE(centralHeader, 0, 0x02014b50);
      writeUint16LE(centralHeader, 4, 20);
      writeUint16LE(centralHeader, 6, 20);
      writeUint16LE(centralHeader, 8, 0);
      writeUint16LE(centralHeader, 10, method);
      writeUint16LE(centralHeader, 12, 0);
      writeUint16LE(centralHeader, 14, 0);
      writeUint32LE(centralHeader, 16, crc);
      writeUint32LE(centralHeader, 20, payload.length);
      writeUint32LE(centralHeader, 24, rawData.length);
      writeUint16LE(centralHeader, 28, nameBytes.length);
      writeUint16LE(centralHeader, 30, 0);
      writeUint16LE(centralHeader, 32, 0);
      writeUint16LE(centralHeader, 34, 0);
      writeUint16LE(centralHeader, 36, 0);
      writeUint32LE(centralHeader, 38, 0);
      writeUint32LE(centralHeader, 42, offset);
      centralHeader.set(nameBytes, 46);

      chunks.push(localHeader, payload);
      central.push(centralHeader);
      offset += localHeader.length + payload.length;
    }

    const centralSize = central.reduce((sum, part) => sum + part.length, 0);
    const end = new Uint8Array(22);
    writeUint32LE(end, 0, 0x06054b50);
    writeUint16LE(end, 4, 0);
    writeUint16LE(end, 6, 0);
    writeUint16LE(end, 8, files.length);
    writeUint16LE(end, 10, files.length);
    writeUint32LE(end, 12, centralSize);
    writeUint32LE(end, 16, offset);
    writeUint16LE(end, 20, 0);

    const totalSize =
      chunks.reduce((sum, part) => sum + part.length, 0) + centralSize + end.length;
    const zip = new Uint8Array(totalSize);
    let pos = 0;
    chunks.forEach((part) => {
      zip.set(part, pos);
      pos += part.length;
    });
    central.forEach((part) => {
      zip.set(part, pos);
      pos += part.length;
    });
    zip.set(end, pos);
    return zip;
  }

  global.TCBZipStore = { createZipDeflate, toBytes };
})(typeof self !== 'undefined' ? self : this);
