/*
 * 统一日志收集器（content script / background / popup 共用）
 *
 * 设计目标：
 *  - 所有 TCB.log / console 输出自动进入内存环形缓冲，并批量持久化到 chrome.storage.local
 *  - 每条日志带 level / time / context / detail，可回溯「谁、在哪个页面、做了什么」
 *  - 面板按钮可一键打包导出日志包（含运行现场快照），便于问题排查
 */
(function () {
  'use strict';

  // SW（service worker）环境没有 window/document，统一用安全引用
  const GLOBAL = typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : globalThis;
  const HAS_WINDOW = typeof window !== 'undefined';
  const HAS_DOCUMENT = typeof document !== 'undefined';
  const DOC = HAS_DOCUMENT ? document : null;

  const STORAGE_KEY = 'tcbLogEntries';
  const STORAGE_META_KEY = 'tcbLogMeta';
  const MAX_MEMORY_ENTRIES = 2000; // 内存环形缓冲上限
  const MAX_STORAGE_ENTRIES = 800; // storage 持久化上限（超限裁剪保留最新）
  const FLUSH_INTERVAL_MS = 3000; // 批量落盘间隔
  const MAX_BATCH = 50; // 每次落盘最多条数

  // 日志滚动清理：默认只保留最近 7 天（可通过 TCBLogger.setRetentionDays 调整）
  let RETENTION_DAYS = 7;
  const RETENTION_KEY = 'tcbLogRetentionDays';

  const COLORS = {
    log: '#1677ff',
    info: '#1677ff',
    warn: '#faad14',
    error: '#ff4d4f',
    debug: '#8c8c8c',
  };

  let memoryBuffer = [];
  let storageFlushQueue = [];
  let flushTimer = null;
  let storageReady = false;

  // —— 上下文 ——
  const ctx = {
    env: 'content', // content | background | popup
    url: typeof location !== 'undefined' ? location.href : '',
    tabId: 0,
    frame: 'top',
    windowId: 0,
    incognito: false,
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
    startedAt: Date.now(),
  };
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) {
      ctx.manifest = chrome.runtime.getManifest();
      ctx.extVersion = (ctx.manifest && ctx.manifest.version) || '';
      ctx.extName = (ctx.manifest && ctx.manifest.name) || '';
    }
  } catch (e) { /* ignore */ }
  try {
    if (typeof chrome !== 'undefined' && chrome.tabs && typeof chrome.tabs.query === 'function') {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs && tabs[0];
        if (tab) {
          ctx.tabId = tab.id || 0;
          ctx.windowId = tab.windowId || 0;
          ctx.incognito = !!tab.incognito;
          ctx.url = tab.url || ctx.url;
        }
      });
    }
  } catch (e) { /* ignore */ }
  if (typeof window !== 'undefined') {
    ctx.frame = window.top === window ? 'top' : 'iframe';
  }

  // —— 内部函数 ——
  function pad(n, len) {
    return String(n).padStart(len || 2, '0');
  }

  function timestamp() {
    const d = new Date();
    return `${pad(d.getFullYear(), 4)}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
  }

  function normalizeError(err) {
    if (!err) return '';
    if (typeof err === 'string') return err;
    if (err instanceof Error) {
      const lines = [err.message || String(err)];
      if (err.stack) lines.push(err.stack);
      return lines.join('\n');
    }
    try {
      return JSON.stringify(err);
    } catch (e2) {
      return String(err);
    }
  }

  function normalizeDetail(detail) {
    if (detail == null) return '';
    if (typeof detail === 'string') return detail;
    if (detail instanceof Error) return normalizeError(detail);
    if (Array.isArray(detail)) {
      return detail.map((d) => normalizeDetail(d)).join(' ');
    }
    try {
      const s = JSON.stringify(detail, (k, v) => {
        if (typeof v === 'function') return undefined;
        if (v instanceof Error) return normalizeError(v);
        if (v instanceof HTMLElement) return { tag: v.tagName, id: v.id, cls: v.className };
        return v;
      });
      return s && s.length > 2000 ? s.slice(0, 2000) + '…(截断)' : s;
    } catch (e2) {
      return String(detail);
    }
  }

  // —— 对外 API ——
  function makeEntry(level, context, detail, extra) {
    return {
      ts: Date.now(),
      time: timestamp(),
      level,
      context: context || '',
      detail: normalizeDetail(detail),
      extra: extra || {},
    };
  }

  /**
   * 动作记录：结构化记录一次用户/系统动作（正常分支与异常分支都打点）
   * 返回动作 ID，可后续补充结果（action.finish）
   */
  let actionSeq = 0;
  function action(name, data, opts) {
    const entry = {
      ts: Date.now(),
      time: timestamp(),
      level: opts && opts.level ? opts.level : 'info',
      context: `action.${name}`,
      detail: normalizeDetail(data || {}),
      extra: {
        actionId: (opts && opts.id) || `A${++actionSeq}`,
        isAction: true,
        ...(opts && opts.extra ? opts.extra : {}),
      },
    };
    addEntry(entry);
    return entry.extra.actionId;
  }

  function actionResult(actionId, ok, result) {
    addEntry(
      makeEntry(
        ok ? 'info' : 'warn',
        'action.result',
        result ? normalizeDetail(result) : (ok ? '成功' : '失败'),
        { actionId, ok: !!ok }
      )
    );
  }

  // 最近 N 条动作记录（供异常现场附带上文）
  function recentActions(max) {
    const all = memoryBuffer.concat([]);
    const actions = all.filter((e) => e.extra && e.extra.isAction);
    return actions.slice(-(max || 20));
  }

  /**
   * 异常现场快照：异常发生时自动保存现场（DOM 环境、上下文、动作记录、storage 关键值）
   * 返回快照对象；可附加当前批次状态
   */
  async function captureScene(reason, extraInfo) {
    const scene = {
      capturedAt: timestamp(),
      reason: reason || 'unknown',
      ...buildSnapshot(),
      recentActions: recentActions(30),
      extra: extraInfo || {},
    };

    // storage 关键键值（密码哈希脱敏）
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        const keys = [
          'tcbCompletedShipOrders',
          'tcbBatchState',
          'tcbCertUploadDelayMs',
          'tcbInjectedWhitelist',
          'tcbRemovedBuiltinWhitelist',
          'tcbAdminPasswordHash',
          'tcbAuthorizedShopName',
          'certSerial',
        ];
        scene.storage = await new Promise((resolve) => {
          chrome.storage.local.get(keys, (data) => {
            const out = {};
            keys.forEach((k) => {
              if (data[k] === undefined) return;
              if (k === 'tcbAdminPasswordHash' && typeof data[k] === 'string') {
                out[k] = data[k].slice(0, 8) + '…(隐藏)';
                return;
              }
              out[k] = data[k];
            });
            resolve(out);
          });
        });
      } catch (e) { /* ignore */ }
    }

    return scene;
  }

  /**
   * 异常现场持久化：将异常场景存入 storage（异常现场记录，独立于普通日志保留）
   * 返回场景 ID
   */
  function persistScene(scene) {
    const sceneId = `scene-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const sceneRecord = { ...scene, sceneId, persistedAt: timestamp() };
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.get('tcbErrorScenes', (data) => {
          let scenes = Array.isArray(data.tcbErrorScenes) ? data.tcbErrorScenes : [];
          scenes.push(sceneRecord);
          // 异常现场保留最近 20 个
          scenes = scenes.slice(-20);
          chrome.storage.local.set({ tcbErrorScenes: scenes });
        });
      } catch (e) { /* ignore */ }
    }
    return sceneId;
  }

  // 记录一条异常 + 自动保存现场
  async function errorWithScene(context, error, extraInfo) {
    const scene = await captureScene(context, extraInfo);
    const sceneId = persistScene(scene);
    log('error', context, error, { sceneId, ...(extraInfo || {}) });
    return sceneId;
  }

  function addEntry(entry) {
    memoryBuffer.push(entry);
    if (memoryBuffer.length > MAX_MEMORY_ENTRIES) {
      memoryBuffer.splice(0, memoryBuffer.length - MAX_MEMORY_ENTRIES);
    }
    storageFlushQueue.push(entry);
    if (storageFlushQueue.length >= MAX_BATCH) {
      flushToStorage();
    } else if (!flushTimer) {
      flushTimer = setTimeout(flushToStorage, FLUSH_INTERVAL_MS);
    }
  }

  function flushToStorage() {
    if (flushTimer) {
      clearTimeout(flushTimer);
      flushTimer = null;
    }
    if (!storageFlushQueue.length) return;
    const batch = storageFlushQueue.splice(0, storageFlushQueue.length);
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return; // 非扩展环境，仅内存
    }
    try {
      chrome.storage.local.get(STORAGE_KEY, (data) => {
        let existing = [];
        try {
          existing = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
        } catch (e) { /* ignore */ }
        let merged = existing.concat(batch);
        // 滚动清理：先按保留天数裁剪，再按条数上限裁剪（防止磁盘/存储膨胀）
        if (RETENTION_DAYS > 0) {
          const cutoff = Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000;
          merged = merged.filter((e) => {
            const ts = e && typeof e.ts === 'number' ? e.ts : 0;
            return ts >= cutoff;
          });
        }
        const trimmed = merged.slice(-MAX_STORAGE_ENTRIES);
        const payload = {};
        payload[STORAGE_KEY] = trimmed;
        chrome.storage.local.set(payload, () => {
          storageReady = true;
        });
      });
    } catch (e) { /* ignore */ }
  }

  function log(level, context, detail, extra) {
    addEntry(makeEntry(level, context, detail, extra));
  }

  function buildSnapshot() {
    const snapshot = {
      ts: Date.now(),
      time: timestamp(),
      env: ctx.env,
      extName: ctx.extName,
      extVersion: ctx.extVersion,
      url: ctx.url,
      tabId: ctx.tabId,
      windowId: ctx.windowId,
      frame: ctx.frame,
      incognito: ctx.incognito,
      userAgent: ctx.userAgent,
    };

    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getManifest === 'function') {
      try {
        snapshot.manifest = chrome.runtime.getManifest();
      } catch (e) { /* ignore */ }
    }

    // 页面级 DOM 快照（仅 content script 且有 document 时）
    if (ctx.env === 'content' && HAS_DOCUMENT && DOC) {
      try {
        snapshot.dom = {
          title: DOC.title,
          readyState: DOC.readyState,
          url: typeof location !== 'undefined' ? location.href : '',
          iframes: Array.from(DOC.querySelectorAll('iframe')).map((f) => ({
            src: (f.src || '').slice(0, 300),
            w: f.clientWidth,
            h: f.clientHeight,
          })),
          elements: {
            certButtons: TCBElCount('a, button, span, div[role="button"]'),
            fileInputs: TCBElCount('input[type="file"]'),
            certNumberLabels: Array.from(DOC.querySelectorAll('[title="证书编号"]')).length,
            itemSerialInputs: DOC.querySelectorAll('#item_showSerialNo').length,
            tabs: DOC.querySelectorAll('.ant-tabs-nav').length,
            modals: DOC.querySelectorAll('.ant-modal, .tcb-modal, .tcb-modal-overlay').length,
            topClose: DOC.querySelectorAll('a[aria-label="关闭"]').length,
          },
        };
      } catch (e) { /* ignore */ }
    }

    return snapshot;
  }

  function TCBElCount(sel) {
    if (!HAS_DOCUMENT || !DOC) return -1;
    try {
      return DOC.querySelectorAll(sel).length;
    } catch (e) {
      return -1;
    }
  }

  function collectStorageEntries(max) {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve([]);
        return;
      }
      chrome.storage.local.get(STORAGE_KEY, (data) => {
        let list = [];
        try {
          list = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
        } catch (e) { /* ignore */ }
        if (max && list.length > max) list = list.slice(-max);
        resolve(list);
      });
    });
  }

  function collectMeta() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve({});
        return;
      }
      chrome.storage.local.get(STORAGE_META_KEY, (data) => {
        resolve(data[STORAGE_META_KEY] || {});
      });
    });
  }

  function setMeta(patch) {
    collectMeta().then((meta) => {
      const next = { ...meta, ...patch, updatedAt: Date.now() };
      try {
        chrome.storage.local.set({ [STORAGE_META_KEY]: next });
      } catch (e) { /* ignore */ }
    });
  }

  // 供 background 导出使用：合并内存 + storage 的日志
  function collectAll(max) {
    return collectStorageEntries(max || MAX_STORAGE_ENTRIES + 500).then((stored) => {
      const merged = stored.concat(memoryBuffer);
      const seen = new Set();
      const unique = [];
      // 简单去重：同 ts+level+detail 视为同一条
      merged.forEach((e) => {
        if (!e || typeof e.ts !== 'number') return;
        const key = `${e.ts}|${e.level}|${e.context}|${e.detail}`;
        if (seen.has(key)) return;
        seen.add(key);
        unique.push(e);
      });
      unique.sort((a, b) => a.ts - b.ts);
      return unique;
    });
  }

  function clear() {
    memoryBuffer = [];
    storageFlushQueue = [];
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.remove(STORAGE_KEY);
        chrome.storage.local.remove(STORAGE_META_KEY);
      } catch (e) { /* ignore */ }
    }
  }

  /** 收集已持久化的异常现场 */
  function collectErrorScenes(max) {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
        resolve([]);
        return;
      }
      chrome.storage.local.get('tcbErrorScenes', (data) => {
        let scenes = Array.isArray(data.tcbErrorScenes) ? data.tcbErrorScenes : [];
        if (max && scenes.length > max) scenes = scenes.slice(-max);
        resolve(scenes);
      });
    });
  }

  const LEVEL_LABEL = { log: 'INFO', info: 'INFO', warn: 'WARN', error: 'ERROR', debug: 'DEBUG' };

  /**
   * 把日志条目渲染成一行人类可读文本（操作记录风格）
   * 例：[2026-08-22 14:30:00.123] [INFO] [ship.process] 处理第 2/5 个证书「上传证书」
   */
  function entryToText(e) {
    const t = e.time || (e.ts ? new Date(e.ts).toISOString().replace('T', ' ').slice(0, 23) : '');
    const lvl = LEVEL_LABEL[e.level] || String(e.level || '').toUpperCase() || 'INFO';
    const ctxPart = e.context ? `[${e.context}] ` : '';
    const detail = typeof e.detail === 'string' ? e.detail : normalizeDetail(e.detail);
    const extraPart = e.extra && Object.keys(e.extra).length
      ? ` ${normalizeDetail(e.extra)}`
      : '';
    return `[${t}] [${lvl}] ${ctxPart}${detail}${extraPart}`;
  }

  /**
   * 生成人类可读的日志文本（含分隔的操作记录 + 统计汇总）
   * 供导出日志包 / 异常现场附带上文使用
   */
  function entriesToText(entries) {
    const lines = entries.map(entryToText);
    const stats = {};
    entries.forEach((e) => {
      stats[e.level] = (stats[e.level] || 0) + 1;
    });
    const header = [
      '════════════════════════════════════════════════════',
      `  淘宝证书自动上传 · 操作日志导出`,
      `  导出时间: ${timestamp()}`,
      `  日志条数: ${entries.length}  (${Object.entries(stats).map(([k, v]) => `${k}:${v}`).join('  ')})`,
      `  环境: ${ctx.env}  扩展: ${ctx.extName || ''} v${ctx.extVersion || ''}`,
      `  页面: ${ctx.url || ''}`,
      '════════════════════════════════════════════════════',
      '',
    ];
    return header.concat(lines).join('\n');
  }

  let consoleHooked = false;
  function installConsoleHooks() {
    if (typeof console === 'undefined' || consoleHooked) return;
    consoleHooked = true;
    const origLog = console.log.bind(console);
    const origWarn = console.warn.bind(console);
    const origError = console.error.bind(console);
    // TCB.log/warn/error 已通过 LOGGER 直接记录，这里跳过其带前缀的输出避免重复
    function isTcbStyled(args) {
      const first = args && args[0];
      return typeof first === 'string' && /^%?\[?证书上传/.test(first);
    }
    console.log = function (...args) {
      origLog(...args);
      if (!isTcbStyled(args)) {
        log('log', 'console.log', args.length === 1 ? args[0] : args, { source: 'console' });
      }
    };
    console.warn = function (...args) {
      origWarn(...args);
      if (!isTcbStyled(args)) {
        log('warn', 'console.warn', args.length === 1 ? args[0] : args, { source: 'console' });
      }
    };
    console.error = function (...args) {
      origError(...args);
      if (!isTcbStyled(args)) {
        log('error', 'console.error', args.length === 1 ? args[0] : args, { source: 'console' });
      }
    };
    // 捕获未处理异常 / Promise 拒绝，便于问题现场还原（自动保存现场）
    if (HAS_WINDOW && typeof window.addEventListener === 'function') {
      try {
        window.addEventListener('error', (event) => {
          const detail = {
            message: event.message || '',
            filename: event.filename || '',
            lineno: event.lineno || 0,
            colno: event.colno || 0,
            stack: event.error && event.error.stack ? event.error.stack : '',
          };
          captureScene('window.onerror', detail).then((scene) => {
            persistScene(scene);
            log('error', 'window.onerror', detail, { sceneId: scene.sceneId });
          }).catch(() => {
            log('error', 'window.onerror', detail);
          });
        });
        window.addEventListener('unhandledrejection', (event) => {
          const detail = event && event.reason ? String(event.reason) : '(未提供原因)';
          captureScene('unhandledrejection', { reason: detail }).then((scene) => {
            persistScene(scene);
            log('error', 'unhandledrejection', detail, { sceneId: scene.sceneId });
          }).catch(() => {
            log('error', 'unhandledrejection', detail);
          });
        });
      } catch (e) { /* ignore */ }
    }
  }

  // —— 保留天数（滚动清理） ——
  function loadRetentionSetting() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.get(RETENTION_KEY, (data) => {
          const v = Number(data[RETENTION_KEY]);
          if (Number.isFinite(v) && v > 0) {
            RETENTION_DAYS = v;
          }
        });
      } catch (e) { /* ignore */ }
    }
  }

  function setRetentionDays(days) {
    const v = Math.max(1, Math.floor(Number(days) || RETENTION_DAYS));
    RETENTION_DAYS = v;
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      try {
        chrome.storage.local.set({ [RETENTION_KEY]: v });
      } catch (e) { /* ignore */ }
    }
    flushToStorage();
    return v;
  }

  function getRetentionDays() {
    return RETENTION_DAYS;
  }

  // 全局注册
  const api = {
    ctx,
    log,
    info: (context, detail, extra) => log('info', context, detail, extra),
    warn: (context, detail, extra) => log('warn', context, detail, extra),
    error: (context, detail, extra) => log('error', context, detail, extra),
    debug: (context, detail, extra) => log('debug', context, detail, extra),
    makeEntry,
    action,
    actionResult,
    recentActions,
    captureScene,
    persistScene,
    errorWithScene,
    collectErrorScenes,
    entriesToText,
    entryToText,
    buildSnapshot,
    collectAll,
    collectStorageEntries,
    collectMeta,
    setMeta,
    clear,
    flushToStorage,
    installConsoleHooks,
    setRetentionDays,
    getRetentionDays,
    storageKey: STORAGE_KEY,
    retentionKey: RETENTION_KEY,
    setEnv: (env) => { ctx.env = env; },
    colors: COLORS,
  };

  GLOBAL.TCBLogger = api;
  // 让 helpers 的 TCB.log 可感知（TCB 可能尚未定义，由 helpers 加载时桥接）
  if (HAS_WINDOW && window.TCB && window.TCB.log) {
    window.TCB._logger = api;
  }

  // 立即记录一条启动日志（各环境首次加载即可见）
  api.log('info', 'logger.init', `日志系统已初始化 env=${ctx.env} url=${ctx.url || ''} 保留${RETENTION_DAYS}天`);

  // 读取保留天数配置
  loadRetentionSetting();

  // 默认启用 console 钩子：所有 console.log/warn/error 都会进入日志系统（正常运行也记录）
  api.installConsoleHooks();
})();
